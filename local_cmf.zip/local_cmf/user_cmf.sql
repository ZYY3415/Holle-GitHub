/*
Navicat MySQL Data Transfer

Source Server         : local_1
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : user_cmf

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2017-09-06 21:08:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cmf_login
-- ----------------------------
DROP TABLE IF EXISTS `cmf_login`;
CREATE TABLE `cmf_login` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` char(30) DEFAULT '' COMMENT '用户名',
  `password` varchar(60) DEFAULT '' COMMENT '加密之后的密码',
  `yan` varchar(10) DEFAULT '123456' COMMENT '盐，用户密码的加密',
  `is_del` tinyint(3) unsigned DEFAULT '0' COMMENT '是否删除，0 否 1是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cmf_login
-- ----------------------------
INSERT INTO `cmf_login` VALUES ('1', 'admin', 'MjEyMzJmMjk3YTU3YTVhNzQzODk0YTBlNGE4MDFmYzMxMjM0NTY=', '123456', '0');

-- ----------------------------
-- Table structure for cmf_nav
-- ----------------------------
DROP TABLE IF EXISTS `cmf_nav`;
CREATE TABLE `cmf_nav` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `navname` char(30) DEFAULT '' COMMENT '导航名',
  `parent_id` tinyint(3) unsigned DEFAULT '0' COMMENT '父级导航的id  0为顶级导航',
  `href` varchar(255) DEFAULT '' COMMENT '链接',
  `opentype` char(10) DEFAULT '0' COMMENT '页面打开方式 0默认在当前打开  __blank  新页面打开',
  `is_show` tinyint(3) unsigned DEFAULT '1' COMMENT '是否显示    0 不显示   1显示',
  `is_del` tinyint(3) unsigned DEFAULT '0' COMMENT '是否删除  0否  1是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cmf_nav
-- ----------------------------
INSERT INTO `cmf_nav` VALUES ('1', '关于天华', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('2', '交易指南', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('3', '交易中心', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('4', '在线课堂', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('6', '数据中心', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('7', '软件下载', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('8', '天华学院', '0', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('9', '天华金号简介', '1', '', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('10', '最新公告', '1', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('11', '公司新闻', '1', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('12', '资质荣耀', '1', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('13', '联系我们', '1', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('14', '交易产品', '2', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('15', '产品介绍', '2', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('16', '交易细则', '2', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('17', '交易词汇', '2', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('18', '挂单优势', '2', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('19', '开立真实账户', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('20', '开立模拟账户', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('21', '优惠活动', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('22', '常用表格下载', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('23', '常见问题', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('24', '交易编号', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('25', '投诉指南', '3', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('26', '数据中心', '6', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('27', '持仓比例', '6', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('28', '历史分笔数据', '6', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('29', '实时行情', '6', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('30', '财经日历', '6', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('31', 'MT4PC端', '7', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('32', 'MT4移动端', '7', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('33', '天华金号APP', '7', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('34', 'EA', '7', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('35', '天华课堂', '8', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('36', '投资百科', '8', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('37', '金融词典', '8', 'http://', '0', '1', '0');
INSERT INTO `cmf_nav` VALUES ('38', '最新资讯', '8', 'http://', '0', '1', '0');

-- ----------------------------
-- Table structure for cmf_navcate
-- ----------------------------
DROP TABLE IF EXISTS `cmf_navcate`;
CREATE TABLE `cmf_navcate` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` char(50) DEFAULT '' COMMENT '导航名',
  `remark` text COMMENT '备注',
  `is_main` tinyint(3) unsigned DEFAULT '0' COMMENT '0 默认不是主导航   1是',
  `is_del` tinyint(3) unsigned DEFAULT '0' COMMENT '是否删除 0否 1是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cmf_navcate
-- ----------------------------
INSERT INTO `cmf_navcate` VALUES ('1', '主导航', '0', '1', '0');
INSERT INTO `cmf_navcate` VALUES ('2', '新闻发布', '111', '1', '0');
INSERT INTO `cmf_navcate` VALUES ('3', '首页', 'fdfd', '1', '0');
INSERT INTO `cmf_navcate` VALUES ('4', '列表演示', 'ddd', '1', '0');
INSERT INTO `cmf_navcate` VALUES ('5', 'ddd', '11', '1', '0');
INSERT INTO `cmf_navcate` VALUES ('6', '1111', '0', '1', '0');
