<?php
return array(
	//'配置项'=>'配置值'
    'DEFAULT_CONTROLLER'        =>  'Login',  // 默认控制器
);