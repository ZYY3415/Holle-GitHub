<?php
namespace Admin\Controller;
use  Think\Controller;
use  Think\Page;
class  NavController extends Controller
{
    //显示菜单列表
    public function navlist()
    {
        if(IS_GET)
        {
            $navmodel = M('Nav');
            $navinfo = $navmodel->field('navname,id,is_show,parent_id')->select();

            //调用getTree方法  获取无限极分类  得到有序的菜单结构
            $navdata = getTree($navinfo);
            $this->assign('navdata',$navdata);
            $this->display('index');
        }

    }
    //菜单添加页
    public function addnav()
    {
        if(IS_GET)
        {
            $navmodel = M('Nav');
            $navinfo =$navmodel->field('navname,id,parent_id')->where('is_show=1')->select();
            $navdata = getTree($navinfo);
            $this->assign('navdata',$navdata);
            $this->display(T('add'));
        }

    }

    //添加表单
    public function addnav_post(){
        if(IS_POST) {
            $data['parent_id'] = I('post.parent_id') ? I('post.parent_id') : 0;
            $data['navname'] = I('post.navname') ? I('post.navname') : 0;
            $data['href'] = I('post.href') ? I('post.href') : 0;
            $data['opentype'] = I('post.opentype') ? I('post.opentype') : 0;
            $data['is_show'] = I('post.is_show') ? I('post.is_show') : 0;
            //判断数据是否存在
            $result = $this->check_nav($data);
            if ($result['code'] != 1) {
                return $this->ajaxReturn($result);
            }
            //数据入库
            $rel = D('Nav')->add($data);
            if (!$rel) {
                $error['code'] = -3;
                $error['message'] = '菜单添加失败';
                return $this->ajaxReturn($error);
            }
            $error['code'] = 1;
            $error['message'] = '菜单添加成功！';

            return $this->ajaxReturn($error);
        }
    }
   //菜单编辑
    public function editnav()
    {
       if(IS_GET){
           $id = I('get.id') ? I('get.id') : 0;

           if(!$id){
               $error['code'] = -1;
               $error['message'] = '该菜单不存在';
               return $this->ajaxReturn($error);
           }

           $navmodel = M('Nav');
           //获取所有的菜单信息
           $navallinfo =$navmodel->field('navname,id,parent_id')->where('is_show=1')->select();
           //根据id获取该菜单的信息
           $navoneinfo = $navmodel->where('id = %d',$id)->find();
           $navdata = getTree($navallinfo,0,0,$id);

           //模板赋值
           $this->assign('navdata',$navdata);
           $this->assign('navinfo',$navoneinfo);
           $this->display('edit');
       }else if(IS_POST){

           $data['id'] =I('post.id') ? I('post.id') :0;
           $data['parent_id'] = I('post.parent_id') ? I('post.parent_id') : 0;
           $data['navname'] = I('post.navname') ? I('post.navname') : 0;
           $data['href'] = I('post.href') ? I('post.href') : 0;
           $data['opentype'] = I('post.opentype') ? I('post.opentype') : 0;
           $data['is_show'] = I('post.is_show') ? I('post.is_show') : 0;

           $navmodel = M('Nav');
           //获取所有的菜单信息
           $navallinfo =$navmodel->field('navname,id,parent_id')->where('is_show=1')->select();
           //判断数据是否存在
           $result = $this->check_editnav($data);
           if ($result['code'] != 1) {
               return $this->ajaxReturn($result);
           }
           //判断该菜单下是否有子菜单，如果有则不允许修改
           $childnav = getTree($navallinfo,$data['id']);
           if($childnav){
               $error['code'] = -4;
               $error['message'] = '该菜单下还有子菜单，不允许修改';
               return $this->ajaxReturn($error);
           }
           //数据入库
           $rel = M('Nav')->save($data);
           if (!$rel) {
               $error['code'] = -3;
               $error['message'] = '菜单修改失败';
               return $this->ajaxReturn($error);
           }
           $error['code'] = 1;
           $error['message'] = '菜单修改成功！';

           return $this->ajaxReturn($error);
       }

    }
    //修改菜单数据验证
    public function check_editnav($data)
    {
        if(empty($data['navname']))
        {
            $error['code'] = -1;
            $error['message'] = '标签名不能为空！';
            return $error;
        }

        $result = D('Nav')->create($data);
        if(!$result)
        {
            $error['code'] = -2;
            $error['message'] = D('Nav')->getError();
            return $error;
        }
         $error['code'] = 1;
        return $error;
    }
    //数据验证
    public function check_nav($data)
    {
        if(empty($data['navname']))
        {
            $error['code'] = -1;
            $error['message'] = '标签名不能为空！';
            return $error;
        }

        $result = D('Nav')->create($data);
        if(!$result)
        {
            $error['code'] = -2;
            $error['message'] = D('Nav')->getError();
            return $error;
        }

        $navinfo = M('Nav')->field('navname')->where('is_show=1')->find();
        if(trim($navinfo['navname']) == trim($data['navname']))
        {
            $error['code'] = -4;
            $error['message'] = '该菜单名已存在';
            return $error;
        }
        return $error['code'] = 1;
    }


}






