<?php
namespace Admin\Controller;
use Think\Controller;
use Think\Log;
use Think\Verify;
class LoginController extends Controller
{
    public function index()
    {
     $this->display();

    }

    public function yzm()
    {
        if(IS_GET){
            $config =  array(
                'fontSize'    =>    20,    // 验证码字体大小
                'length'      =>    4,     // 验证码位数
                'useNoise'    =>    true,  // 验证码杂点
                'useCurve'    =>    false,   //关闭混淆曲线
                'imageW'      =>    '248',  //验证码的宽度
                'imageH'      =>    '51',   //验证码的高度
                'useImgBg'    =>     true,   //开启背景图片
                );
            $Verify = new Verify($config);
            $Verify->entry();
        }else{
            $this->error('非法链接!');
        }
    }
    //后台登陆
    public function login()
    {
        //接收数据
        $data['username'] = I('post.username') ? I('post.username') : 0;
        $data['password'] = I('post.password') ? I('post.password') : 0;
        $data['yzm'] = I('post.yzm') ? I('post.yzm') : 0;

        if(!$data['username']){
            $error['code'] = -1;
            $error['message'] = '用户名为空！';
            return $this->ajaxReturn($error);
        }

        if(!$data['password']){
            $error['code'] = -2;
            $error['message'] = '密码为空！';
            return $this->ajaxReturn($error);
        }
        if(!$data['yzm']){
            $error['code'] = -3;
            $error['message'] = '验证码为空！';
            return $this->ajaxReturn($error);
        }

        /*$Verify = new Verify();
        if(!$Verify->check($data['yzm'])){
            $error['code'] = -4;
            $error['message'] = '验证码不正确！';
            return $this->ajaxReturn($error);
        }*/
        //自动验证功能
        $result = D('Login')->create($data);
        if(!$result){
            $err =D('Login')->getError();
            Log::record($err['message'],'DEBUG');
            return $this->ajaxReturn(D('Login')->getError());
        }
        //判断该用户名是否被占用
        $userinfo = M('Login')->where("username = '%s'",$data['username'])->find();
        if(!$userinfo){
            $error['code'] = -7;
            $error['message'] = '用户不存在！';
            return $this->ajaxReturn($error);
        }
        //密码判断
        if(userBase_encode($data['password']) !=$userinfo['password'])
        {
            $error['code'] = -8;
            $error['message'] = '密码不正确！';
            return $this->ajaxReturn($error);
        }
        $error['code'] = 1;
        $error['message'] = '登录成功！';
        cookie('userinfo',$userinfo);
        return $this->ajaxReturn($error);
    }
}








