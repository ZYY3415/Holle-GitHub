<?php
namespace Admin\Controller;
use Think\Controller;

class NavCateController extends Controller
{
    //导航菜单类别显示
    public function index()
    {
       $this->display();
    }

    //添加菜单类别
    public function add()
    {
        if(IS_GET){
            $this->display();
        }else if(IS_AJAX){
            $data['name'] = I('post.name') ? I('post.name') : 0;
            $data['remark'] = I('post.remark') ? trim(I('post.remark')) : 0;
            $data['is_main'] = I('post.is_main') ? I('post.is_main') : 0;

            if(empty($data['name']))
            {
                return $this->ajaxReturn(array('code'=>-1,'msg'=>'名称不能为空！'));
            }

            $model = M('Navcate');
            $rel = $model->add($data);
            if(!$rel)
            {
                return $this->ajaxReturn(array('code'=>-2,'msg'=>'数据添加失败！'));
            }

            return $this->ajaxReturn(array('code'=>1,'msg'=>'数据添加成功！'));
        }
    }
}









