<?php
namespace Admin\Controller;
use Think\Controller;

class NavCateController extends Controller
{
    //导航菜单类别显示
    public function index()
    {
        $model =M('Navcate');
        $data = $model->field('id,name,is_main,remark')->select();
       /* var_dump($model ->getLastSql());exit;*/
        $this->assign('data',$data);
        $this->display();
    }

    //添加菜单类别
    public function add()
    {
        if(IS_GET){
            $this->display();
        }else if(IS_AJAX){
            $data['name'] = I('post.name') ? I('post.name') : 0;
            $data['remark'] = I('post.remark') ? trim(I('post.remark')) : 0;
            $data['is_main'] = I('post.is_main') ? I('post.is_main') : 0;

            if(empty($data['name']))
            {
                return $this->ajaxReturn(array('code'=>-1,'msg'=>'名称不能为空！'));
            }

            $model = M('Navcate');
            $info = $model ->where('name=%s',$data['name'])->find();
            if($info){
                return $this->ajaxReturn(array('code'=>-3,'msg'=>'该分类已经存在！'));
            }
            $rel = $model->add($data);
            if(!$rel)
            {
                return $this->ajaxReturn(array('code'=>-2,'msg'=>'数据添加失败！'));
            }

            return $this->ajaxReturn(array('code'=>1,'msg'=>'数据添加成功！'));
        }
    }

    //分类编辑
    public function edit()
    {
        if(IS_GET)
        {
            $id = I('get.id') ? I('get.id') : 0;
            $model = M('Navcate');
            $data =$model->field('id,name,remark,is_main')->where('id=%d and is_del=0',$id)->find();
            if(!$data)
            {
                return $this->ajaxReturn(array('code'=>-1,'msg'=>'数据不存在！'));
            }
            $this->assign('data',$data);
            $this->display('Nav_cate/edit');
        }else if(IS_AJAX)
        {
            $data['id'] = I('post.id') ? I('post.id') : 0;
            $data['name'] = I('post.name') ? I('post.name') : 0;
            $data['remark'] = I('post.remark') ? trim(I('post.remark')) : 0;
            $data['is_main'] = I('post.is_main') ? I('post.is_main') : 0;
            if(empty($data['name']))
            {
                return $this->ajaxReturn(array('code'=>-1,'msg'=>'名称不能为空！'));
            }

            $model = M('Navcate');
            $info = $model ->where("name='%s'",$data['name'])->find();
            if($info){
                return $this->ajaxReturn(array('code'=>-3,'msg'=>'该分类已经存在！'));
            }

            $navinfo = $model ->where('id=%d',$data['id'])->find();
            if(!$navinfo){
                return $this->ajaxReturn(array('code'=>-3,'msg'=>'该分类无效！'));
            }

            $rel = $model->save($data);
            if(!$rel)
            {
                return $this->ajaxReturn(array('code'=>-2,'msg'=>'数据编辑失败！'));
            }

            return $this->ajaxReturn(array('code'=>1,'msg'=>'数据编辑成功！'));
        }
    }
}









