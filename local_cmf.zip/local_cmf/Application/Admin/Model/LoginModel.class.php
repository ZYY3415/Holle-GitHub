<?php
namespace Admin\Model;
use   Think\Model;

class  LoginModel extends Model
{

    protected $fields = array('id','username','password','yan','is_del','_pk'=>'id');
    protected $_validate = array(
        array('username','check_username',array(
            'message'=>'用户名必须大于4位小于10位且不能全为数字',
            'code'  => -5
        ),0,'callback',3),
        array('password','check_password',array(
            'message' =>'密码必须大于4位小于12位且不能全为数字',
            'code'  => -6
        ),0,'callback',3)
    );
    //验证用户名的长度及格式
    public function check_username($username){
        $length = mb_strlen($username);
        $flag = true;
        if($length < 4 || $length > 10)
        {
            $flag = false;
        }
        $pattern = '/^(\d+)$/i';
        if(preg_match_all($pattern,$username))
        {
            $flag = false;
        }
        return $flag;
    }
    //验证密码的长度及格式
    public function check_password($password){
        $length = mb_strlen($password);
        $flag = true;
        if($length < 4 || $length > 12)
        {
            $flag = false;
        }
        $pattern = '/^(\d+)$/i';
        if(preg_match_all($pattern,$password))
        {
            $flag = false;
        }
        return $flag;
    }
}










