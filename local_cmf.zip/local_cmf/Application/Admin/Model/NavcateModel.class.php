<?php
namespace Admin\Model;

use  Think\Model;

class NavcateModel extends Model
{
    protected $fields = array('id','name','remark','is_main','is_del','_pk'=>'id');



}




