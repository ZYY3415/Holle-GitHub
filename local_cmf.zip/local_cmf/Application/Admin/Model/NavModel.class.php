<?php
namespace Admin\Model;

use Think\Model;

class NavModel extends Model
{
    protected $fileds = array('id','prent_id','navname','href','opentype','is_show','is_del','_pk'=>'id');




}









