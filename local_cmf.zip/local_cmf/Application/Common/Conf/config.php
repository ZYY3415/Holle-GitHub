<?php
return array(
	//'配置项'=>'配置值'
    'URL_MODEL' =>2,           //重写模式
    'URL_CASE_INSENSITIVE'  =>  true,    //URL不区分大小写

    'DB_TYPE'   => 'mysql', // 数据库类型
    'DB_HOST'   => 'localhost', // 服务器地址
    'DB_NAME'   => 'user_cmf', // 数据库名
    'DB_USER'   => 'root', // 用户名
    'DB_PWD'    => 'root', // 密码
    'DB_PORT'   => 3306, // 端口
    'DB_PREFIX' => 'cmf_', // 数据库表前缀
    'DB_CHARSET'=> 'utf8', // 字符集

    'MODULE_ALLOW_LIST'     =>  array('admin,Home'),    //允许访问的模块
    'DEFAULT_MODULE'        =>  'Admin',            // 默认模块
    
    //模板替换
    'TMPL_PARSE_STRING'  =>array(
        '__PUBLIC__'    => '/Public',
        ),
    //I函数过滤方法
    'DEFAULT_FILTER'        =>  'strip_tags,stripslashes,htmlspecialchars',
    //错误
    'LOG_RECORD'            =>  true,   // 默认不记录日志
    'LOG_TYPE'              =>  'File', // 日志记录类型 默认为文件方式
    'LOG_LEVEL'             =>  'EMERG,ALERT,CRIT,ERR,DEBUG',// 允许记录的日志级别
    'LOG_EXCEPTION_RECORD'  =>  false,    // 是否记录异常信息日志

);