<?php
//自定义加密方法
/*
 * $pwd  要加密的字符串
 * $yan  盐，使加密的字符串更加的安全
 * 加密方法  base64_encode(md5($pwd).$yan)
 */
if(!function_exists('userBase_encode'))
{
    function userBase_encode($pwd,$yan = '123456'){
         return base64_encode(md5($pwd).$yan);
    }
}

if(!function_exists('getTree'))
{
    /**
     * @param $data
     * @param int $parent
     * @param int $lenve
     * @param int $flag
     * @return array
     */
    function getTree($data, $parent = 0, $lenve = 0, $flag = 0){
        static $array =[];
        foreach($data as $key=>$value)
        {
            if(intval($value['parent_id']) == $parent)
            {
                if($value['id'] == $flag){
                    continue;
                }
                $value['lenve'] = $lenve;
                $array[] = $value;
               getTree($data,$value['id'],$lenve+1);
            }
        }
        return $array;
    }
}








