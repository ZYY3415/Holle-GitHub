<?php if (!defined('THINK_PATH')) exit();?><!doctype html >
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
    *{
        padding:0;
        margin:0;
    }
     body{
     	font-family: "Source Sans Pro",Calibri,Candara,Arial,sans-serif;
        font-size: 14px;
     }
     .nav-tabs{
     	list-style:none;
        border-bottom: 1px solid #ecf0f1;
     }
     .nav-tabs li{
     	float:left;
     }
     .nav-tabs li a{
        display:block;
     	margin-right: 2px;
	    color: #18BC9C;
        text-decoration: none;
        padding:10px 15px;
     }
     .wrap{
        padding:20px;
     }
     .active{
        background-color: #fff;
        cursor: default;
     }
     .active a{
        color:black !important;
        border: 1px solid #ecf0f1;
        border-bottom-color:transparent;
     }
     .nav-tabs>li>a:hover {
    border-color: #ecf0f1 #ecf0f1 #ecf0f1;
     }
    .nav>li>a:hover, .nav>li>a:focus {
            text-decoration: none;
            background-color: #ecf0f1;
    }
    form{
        margin-top:20px;
    }
     table{
        width:100%;
        border-color:#ecf0f1;
     }
     .ualert{
        width:200px;
        background:green;
        color:white;
        top:0;
        text-align:center;
        display:none;
        position:absolute;
        padding:5px 0;
     }
     .js-ajax-delete{
        position:relative;
     }
     .js_del{
        width:206px;
        height:110px;
        position:absolute;
        border:1px solid #666;
        z-index:999;
        background:white;
        right:10px;
        top:20px;
     }
     .sign_is_del{
        font-size:20px !important;
        color:blue !important;
     }
    </style>
    <link rel="stylesheet" href="/Public/Admin/Index/css/bootstrap.min.css" />
    <script src="/Public/Admin/Nav/jquery.js"></script>
    <script type="text/javascript">

      function ualert(title){
        var alert = $('<div class="ualert">'+title+'</div>');
        $('body').append(alert.show());
           var alert_width = $(window).width();
           var alert_height = $(window).height();
           var parent_width =alert_width + 200;
           var center = (parent_width - 200)/2 - 200;
           $('.ualert').css('left',center+'px');
           $('.ualert').animate({
               top:'50px',
               opacity:'show'
           },200,function(){
               setTimeout(function(){
                $('.ualert').animate({
                    top:0,
                    opacity:'hide'
                });
               },1500);
           });
      }

      $('.js-ajax-delete').click(function(){
            console.log(11);
            return false;
       });
    </script>
</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="/nav_cate/index.html">所有导航</a></li>
        <li><a href="/nav_cate/add.html">添加导航</a></li>
    </ul>
    <form action="/NavCate/index.html" method="post" class="margin-top-20">
        <table class="table table-hover table-bordered" border="1" rules="all">
            <thead>
            <tr>
                <th width="40">ID</th>
                <th>名称</th>
                <th width="80">主导航</th>
                <th>描述</th>
                <th width="160">操作</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                    <td>1</td>
                    <td>主导航1</td>
                    <td>是</td>
                    <td>0</td>
                    <td>
                        <a href="">菜单管理</a> |
                        <a href="/NavCate/edit/id/1.html">编辑</a> |
                        <a class="js-ajax-delete" href="/NavCate/delete/id/1.html">删除
                            <div class="js_del">
                              <i class="glyphicon glyphicon-question-sign"></i>
                              <p>确认要删除吗?</p>
                            </div>
                        </a>

                    </td>
                </tr>            </tbody>
        </table>
    </form>
</div>
<script type="text/javascript">

</script>
</body>
</html>