<?php if (!defined('THINK_PATH')) exit();?><!doctype html >
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
    *{
        padding:0;
        margin:0;
    }
     body{
     	font-family: "Source Sans Pro",Calibri,Candara,Arial,sans-serif;
        font-size: 14px;
     }
     .nav-tabs{
     	list-style:none;
        border-bottom: 1px solid #ecf0f1;
     }
     .nav-tabs li{
     	float:left;
     }
     .nav-tabs li a{
        display:block;
     	margin-right: 2px;
	    color: #18BC9C;
        text-decoration: none;
        padding:10px 15px;
     }
     .wrap{
        padding:20px;
     }
     .active{
        background-color: #fff;
        cursor: default;
     }
     .active a{
        color:black !important;
        border: 1px solid #ecf0f1;
        border-bottom-color:transparent;
     }
     .nav-tabs>li>a:hover {
    border-color: #ecf0f1 #ecf0f1 #ecf0f1;
     }
    .nav>li>a:hover, .nav>li>a:focus {
            text-decoration: none;
            background-color: #ecf0f1;
    }
    form{
        margin-top:20px;
    }
     table{
        width:100%;
        border-color:#ecf0f1;
     }
     .ualert{
        width:200px;
        background:green;
        color:white;
        top:0;
        text-align:center;
        display:none;
        position:absolute;
        padding:5px 0;
     }
    </style>
    <link rel="stylesheet" href="/Public/Admin/Index/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/Public/del/css/xcConfirm.css"/>
    <script src="/Public/Admin/Nav/jquery.js"></script>
    <script src="/Public/del/js/xcConfirm.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
    
      function ualert(title){
        var alert = $('<div class="ualert">'+title+'</div>');
        $('body').append(alert.show());
           var alert_width = $(window).width();
           var alert_height = $(window).height();
           var parent_width =alert_width + 200;
           var center = (parent_width - 200)/2 - 200;
           $('.ualert').css('left',center+'px');
           $('.ualert').animate({
               top:'50px',
               opacity:'show'
           },200,function(){
               setTimeout(function(){
                $('.ualert').animate({
                    top:0,
                    opacity:'hide'
                });
               },1500);
           });
      }
    
    </script>
</head>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li><a href="<?php echo U('nav_cate/index');?>">导航管理</a></li>
        <li class="active"><a href="<?php echo U('nav_cate/add');?>">导航添加</a></li>
        <!--<li><a  href="<?php echo U('nav/edit');?>" >导航编辑</a></li>-->
    </ul>
    <form method="post" name="js-ajax-from" class="form-horizontal js-ajax-form margin-top-20">
        <div class="form-group">
            <label class="col-sm-2 control-label"><span class="form-required">*</span>名称:</label>
            <div class="col-md-6 col-sm-10">
                <input type="text" class="form-control" name="name" value="">
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">备注:</label>
            <div class="col-md-6 col-sm-10">
                <textarea class="form-control" name="remark" rows="5" cols="57"></textarea>
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-2 control-label">主菜单:</label>
            <div class="col-md-6 col-sm-10">
                <div class="checkbox">
                    <label>
                        <input  type="checkbox" name="is_main" value="0" >
                    </label>
                </div>

            </div>
        </div>

        <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-primary js-ajax-submit">保存</button>
            <a class="btn btn-default" href="<?php echo U('NavCate/index');?>">返回</a>
        </div>
    </form>
</div>
<script type="text/javascript">
   $('.js-ajax-submit').click(function(){
         var $flag = true;
          if(!$('input[name="name"]').val()){
               $flag = false;
                ualert('用户名必须填写！');
           }
           var data =[];
           data['name'] = $('input[name="name"]').val();
           data['remark'] = $('textarea').val();
           data['is_main'] = $('input[name="is_main"]').val();
           if($flag){
             $.post('<?php echo U("NavCate/add");?>',
               {
                name:data['name'],
                remark:data['remark'],
                is_main:data['is_main']
               },
               function(message){
                   if(message.code != 1){
                     ualert(message.msg);
                   }else{
                     ualert(message.msg);
                     setTimeout(function(){
                     location.href = '<?php echo U("Nav_cate/index");?>';
                     },2500);
                     
                   }
    
               }
            );
           }
           return false;
   });

</script>
</body>
</html