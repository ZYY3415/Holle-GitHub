<?php if (!defined('THINK_PATH')) exit();?><admintpl file="header" />
</head>
<body>
	<div class="wrap js-check-wrap">
		<ul class="nav nav-tabs">
			<li class="active"><a href="<?php echo U('nav/index');?>"><?php echo L('ADMIN_NAV_INDEX');?></a></li>
			<li><a href="<?php echo U('nav/add',array('cid'=>$navcid));?>"><?php echo L('ADMIN_NAV_ADD');?></a></li>
		</ul>

		<form class="well form-search" id="mainform" action="<?php echo U('nav/index');?>" method="post">
			<select id="navcid_select" name="cid">
				<?php if(is_array($navcats)): foreach($navcats as $key=>$vo): $navcid_selected=$navcid==$vo['navcid']?"selected":""; ?>
				<option value="<?php echo ($vo["navcid"]); ?>"<?php echo ($navcid_selected); ?>><?php echo ($vo["name"]); ?></option><?php endforeach; endif; ?>
			</select>
		</form>
		<form class="js-ajax-form" action="<?php echo U('nav/listorders');?>" method="post">
			<div class="table-actions">
				<button type="submit" class="btn btn-primary btn-small js-ajax-submit"><?php echo L('SORT');?></button>
			</div>
			<table class="table table-hover table-bordered table-list">
				<thead>
					<tr>
						<th width="50"><?php echo L('SORT');?></th>
						<th width="50">ID</th>
						<th><?php echo L('NAVIGATION_NAME');?></th>
						<th width="80"><?php echo L('STATUS');?></th>
						<th width="180"><?php echo L('ACTIONS');?></th>
					</tr>
				</thead>
				<tbody>
				<?php echo ($categorys); ?>
				</tbody>
				<tfoot>
					<tr>
						<th width="50"><?php echo L('SORT');?></th>
						<th width="50">ID</th>
						<th><?php echo L('NAVIGATION_NAME');?></th>
						<th width="80"><?php echo L('STATUS');?></th>
						<th width="180"><?php echo L('ACTIONS');?></th>
					</tr>
				</tfoot>
			</table>
			<div class="table-actions">
				<button type="submit" class="btn btn-primary btn-small js-ajax-submit"><?php echo L('SORT');?></button>
			</div>
		</form>
	</div>
	<script src="/Public/js/common.js"></script>
	<script>
		$(function() {

			$("#navcid_select").change(function() {
				$("#mainform").submit();
			});

		});
	</script>
</body>
</html>