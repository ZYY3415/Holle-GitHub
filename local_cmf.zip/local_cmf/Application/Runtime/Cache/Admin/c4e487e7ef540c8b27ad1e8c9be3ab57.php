<?php if (!defined('THINK_PATH')) exit();?><!doctype html >
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
    *{
        padding:0;
        margin:0;
    }
     body{
     	font-family: "Source Sans Pro",Calibri,Candara,Arial,sans-serif;
        font-size: 14px;
     }
     .nav-tabs{
     	list-style:none;
        overflow:hidden;
        border-bottom: 1px solid #ecf0f1;
     }
     .nav-tabs li{
     	float:left;
     }
     .nav-tabs li a{
        display:block;
     	margin-right: 2px;
	    color: #18BC9C;
        text-decoration: none;
        padding:10px 15px;
     }
     .wrap{
        padding:20px;
     }
     .active{
        background-color: #fff;
        cursor: default;
     }
     .active a{
        color:black !important;
        border: 1px solid #ecf0f1;
        border-bottom-color:transparent;
     }
     .nav-tabs>li>a:hover {
    border-color: #ecf0f1 #ecf0f1 #ecf0f1;
     }
    .nav>li>a:hover, .nav>li>a:focus {
            text-decoration: none;
            background-color: #ecf0f1;
    }
    form{
        margin-top:20px;
    }
     table{
        width:100%;
        border-color:#ecf0f1;
     }
     .ualert{
        width:200px;
        background:green;
        color:white;
        text-align:center;
        display:none;
        position:absolute;
        left:100px;
        top:200px;
        padding:5px 0;
     }
    </style>
    <link rel="stylesheet" href="/Public/Admin/Index/css/bootstrap.min.css" />
    <script src="/Public/Admin/Nav/jquery.js"></script>
</head>
<body>
	<div class="wrap js-check-wrap container-fluid">
		<ul class="nav nav-tabs">
			<li class="active"><a href="<?php echo U('navlist');?>">菜单管理</a></li>
			<li><a href="<?php echo U('addnav');?>">添加菜单</a></li>
		</ul>
		<form class="js-ajax-form" action="<?php echo U('nav/listorders');?>" method="post">
			<div class="table-actions">
				<button type="submit" class="btn btn-primary btn-small js-ajax-submit">排序</button>
			</div>
			<table class="table table-hover table-bordered table-list">
				<thead>
					<tr>
						<th width="50">排序</th>
						<th width="50">ID</th>
						<th>菜单名称</th>
						<th width="80">状态</th>
						<th width="180">操作</th>
					</tr>
				</thead>
				<tbody>
				    <?php if(is_array($navdata)): $i = 0; $__LIST__ = $navdata;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				        <td>0</td>
				        <td><?php echo ($vo["id"]); ?></td>
				        <td>
				            <?php if($vo["lenve"] == 0): echo ($vo["navname"]); ?>
				              <?php else: ?>
				             <?php echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",$vo['lenve']);?>└─<?php echo ($vo["navname"]); endif; ?>
				        </td>
				        <td>
					         <?php if($vo["is_show"] == 1): ?>显示
					         <?php else: ?>不显示<?php endif; ?>
				        </td>
				        <td><a href="./editnav/id/<?php echo ($vo["id"]); ?>">编辑</a> | <a class="js-ajax-delete" href="./delnav/id/<?php echo ($vo["id"]); ?>">删除</a></td>
				     </tr><?php endforeach; endif; else: echo "" ;endif; ?>
				</tbody>
				
			</table>
		</form>
	</div>

</body>
</html>