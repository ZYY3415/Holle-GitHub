<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="/Public/Admin/header/theme.min.css" rel="stylesheet">
    <link href="/Public/Admin/header/simplebootadmin.css" rel="stylesheet">
    <link href="/Public/Admin/header/default.css" rel="stylesheet" />
    <link href="/Public/Admin/header/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/Public/Admin/header/font-awesome-ie7.min.css">
	<![endif]-->

</head>
<body>
	<div class="wrap js-check-wrap">
		<ul class="nav nav-tabs">
			<li class="active"><a href="<?php echo U('navlist');?>">菜单管理</a></li>
			<li><a href="<?php echo U('addnav');?>">添加菜单</a></li>
		</ul>
		<form class="js-ajax-form" action="<?php echo U('nav/listorders');?>" method="post">
			<div class="table-actions">
				<button type="submit" class="btn btn-primary btn-small js-ajax-submit">排序</button>
			</div>
			<table class="table table-hover table-bordered table-list">
				<thead>
					<tr>
						<th width="50">排序</th>
						<th width="50">ID</th>
						<th>菜单名称</th>
						<th width="80">状态</th>
						<th width="180">操作</th>
					</tr>
				</thead>
				<tbody>
				    <?php if(is_array($navdata)): $i = 0; $__LIST__ = $navdata;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
				        <td>0</td>
				        <td><?php echo ($vo["id"]); ?></td>
				        <td>
				            <?php if($vo["lenve"] == 0): echo ($vo["navname"]); ?>
				              <?php else: ?>
				             <?php echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",$vo['lenve']);?>└─<?php echo ($vo["navname"]); endif; ?>
				        </td>
				        <td>
					         <?php if($vo["is_show"] == 1): ?>显示
					         <?php else: ?>不显示<?php endif; ?>
				        </td>
				        <td><a href="./editnav/id/<?php echo ($vo["id"]); ?>">编辑</a> | <a class="js-ajax-delete" href="./delnav/id/<?php echo ($vo["id"]); ?>">删除</a></td>
				     </tr><?php endforeach; endif; else: echo "" ;endif; ?>
				</tbody>
				
			</table>
            <?php echo ($page); ?>
		</form>
	</div>
	<script src="/Public/js/common.js"></script>
	<script>
		$(function() {

			$("#navcid_select").change(function() {
				$("#mainform").submit();
			});

		});
	</script>
</body>
</html>