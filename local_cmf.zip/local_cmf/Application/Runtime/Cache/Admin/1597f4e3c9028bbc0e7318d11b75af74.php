<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="/Public/Admin/header/theme.min.css" rel="stylesheet">
    <link href="/Public/Admin/header/simplebootadmin.css" rel="stylesheet">
    <link href="/Public/Admin/header/default.css" rel="stylesheet" />
    <link href="/Public/Admin/header/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/Public/Admin/header/font-awesome-ie7.min.css">
	<![endif]-->

<style>
    input,select{
        color:black !important;
    }
    .error
    {
        color:rgb(245, 176, 67);
        font-weight:bold;
    }
</style>
</head>
<body>
<div class="wrap">
    <ul class="nav nav-tabs">
        <li><a href="<?php echo U('Navlist');?>" style="color:#2fa4e7;font-weight:blod;">菜单管理</a></li>
        <li><a href="<?php echo U('addnav');?>" style="color:#2fa4e7;font-weight:blod;">添加菜单</a></li>
        <li class="active"><a href="<?php echo U('editnav');?>" style="color:black;">编辑菜单</a></li>
    </ul>
    <form method="post" class="form-horizontal js-ajax-form" action="<?php echo U('editnav');?>">
    <input type="hidden" name="id" value="<?php echo ($navinfo["id"]); ?>"  />
        <fieldset>
            <div class="control-group">
                <label class="control-label">父级</label>
                <div class="controls">
                    <select name="parentid">
                         <option value="0">/</option>
                        <?php if(is_array($navdata)): $i = 0; $__LIST__ = $navdata;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if($vo["lenve"] == 0): ?><option value="<?php echo ($vo["id"]); ?>" <?php if(($vo["id"]) == $navinfo["parent_id"]): ?>selected<?php endif; ?> >
                                <?php echo ($vo["navname"]); ?></option>
                                <?php else: ?>
                                <option value="<?php echo ($vo["id"]); ?>" ><?php echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",$vo['lenve']);?>└─<?php echo ($vo["navname"]); ?></option><?php endif; endforeach; endif; else: echo "" ;endif; ?>
                    </select>
                </div>
            </div>
            <div class="control-group">
                <label class="control-label">标签名</label>
                <div class="controls">
                    <input type="text" name="label" value="<?php echo ($navinfo["navname"]); ?>"><span class="form-required">*</span>
                </div>
            </div>
            <div class="control-group">
                <label class="control-label">链接</label>
                <div class="controls">
                    <input type="radio" name="nav" checked id="outlink_radio">
                    <input type="text" name="href" class="href" id="outlink_input" value="http://">
                    <input type="radio" name="nav"  class="href" id="selecturl_radio">
                    <select name="href" id="selecthref">
                        <option value="<?php echo base64_encode('home');?>">首页</option>
                        <?php if(is_array($navs)): foreach($navs as $key=>$vo): endforeach; endif; ?>
                    </select>
                </div>
            </div>
            <div class="control-group">
                <label class="control-label">打开方式</label>
                <div class="controls">
                    <select name="target">
                        <option value="">默认</option>
                        <option value="_blank">新窗口</option>
                    </select>
                </div>
            </div>

            <div class="control-group">
                <label class="control-label">状态</label>
                <div class="controls">
                    <select name="status">
                        <option value="1" selected>显示</option>
                        <option value="0">隐藏</option>
                    </select>
                </div>
            </div>
        </fieldset>
        <div class="form-actions">
            <button type="submit" class="btn btn-primary js-ajax-submit" style="background-color:#2fa4e7;">修改</button>
            <a class="btn" href="javascript:history.back(-1);"style="background-color:#fff;color:black;">返回</a>
            <span class="error"></span>
        </div>
    </form>
</div>
<script src="/Public/Admin/Nav/jquery.js"></script>
<script>
    $('.js-ajax-form').submit(function(){
        $.post(
                './addnav_post',
                {
                	id:$('input[type="hidden"]').val(),
                    parent_id:$('select[name="parentid"]').val(),
                    navname:$('input[name="label"]').val(),
                    href:$('.href').val(),
                    opentype:$('select[namee="target"]').val(),
                    is_show:$('select[name="status"]').val()
                },
                function(data){
                    $('.error').html(data.message);
                }
        );
        return false;
    });

</script>
</body>
</html>