<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
	<head>
		<meta charset="UTF-8" />
		<title>ThinkCMF <?php echo L('ADMIN_CENTER');?></title>
		<meta http-equiv="X-UA-Compatible" content="chrome=1,IE=edge" />
		<meta name="renderer" content="webkit|ie-comp|ie-stand">
		<meta name="robots" content="noindex,nofollow">
		<link href="/Public/Admin/Login/css/admin_login.css" rel="stylesheet" />
		<style>
			#login_btn_wraper{
				text-align: center;
			}
			#login_btn_wraper .tips_success{
				color:#fff;
			}
			#login_btn_wraper .tips_error{
				color:#DFC05D;
			}
			#login_btn_wraper button:focus{outline:none;}
			.error{
				color:#DFC05D;
			    text-align:center;
			}
		</style>
		<script>
			if (window.parent !== window.self) {
					document.write = '';
					window.parent.location.href = window.self.location.href;
					setTimeout(function () {
							document.body.innerHTML = '';
					}, 0);
			}
		</script>
		
	</head>
<body>
	<div class="wrap">
		<h1><a>ThinkCMF</a></h1>
		<form method="post" name="login" action="<?php echo U('login');?>" autoComplete="off" class="js-ajax-form">
			<div class="login">
				<ul>
					<li>
						<input class="input" id="js-admin-name" name="username" type="text" placeholder="用户名" title="用户名" value="" />
					</li>
					<li>
						<input class="input" id="admin_pwd" type="password" name="password" placeholder="密码" title="密码" />
					</li>
					<li class="verifycode-wrapper">
						<img src="" title='验证码'>
					</li>
					<li>
						<input class="input verify" type="text" name="verify" placeholder="请输入验证码" />
					</li>
				</ul>
				<div id="login_btn_wraper">
					<button type="button" name="submit" class="btn js-ajax-submit">提交</button>
				</div>
				<div class="error">
				</div>
			</div>
		</form>
	</div>

<script>
var GV = {
    ROOT: "/",
    WEB_ROOT: "__WEB_ROOT__/",
    JS_ROOT: "public/js/"
};
</script>
<script src="/Public/Admin/Login/js/jquery.js"></script>
<script src="/Public/Admin/Login/js/login.js"></script>
</body>
</html>