<?php if (!defined('THINK_PATH')) exit();?><!doctype html >
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style type="text/css">
    *{
        padding:0;
        margin:0;
    }
     body{
     	font-family: "Source Sans Pro",Calibri,Candara,Arial,sans-serif;
        font-size: 14px;
     }
     .nav-tabs{
     	list-style:none;
        border-bottom: 1px solid #ecf0f1;
     }
     .nav-tabs li{
     	float:left;
     }
     .nav-tabs li a{
        display:block;
     	margin-right: 2px;
	    color: #18BC9C;
        text-decoration: none;
        padding:10px 15px;
     }
     .wrap{
        padding:20px;
     }
     .active{
        background-color: #fff;
        cursor: default;
     }
     .active a{
        color:black !important;
        border: 1px solid #ecf0f1;
        border-bottom-color:transparent;
     }
     .nav-tabs>li>a:hover {
    border-color: #ecf0f1 #ecf0f1 #ecf0f1;
     }
    .nav>li>a:hover, .nav>li>a:focus {
            text-decoration: none;
            background-color: #ecf0f1;
    }
    form{
        margin-top:20px;
    }
     table{
        width:100%;
        border-color:#ecf0f1;
     }
     .ualert{
        width:200px;
        background:green;
        color:white;
        top:0;
        text-align:center;
        display:none;
        position:absolute;
        padding:5px 0;
     }
    </style>
    <link rel="stylesheet" href="/Public/Admin/Index/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="/Public/del/css/xcConfirm.css"/>
    <script src="/Public/Admin/Nav/jquery.js"></script>
    <script src="/Public/del/js/xcConfirm.js" type="text/javascript" charset="utf-8"></script>
    <script type="text/javascript">
    
      function ualert(title){
        var alert = $('<div class="ualert">'+title+'</div>');
        $('body').append(alert.show());
           var alert_width = $(window).width();
           var alert_height = $(window).height();
           var parent_width =alert_width + 200;
           var center = (parent_width - 200)/2 - 200;
           $('.ualert').css('left',center+'px');
           $('.ualert').animate({
               top:'50px',
               opacity:'show'
           },200,function(){
               setTimeout(function(){
                $('.ualert').animate({
                    top:0,
                    opacity:'hide'
                });
               },1500);
           });
      }
    
    </script>
</head>
<body>
	<div class="wrap">
		<ul class="nav nav-tabs">
			<li><a href="<?php echo U('Navlist');?>" style="color:#2fa4e7;font-weight:blod;">菜单管理</a></li>
			<li class="active"><a href="<?php echo U('addnav');?>" style="color:black;">添加菜单</a></li>
		</ul>
		<form method="post" class="form-horizontal js-ajax-form" action="<?php echo U('add_nav');?>">
		<div class="fieldset">
				<div class="form-group">
					<label class="control-label col-sm-2">父级:</label>
					    <div class="col-md-6 col-sm-10">
							<select name="parentid" class="form-control ">
								<option value="0">/</option>
	                                <?php if(is_array($navdata)): $i = 0; $__LIST__ = $navdata;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if($vo["lenve"] == 0): ?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["navname"]); ?></option>
	                                        <?php else: ?>
	                                        <option value="<?php echo ($vo["id"]); ?>"><?php echo str_repeat("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",$vo['lenve']);?>└─<?php echo ($vo["navname"]); ?></option><?php endif; endforeach; endif; else: echo "" ;endif; ?>
							</select>
						</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">标签名:</label>
					<div class="col-md-6 col-sm-10">
						<input type="text" class="form-control" name="label" value=""><span class="form-required">*</span>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">链接</label>
					<div class="col-md-6 col-sm-10">
							<input type="radio" name="nav" id="outlink_radio">
							<input type="text" class="form-control" name="href" class="href" id="outlink_input" value="http://">
						    <input type="radio" class="radio" name="nav"  class="href" id="selecturl_radio">
						    <select name="href" class="form-control valid" id="selecthref">
								<option value="<?php echo base64_encode('home');?>">首页</option>
								<?php if(is_array($navs)): foreach($navs as $key=>$vo): endforeach; endif; ?>
						    </select>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-2">打开方式</label>
					<div class="col-md-6 col-sm-10">
						<select name="target" class="form-control">
							<option value="">默认</option>
							<option value="_blank">新窗口</option>
						</select>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-2">状态</label>
					<div class="col-md-6 col-sm-10">
						<select name="status" class="form-control">
							<option value="1">显示</option>
							<option value="0">隐藏</option>
						</select>
					</div>
				</div>
			</fieldset>
			<div class="form-actions">
				<button type="submit" class="btn btn-primary js-ajax-submit" style="background-color:#2fa4e7;">添加</button>
				<a class="btn" href="javascript:history.back(-1);"style="background-color:#fff;color:black;">返回</a>
                 <span class="error"></span>
			</div>
		</div>
		</form>
	</div>
    <script>
     $('.js-ajax-form').submit(function(){
         $.post(
                 './addnav_post',
         {
                     parent_id:$('select[name="parentid"]').val(),
                     navname:$('input[name="label"]').val(),
                     href:$('.href').val(),
                     opentype:$('select[namee="target"]').val(),
                     is_show:$('select[name="status"]').val()
         },
         function(data){
             $('.error').html(data.message);
         }
         );
         return false;
     });

    </script>
</body>
</html>