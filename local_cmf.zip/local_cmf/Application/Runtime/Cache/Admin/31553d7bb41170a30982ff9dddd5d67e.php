<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="/Public/Admin/header/theme.min.css" rel="stylesheet">
    <link href="/Public/Admin/header/simplebootadmin.css" rel="stylesheet">
    <link href="/Public/Admin/header/default.css" rel="stylesheet" />
    <link href="/Public/Admin/header/font-awesome.min.css"  rel="stylesheet" type="text/css">
    <style>
		form .input-order{margin-bottom: 0px;padding:3px;width:40px;}
		.table-actions{margin-top: 5px; margin-bottom: 5px;padding:0px;}
		.table-list{margin-bottom: 0px;}
	</style>
	<!--[if IE 7]>
	<link rel="stylesheet" href="/Public/Admin/header/font-awesome-ie7.min.css">
	<![endif]-->

<style>
     input,select{
        color:black !important;
    }
</style>
</head>
<body>
	<div class="wrap">
		<ul class="nav nav-tabs">
			<li><a href="<?php echo U('menulist');?>">菜单管理</a></li>
			<li class="active"><a href="<?php echo U('addmenu');?>">添加菜单</a></li>
		</ul>
		<form method="post" class="form-horizontal js-ajax-form" action="<?php echo U('add_post');?>">
			<fieldset>
				<div class="control-group">
					<label class="control-label">父级</label>
					<div class="controls">
						<select name="parentid">
							<option value="0">/</option>

						</select>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label">标签名</label>
					<div class="controls">
						<input type="text" name="label" value=""><span class="form-required">*</span>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label">链接</label>
					<div class="controls">
						<input type="radio" name="nav" id="outlink_radio">
						<input type="text" name="href" id="outlink_input" value="http://">
						<input type="radio" name="nav" id="selecturl_radio">
						<select name="href" id="selecthref">
							<option value="<?php echo base64_encode('home');?>">首页</option>
							<?php if(is_array($navs)): foreach($navs as $key=>$vo): ?><optgroup label="<?php echo ($vo["name"]); ?>">

								</optgroup><?php endforeach; endif; ?>
						</select>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label">打开方式</label>
					<div class="controls">
						<select name="target">
							<option value="">默认</option>
							<option value="_blank">新窗口</option>
						</select>
					</div>
				</div>

				<div class="control-group">
					<label class="control-label">状态</label>
					<div class="controls">
						<select name="status">
							<option value="1">显示</option>
							<option value="0">隐藏</option>
						</select>
					</div>
				</div>
			</fieldset>
			<div class="form-actions">
				<button type="submit" class="btn btn-primary js-ajax-submit">添加</button>
				<a class="btn" href="javascript:history.back(-1);">返回</a>
			</div>
		</form>
	</div>

</body>
</html>