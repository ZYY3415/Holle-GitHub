<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title>后台首页</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="/Public/layui/css/layui.css">
  <link rel="stylesheet" type="text/css" href="/Public/Admin/Index/css/index.css">

</head>
<body>
<div class="container-fluid">
<div class="header">
         <div class="left"><a href="javascript:">Thinkcmf</a></div>
         <div class="center">
           <ul class="header_nav">
               <li><a style="cursor:pointer;" class="one">首页</a></li>
           </ul>
         </div>
         <div class="right"></div>
</div>
</div>
<div class="container-fluid content">
  <div class="index_left">
       <div class="nav_header">
       </div>
       <div class="nav">
          <ul>
             <li class="toggle_li">
                 <a href="javascript:">
                     <i class="glyphicon glyphicon-cog"></i><span>设置</span>
                     <b>&gt;</b>
                 </a>
                 <ul>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>网站信息</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>网站配置</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>模板管理</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav('<?php echo U('nav_cate/index');?>','导航管理')" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>导航管理</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav('<?php echo U('hdp/index');?>','幻灯片管理')" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>幻灯片管理</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>友情链接</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>URL美化</span>
                             </a>
                        </li>
                 </ul>
             </li>
             <li class="toggle_li">
                 <a href="javascript:opennav()">
                     <i class="glyphicon glyphicon-user"></i><span>用户管理</span>
                     <b>&gt;</b>
                  </a>
                     <ul>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>管理组</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>用户组</span>
                                 </a>
                            </li>
                      </ul>
             </li>
             <li class="toggle_li">
                 <a href="javascript:opennav()">
                     <i class="glyphicon glyphicon-cloud"></i><span>插件管理</span>
                     <b>&gt;</b>
                 </a>
                     <ul>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>钩子管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>所有插件</span>
                                 </a>
                            </li>
                      </ul>
             </li>
             <li class="toggle_li">
                 <a href="javascript:opennav()">
                     <i class="glyphicon glyphicon-list"></i><span>门户管理</span>
                     <b>&gt;</b>
                 </a>
                     <ul>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>文章管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>分类管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>用户管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>文章标签</span>
                                 </a>
                            </li>
                      </ul>
             </li>
          </ul>
       </div>
  </div>
   <div class="index_right">
      <div class="iframe">
         <iframe scrolling="yes" width="85%"  height="100%" frameborder="0" src="<?php echo U('indexrgt');?>">
         </iframe>
       </div>
   </div>
</div>
    <div class="paropen">
    </div>
</body>
<script type="text/javascript" src="/Public/admin/Nav/jquery.js"></script>
<script type="text/javascript" src="/Public/layui/layui.all.js"></script>
<script type="text/javascript" src="/Public/Admin/Index/js/index.js"></script>

</html>