<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
	<title>后台首页</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="https://cdn.bootcss.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
      *{
        padding:0;
        margin:0;
      }
      a{
         text-decoration: none;
         color:black;
      }
      body{
        font-family: 'Microsoft Yahei',verdana;
        font-size:14px;
        line-height:30px;
        color: #010101;
        width:100%;
        height:auto;
        overflow:hidden;
      }
      .container-fluid{
        padding:0;
      }
      .header{
        width:100%;
        height:48px;
        background-color:#2c3e50;
        text-align:center;
        line-height:48px;
        color:#fff;
        font-size:14px;
        position:relative;
      }
      .header .left{
         width:200px;
         font-size:16px;
      }
      .header .left a{
        color:white;
      }
      .header .left a:hover{
        color: #18BC9C;
        text-decoration: none;
      }
      .header div{
         float:left;
      }
      .header .center ul{
          list-style:none;
      }
      .header .center ul li{
        float:left;
        width:101px;
        height:48px;
       line-height:48px;
      }
      .header .center ul li a{
        display:block;
        width:101px;
        text-decoration:none;
        color:white;
        padding:14px 0;
        height:48px;
        line-height:24px;
      }
      .header .right{
        width:200px;
        float:right;
        height:48px;
      }
      .nav{
        position:absolute;
        left:0;
        top:0px;
        bottom:0;
        width:200px;
        height:661px;
        background-color: #f2f2f2;
        border-right: 1px solid #ccc;
        float:left;
      }
      .nav ul li a{
            display:block;
            height: 38px;
            padding: 0 16px 0 17px;
            font-size: 13px;
            line-height: 36px;
            color: #585858;
            text-decoration: none;
            text-shadow: none !important;
            background-color: #f9f9f9;
      }
      .nav ul{
        list-style:none;
      }
      .nav ul li{
        border: 0;
        border-top: 1px solid #fcfcfc;
        border-bottom: 1px solid #e5e5e5;
      }
      .nav .toggle_li ul{
         display:none;
      }
      .nav li.toggle_li a:hover{
          background-color:#fff;
          color:black;
      }
      .nav .toggle_li b{
       display:block;
       float:right;
       font-size:15px;
      }
      .open{
         border-bottom: 1px solid #e5e5e5;
      }
      .open>a>span{
        color:black;
      }
      .glyphicon{
        position:relative;
        top:5px;
        font-size:18px;
        margin-right:10px;
      }
      .glyphicon-triangle-right{
         width:1px;
         font-size:4px;
         position:relative;
         top:1px;
         margin-right:15px;
      }
      .childa{
        padding:7px 0 8px 37px !important;
        line-height:28px !important;
      }
      .one{
        background:#1a242f;
      }
      .active{
        position:relative;
        cursor:pointer;
      }
      .closehv{
         position:absolute;
         top:-5px;
         right:4px;
         font-size:1px;
         display:none;

      }
      .active:hover .closehv{
          display:block;
      }
      .active .closehv:hover{
        color:#ed7669;
      }
      .index_right{
        width:100%;
        margin-left:200px;
        height:661px;
        float:left;
      }
      .content{
        position:relative;
        width:100%;
        height:661px;
      }
      .index_right .iframe{
        height:661px;
      }
    </style>
</head>
<body>
<div class="container-fluid">
<div class="header">
         <div class="left"><a href="javascript:">Thinkcmf</a></div>
         <div class="center">
           <ul class="header_nav">
               <li><a style="cursor:pointer;" class="one">首页</a></li>
           </ul>
         </div>
         <div class="right"></div>
</div>
</div>
<div class="container-fluid content">
  <div class="index_left">
       <div class="nav_header">
       </div>
       <div class="nav">
          <ul>
             <li class="toggle_li">
                 <a href="javascript:">
                     <i class="glyphicon glyphicon-cog"></i><span>设置</span>
                     <b>&gt;</b>
                 </a>
                 <ul>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>网站信息</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>网站配置</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>模板管理</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav('<?php echo U('nav_cate/index');?>','导航管理')" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>导航管理</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav('<?php echo U('hdp/index');?>','幻灯片管理')" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>幻灯片管理</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>友情链接</span>
                             </a>
                        </li>
                        <li>
                            <a href="javascript:opennav()" class="childa">
                               <i class="glyphicon glyphicon-triangle-right"></i><span>URL美化</span>
                             </a>
                        </li>
                 </ul>
             </li>
             <li class="toggle_li">
                 <a href="javascript:opennav()">
                     <i class="glyphicon glyphicon-user"></i><span>用户管理</span>
                     <b>&gt;</b>
                  </a>
                     <ul>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>管理组</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>用户组</span>
                                 </a>
                            </li>
                      </ul>
             </li>
             <li class="toggle_li">
                 <a href="javascript:opennav()">
                     <i class="glyphicon glyphicon-cloud"></i><span>插件管理</span>
                     <b>&gt;</b>
                 </a>
                     <ul>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>钩子管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>所有插件</span>
                                 </a>
                            </li>
                      </ul>
             </li>
             <li class="toggle_li">
                 <a href="javascript:opennav()">
                     <i class="glyphicon glyphicon-list"></i><span>门户管理</span>
                     <b>&gt;</b>
                 </a>
                     <ul>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>文章管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>分类管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>用户管理</span>
                                 </a>
                            </li>
                            <li>
                                <a href="javascript:opennav()" class="childa">
                                   <i class="glyphicon glyphicon-triangle-right"></i><span>文章标签</span>
                                 </a>
                            </li>
                      </ul>
             </li>
          </ul>
       </div>
  </div>
   <div class="index_right">
      <div class="iframe">
         <iframe scrolling="yes" width="85%"  height="100%" frameborder="0" src="<?php echo U('indexrgt');?>">
         </iframe>
       </div>
   </div>
</div>
</body>
<script type="text/javascript" src="/Public/admin/Index/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript">
//侧边导航下拉
$('.toggle_li>a').click(function(){
   if($(this).parent().children('ul')){
      $(this).parent().children('ul').slideToggle('fast',function(){
          $(this).parent().toggleClass('open');
      });
      
   }
});
//in_array  判断一个数是否在数组中  是返回True   否则返回undefined
function in_array(array,text){
      for(var i in array){
        if(array[i] == text){
            return true;
        }else{
           continue;
        }
      }
  }
//点击右侧菜单,在顶部生成一个菜单按钮，并生成一个iframe 标签，插入到.iframe里  
function opennav(url,title){
    var array = $('.header_nav li a').get();
    var attr =new Array();
        for(var i in array){
            attr.push(array[i].innerHTML);
        }
        //如果点击的右侧菜单，上方有则不执行   
         if(title !=undefined && in_array(attr,title) == undefined){
            $('.header_nav li a').removeClass('one');
             //顶部添加菜单
             //'<li class="active"><a class="one">'+title+'</a><span class="closehv" title="点击关闭">×</span></li>'
            var element = $('.header_nav li:first').clone(true).addClass('active');
            element.children('a').addClass('one');
            element.append('<span class="closehv" onclick="closehv(this)" title="点击关闭">×</span>');
            element.appendTo('.header_nav');
            element.siblings().children('a').removeClass('one');
            element.children('a').html(title);

            //拷贝 irame 第一个标签并插入到 .iframe 中
            $('.iframe').children().eq(0).clone().attr('src',url).appendTo($('.iframe').eq(0)).css('display','block').siblings().css('display','none');
        }else if(title !=undefined && in_array(attr,title) != undefined){
              for(var i=0,length=$('.active').length;i<length;i++){
                    if($('.active').eq(i).children('a').html() == title){
                       var index = $('.active').eq(i).index();
                    }
              }
              $('.header_nav li').eq(index).siblings().children('a').removeClass('one');
              $('.header_nav li').eq(index).children('a').addClass('one');
              $('.iframe iframe').eq(index).show();
              $('.iframe iframe').eq(index).siblings().hide();
        }
  }

  //顶部菜单的切换
  $('.header_nav li').click(function(){
    $(this).children('a').addClass('one');
    $(this).siblings().children('a').removeClass('one');
    var li = $(this).parent().children();
    var index = $(this).index();
    
     //点击切换显示对应的iframe 标签隐藏其他兄弟标签
   $('.iframe').children().eq(index).show().siblings().hide();
  });
  //点击菜单栏中小图标
  function closehv(te){
     var index = $(te).parent().index();
     $('.header_nav li').eq(index).remove();
     $('.iframe iframe').eq(index).remove();
     $('.header_nav li').eq(index - 1).children('a').addClass('one');
     $('.iframe iframe').eq(index - 1).show();
  }

  $(window).resize(function(){
       var parent_width = $(window).width();
     $('iframe').css('width',parent_width -200);
   });

</script>
</html>