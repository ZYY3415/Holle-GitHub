<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh_CN" style="overflow: hidden;">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta charset="utf-8">
    <title>ThinkCMF</title>

    <meta name="description" content="This is page-header (.page-header &gt; h1)">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="/Public/Admin/Index/css/bootstrap.min.css" rel="stylesheet">
    <link href="/Public/Admin/Index/css/simplebootadmin.css" rel="stylesheet">
    <link href="/Public/Admin/Index/css/font-awesome.min.css?page=index" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/Public/Admin/Index/css/simplebootadminindex.min.css">
    <style>
        /*-----------------导航hack--------------------*/
        .nav-list > li.open {
            position: relative;
        }

        .nav-list > li.open .back {
            display: none;
        }

        .nav-list > li.open .normal {
            display: inline-block !important;
        }

        .nav-list > li.open a {
            padding-left: 7px;
        }

        .nav-list > li .submenu > li > a {
            background: #fff;
        }

        .nav-list > li .submenu > li a > [class*="fa-"]:first-child {
            left: 20px;
        }

        .nav-list > li ul.submenu ul.submenu > li a > [class*="fa-"]:first-child {
            left: 30px;
        }
        .container-fluid{
            background-color:#2c3e50;
            }
        /*----------------导航hack--------------------*/
    </style>

    <script>
        //全局变量
        var GV = {
            HOST: "<?php echo ($_SERVER['HTTP_HOST']); ?>",
            ROOT: "/",
            WEB_ROOT: "__WEB_ROOT__/",
            JS_ROOT: "static/js/"
        };
    </script>
    <?php $submenus=$menus; ?>

    <?php function getsubmenu($submenus){ ?>
    <?php if(!empty($submenus)): foreach($submenus as $menu){ ?>
        <li>
            <?php $menu_name=lang($menu['lang']); $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name; ?>
            <?php if(empty($menu['items'])){ ?>
            <a href="javascript:openapp('<?php echo ($menu["url"]); ?>','<?php echo ($menu["id"]); ?>','<?php echo ($menu_name); ?>',true);">
                <i class="fa fa-<?php echo ((isset($menu["icon"]) && ($menu["icon"] !== ""))?($menu["icon"]):'desktop'); ?>"></i>
                <span class="menu-text"> <?php echo ($menu_name); ?> </span>
            </a>
            <?php }else{ ?>
            <a href="#" class="dropdown-toggle">
                <i class="fa fa-<?php echo ((isset($menu["icon"]) && ($menu["icon"] !== ""))?($menu["icon"]):'desktop'); ?> normal"></i>
                <span class="menu-text normal"> <?php echo ($menu_name); ?> </span>
                <b class="arrow fa fa-angle-right normal"></b>
                <i class="fa fa-reply back"></i>
                <span class="menu-text back">返回</span>

            </a>

            <ul class="submenu">
                <?php getsubmenu1($menu['items']) ?>
            </ul>
            <?php } ?>

        </li>

        <?php } endif; ?>
    <?php } ?>

    <?php function getsubmenu1($submenus){ ?>
    <?php foreach($submenus as $menu){ ?>
    <li>
        <?php $menu_name=lang($menu['lang']); $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name; ?>
        <?php if(empty($menu['items'])){ ?>
        <a href="javascript:openapp('<?php echo ($menu["url"]); ?>','<?php echo ($menu["id"]); ?>','<?php echo ($menu_name); ?>',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">
									<?php echo ($menu_name); ?>
								</span>
        </a>
        <?php }else{ ?>
        <a href="#" class="dropdown-toggle">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">
									<?php echo ($menu_name); ?>
								</span>
            <b class="arrow fa fa-angle-right"></b>
        </a>
        <ul class="submenu">
            <?php getsubmenu2($menu['items']) ?>
        </ul>
        <?php } ?>

    </li>

    <?php } ?>
    <?php } ?>

    <?php function getsubmenu2($submenus){ ?>
    <?php foreach($submenus as $menu){ ?>
    <li>
        <?php $menu_name=lang($menu['lang']); $menu_name=$menu['lang']==$menu_name?$menu['name']:$menu_name; ?>

        <a href="javascript:openapp('<?php echo ($menu["url"]); ?>','<?php echo ($menu["id"]); ?>','<?php echo ($menu_name); ?>',true);">
            &nbsp;<i class="fa fa-angle-double-right"></i>
            <span class="menu-text">
								<?php echo ($menu_name); ?>
							</span>
        </a>
    </li>

    <?php } ?>
    <?php } ?>


    <?php if(APP_DEBUG): ?><style>
            #think_page_trace_open {
                left: 0 !important;
                right: initial !important;
            }
        </style><?php endif; ?>

</head>

<body style="min-width:900px;overflow: hidden;">
<div id="loading"><i class="loadingicon"></i><span></span></div>
<div id="right-tools-wrapper">
    <!--<span id="right_tools_clearcache" title="清除缓存"><i class="fa fa-trash-o right_tool_icon"></i></span>-->
    <span id="refresh-wrapper" title=""><i
            class="fa fa-refresh right_tool_icon"></i></span>
</div>
<div class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a href="<?php echo U('admin/index/index');?>" class="navbar-brand" style="min-width: 200px;text-align: center;">ThinkCMF</a>
            <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <div class="navbar-collapse collapse" id="navbar-main">
            <div class="pull-left" style="position: relative;">
                <a id="task-pre" class="task-changebt"><i class="fa fa-chevron-left"></i></a>
                <div id="task-content">
                    <ul class="nav navbar-nav cmf-component-tab" id="task-content-inner">
                        <li class="cmf-component-tabitem" app-id="0" app-url="<?php echo U('index/index');?>"
                        >
                            <a class="cmf-tabs-item-text">首页</a>
                        </li>
                    </ul>
                    <div style="clear:both;"></div>
                </div>
                <a id="task-next" class="task-changebt"><i class="fa fa-chevron-right"></i></a>
            </div>

            <ul class="nav navbar-nav navbar-right simplewind-nav">
                <li class="light-blue dropdown">
                    <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                        <?php if(isset($admin['avatar']) && $admin['avatar']): ?><img class="nav-user-photo" width="30" height="30"
                                 src="<?php echo cmf_get_user_avatar_url($admin['avatar']);?>" alt="<?php echo ($admin["user_login"]); ?>">
                            <?php else: ?>
                            <img class="nav-user-photo" width="30" height="30"
                                 src="/Public/Admin/Index/img/logo-18.png" alt="<?php echo ((isset($admin["user_login"]) && ($admin["user_login"] !== ""))?($admin["user_login"]):''); ?>"><?php endif; ?>
                        <span class="user-info">
								
							</span>
                        <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="user-menu pull-right dropdown-menu dropdown-yellow dropdown-caret dropdown-closer">
                        <?php if(FDF ): ?><li>
                                <a href=""><i
                                        class="fa fa-cog"></i> </a></li><?php endif; ?>
                        <?php if(GFG): ?><li>
                                <a href=""><i
                                        class="fa fa-user"></i> </a></li><?php endif; ?>
                        <?php if(GF): ?><li>
                                <a href=""><i
                                        class="fa fa-lock"></i> </a></li><?php endif; ?>
                        <li><a href="<?php echo U('Public/logout');?>"><i class="fa fa-sign-out"></i></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="main-container container-fluid">

    <div class="sidebar" id="sidebar">
        <div class="sidebar-shortcuts" id="sidebar-shortcuts">
            <a class="btn btn-sm btn-warning" href="" title="" target="_blank">
                <i class="fa fa-home"></i>
            </a>
           

            <?php if(JHJ): ?><a class="btn btn-sm btn-info"
                   href="javascript:openapp('<?php echo U('user/AdminAsset/index');?>','userAdminAssetindex','资源管理',true);"
                   title="资源管理">
                    <i class="fa fa-file"></i>
                </a><?php endif; ?>

            <?php if(FD): ?><a class="btn btn-sm btn-danger"
                   href="javascript:openapp('<?php echo U('admin/Setting/clearcache');?>','index_clearcache','',true);"
                   title="">
                    <i class="fa fa-trash-o"></i>
                </a><?php endif; ?>

            <?php if(FD): ?><a class="btn btn-sm btn-danger"
                   href=""
                   title="回收站">
                    <i class="fa fa-recycle"></i>
                </a><?php endif; ?>

            <?php if(APP_DEBUG): ?><a class="btn btn-sm btn-default"
                   href=""
                   title="">
                    <i class="fa fa-list"></i>
                </a><?php endif; ?>

        </div>
        <div id="nav-wrapper">
            <ul class="nav nav-list">
                <ul class="nav nav-list">
    <li class="">
        <a href="#" class="dropdown-toggle">
                <i class="fa fa-cogs normal"></i>
                <span class="menu-text normal"> 设置 </span>
                <b class="arrow fa fa-angle-right normal"></b>
                <i class="fa fa-reply back"></i>
                <span class="menu-text back">返回</span>
        </a>
    <ul class="submenu" style="display: none;">
            <li>
            <a href="javascript:openapp('/admin/setting/site.html','70admin','网站信息',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">网站信息</span>
            </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/mailer/index.html','14admin','邮箱配置',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">邮箱配置</span>
        </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/theme/index.html','94admin','模板管理',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">模板管理</span>
            </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/nav/index.html','28admin','导航管理',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">导航管理</span>
            </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/slide/index.html','77admin','幻灯片管理',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">幻灯片管理</span>
            </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/link/index.html','6admin','友情链接',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">友情链接</span>
            </a>  
    </li>
    <li>
            <a href="javascript:openapp('/admin/route/index.html','60admin','URL美化',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">URL美化</span>
            </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/setting/upload.html','74admin','上传设置',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">上传设置</span>
            </a>
    </li>
    <li>
            <a href="javascript:openapp('/admin/storage/index.html','92admin','文件存储',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">文件存储</span>
            </a>
    </li>

    </ul>
            
    </li>

    <li class="">
        <a href="#" class="dropdown-toggle">
        <i class="fa fa-group normal"></i>
        <span class="menu-text normal"> 用户管理 </span>
        <b class="arrow fa fa-angle-right normal"></b>
        <i class="fa fa-reply back"></i>
        <span class="menu-text back">返回</span>
        </a>

        <ul class="submenu" style="display: none;">
            <li>
            <a href="#" class="dropdown-toggle">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">管理组</span>
            <b class="arrow fa fa-angle-right"></b>
            </a>
            <ul class="submenu">
                <li>
                   <a href="javascript:openapp('/admin/rbac/index.html','49admin','角色管理',true);">
                   &nbsp;<i class="fa fa-angle-double-right"></i>
                   <span class="menu-text">角色管理 </span>
                   </a>
                </li>
                <li>
                   <a href="javascript:openapp('/admin/user/index.html','109admin','管理员',true);">
                   &nbsp;<i class="fa fa-angle-double-right"></i>
                   <span class="menu-text">管理员</span>
                   </a>
                </li>
            </ul>
    </li>
    <li>
            <a href="#" class="dropdown-toggle">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">用户组</span>
            <b class="arrow fa fa-angle-right"></b>
             </a>
            <ul class="submenu">
                <li>
                     <a href="javascript:openapp('/user/admin_index/index.html','152user','本站用户',true);">
                     &nbsp;<i class="fa fa-angle-double-right"></i>
                     <span class="menu-text">本站用户</span>
                    </a>
                </li>
                <li>
                     <a href="javascript:openapp('/user/admin_oauth/index.html','155user','第三方用户',true);">
                     &nbsp;<i class="fa fa-angle-double-right"></i>
                     <span class="menu-text">第三方用户</span>
                    </a>
                </li>
            </ul>
    </li>
        </ul>
            
    </li>

    <li class="">
                <a href="#" class="dropdown-toggle">
                <i class="fa fa-cloud normal"></i>
                <span class="menu-text normal"> 插件管理 </span>
                <b class="arrow fa fa-angle-right normal"></b>
                <i class="fa fa-reply back"></i>
                <span class="menu-text back">返回</span>
                </a>

        <ul class="submenu" style="display: none;">
            <li>
                <a href="javascript:openapp('/admin/hook/index.html','2admin','钩子管理',true);">
                <i class="fa fa-caret-right"></i>
                 <span class="menu-text">钩子管理</span>
                </a>
    </li>
        <li>
            <a href="javascript:openapp('/admin/plugin/index.html','41admin','所有插件',true);">
            <i class="fa fa-caret-right"></i>
            <span class="menu-text">所有插件</span>
            </a> 
        </li>
    </ul>
            
    </li>

            <li class="">
                <a href="#" class="dropdown-toggle">
                <i class="fa fa-th normal"></i>
                <span class="menu-text normal"> 门户管理 </span>
                <b class="arrow fa fa-angle-right normal"></b>
                <i class="fa fa-reply back"></i>
                <span class="menu-text back">返回</span>
                </a>
            <ul class="submenu" style="display: none;">
                <li>
                    <a href="javascript:openapp('/portal/admin_article/index.html','120portal','文章管理',true);">
                    <i class="fa fa-caret-right"></i>
                    <span class="menu-text">文章管理</span>
                    </a>
                </li>
                <li>
                    <a href="javascript:openapp('/portal/admin_category/index.html','130portal','分类管理',true);">
                    <i class="fa fa-caret-right"></i>
                    <span class="menu-text">分类管理</span>
                    </a> 
                </li>

                <li>
                   <a href="javascript:openapp('/portal/admin_page/index.html','138portal','页面管理',true);">
                   <i class="fa fa-caret-right"></i>
                   <span class="menu-text">页面管理</span>
                   </a>
                </li>
                <li>
                    <a href="javascript:openapp('/portal/admin_tag/index.html','144portal','文章标签',true);">
                    <i class="fa fa-caret-right"></i>
                     <span class="menu-text">文章标签</span>
                    </a>
                </li>
            </ul>
            
        </li>
 </ul>
            </ul>
        </div>

    </div>

    <div class="main-content">
        <div class="page-content" id="content">
            <iframe src="<?php echo U('index/indexrgt');?>" style="width:100%;height: 100%;" frameborder="0" id="appiframe-0"
                    class="appiframe"></iframe>
        </div>
    </div>
</div>

<script src="/Public/Admin/Index/js/jquery-1.10.2.min.js"></script>
<script src="/Public/Admin/Index/js/wind.js"></script>
<script src="/Public/Admin/Index/js/bootstrap.min.js"></script>
<script src="/Public/Admin/Index/js/admin.js"></script>
<script src="/Public/Admin/Index/js/adminindex.js"></script>
<script>
    $(function () {
        $("[data-toggle='tooltip']").tooltip();
        $("li.dropdown").hover(function () {
            $(this).addClass("open");
        }, function () {
            $(this).removeClass("open");
        });
    });

    var ismenumin = $("#sidebar").hasClass("menu-min");
    $(".nav-list").on("click", function (event) {
        var closest_a = $(event.target).closest("a");
        if (!closest_a || closest_a.length == 0) {
            return
        }
        if (!closest_a.hasClass("dropdown-toggle")) {
            if (ismenumin && "click" == "tap" && closest_a.get(0).parentNode.parentNode == this) {
                var closest_a_menu_text = closest_a.find(".menu-text").get(0);
                if (event.target != closest_a_menu_text && !$.contains(closest_a_menu_text, event.target)) {
                    return false
                }
            }
            return
        }
        var closest_a_next = closest_a.next().get(0);
        if (!$(closest_a_next).is(":visible")) {
            var closest_ul = $(closest_a_next.parentNode).closest("ul");
            if (ismenumin && closest_ul.hasClass("nav-list")) {
                return
            }
            closest_ul.find("> .open > .submenu").each(function () {
                if (this != closest_a_next && !$(this.parentNode).hasClass("active")) {
                    $(this).slideUp(150).parent().removeClass("open")
                }
            });
        }
        if (ismenumin && $(closest_a_next.parentNode.parentNode).hasClass("nav-list")) {
            return false;
        }
        $(closest_a_next).slideToggle(150).parent().toggleClass("open");
        return false;
    });
</script>
</body>
</html>