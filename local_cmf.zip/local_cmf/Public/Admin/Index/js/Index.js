$('.toggle_li>a').click(function(){
   if($(this).parent().children('ul')){
      $(this).parent().children('ul').slideToggle('fast',function(){
          $(this).parent().toggleClass('open');
      });
      
   }
});
//in_array  判断一个数是否在数组中  是返回True   否则返回undefined
function in_array(array,text){
      for(var i in array){
        if(array[i] == text){
            return true;
        }else{
           continue;
        }
      }
}
//点击右侧菜单,在顶部生成一个菜单按钮，并生成一个iframe 标签，插入到.iframe里  
function opennav(url,title){
    var array = $('.header_nav li a').get();
    var attr =new Array();
        for(var i in array){
            attr.push(array[i].innerHTML);
        }
        //如果点击的右侧菜单，上方有则不执行   
         if(title !=undefined && in_array(attr,title) == undefined){
            $('.header_nav li a').removeClass('one');
             
            var element = $('.header_nav li:first').clone(true).addClass('active');
            element.children('a').addClass('one');
            element.append('<span class="closehv" onclick="closehv(this)" title="点击关闭">×</span>');
            element.appendTo('.header_nav');
            element.siblings().children('a').removeClass('one');
            element.children('a').html(title);

            //拷贝 irame 第一个标签并插入到 .iframe 中
            $('.iframe').children().eq(0).clone().attr('src',url).appendTo($('.iframe').eq(0)).css('display','block').siblings().css('display','none');
        }else if(title !=undefined && in_array(attr,title) != undefined){
              for(var i=0,length=$('.active').length;i<length;i++){
                    if($('.active').eq(i).children('a').html() == title){
                       var index = $('.active').eq(i).index();
                    }
              }
              $('.header_nav li').eq(index).siblings().children('a').removeClass('one');
              $('.header_nav li').eq(index).children('a').addClass('one');
              $('.iframe iframe').eq(index).show();
              $('.iframe iframe').eq(index).siblings().hide();
        }
  }
  //顶部菜单的切换
  $('.header_nav li').click(function(){
    $(this).children('a').addClass('one');
    $(this).siblings().children('a').removeClass('one');
    var li = $(this).parent().children();
    var index = $(this).index();
    
     //点击切换显示对应的iframe 标签隐藏其他兄弟标签
    $('.iframe').children().eq(index).show().siblings().hide();
  });

  //点击菜单栏中小图标
  function closehv(te){
     var index = $(te).parent().index();
     $('.header_nav li').eq(index).remove();
     $('.iframe iframe').eq(index).remove();
     $('.header_nav li').eq(index - 1).children('a').addClass('one');
     $('.iframe iframe').eq(index - 1).show();
  }
  //窗口发生改变
  $(window).resize(function(){
       var parent_width = $(window).width();
       var parent_height = $(window).height();

       $('.layui-layer-iframe').css({
          width:parent_width*0.95,
          height:parent_height*0.9
        });
       //引入的iframe 窗口发生改变
       $('.iframe>iframe').css('width',parent_width -200);
   });


  //页面加载完成使iframe窗口自适应
   var parent_width = $(window).width();
   var parent_height = $(window).height();
   $('.iframe>iframe').css('width',parent_width -200);



     //弹出一个窗口
      function alertopen(url,title,data = null){
          if(data == null){
            data = new Object();
            data['width'] = (parent_width*0.95)+'px';
            data['height'] = (parent_height*0.9)+'px';
          }
        layer.open({
            title: '主菜单管理',
            type:2,
            content:'/nav/navlist',
            shade:0.001,
            shadeClose:true,
            skin:'layui-layer-molv',
            area:[data['width'],data['height']]
        });
      }