(function(){
	//生成验证码
    $('.verifycode-wrapper img').get(0).src = "./Login/yzm/rand="+ new Date().getTime();
    //点击更换验证码
    $('.verifycode-wrapper img').click(function(){
    	$(this).get(0).src = "./Login/yzm/rand="+ new Date().getTime();
    });

    //用户名失去焦点
    $('#js-admin-name').blur(function(){
    	if($(this).val() == ''){
    		$(this).parent().css('border','1px solid red');
            $(this).attr('placeholder','请输入用户名');
    	}
    });

    //用户名获得焦点
    $('#js-admin-name').focus(function(){
    		$(this).parent().css('border','');
            $(this).attr('placeholder','用户名');
    });

    //密码失去焦点
    $('#admin_pwd').blur(function(){
    	if($(this).val() == ''){
    		$(this).parent().css('border','1px solid red');
            $(this).attr('placeholder','请输入密码');
    	}
    });

    //密码获得焦点
    $('#admin_pwd').focus(function(){
            $(this).parent().css('border','');
            $(this).attr('placeholder','密码');
    });
    //验证码失去焦点
    $('.verify').blur(function(){
    	if($(this).val() == ''){
            $(this).parent().css('border','1px solid red');
            $(this).attr('placeholder','请输入验证码');
    	}
    });
    //验证码获得焦点
    $('.verify').focus(function(){
            $(this).parent().css('border','');
            $(this).attr('placeholder','验证码');
    });



    //点击提交按钮
    $('.js-ajax-submit').click(function(){
    	var flag = true;
         //判断用户名是否为空
    	if(!$('#js-admin-name').val()){
    		flag = false;
    		$('.error').html('用户名为空');
    		return false;
    	}
         //判断密码是否为空
        if(!$('#admin_pwd').val()){
    		flag = false;
    		$('.error').html('密码为空');
    		return false;
    	}
        //判断严重码是否为空
    	if(!$('.verify').val()){
    		flag = false;
    		$('.error').html('验证码为空');
    		return false;
    	}
        //验证用户名格式
        var upattern = /^(\d+)$/ig;
        var username =$('#js-admin-name').val();
        if(username.length < 4 || username.length > 10){
        	$flag = false;
        	$('.error').html('用户名长度必须大于4位小于10位');
        	return false;
        }else{
        	if(username.match(upattern)){
               $flag = false;
               $('.error').html('用户名不能全为数字');
               return false;
            }
        }
        

        //验证密码格式
        var ppattern = /^(\d+)$/ig;
        var password =$('#admin_pwd').val();
        if(password.length < 4 || password.length > 12){
        	$flag = false;
        	$('.error').html('密码长度必须大于4位小于12位');
        	return false;
        }else{
        	if(password.match(ppattern)){
        	               $flag = false;
        	               $('.error').html('密码不能全为数字');
        	               return false;
        	  }
        }
        //验证验证码
        var yzm = $('.verify').val();
        console.log(yzm.match(ypattern) == false);
        var ypattern = /^[a-z0-9A-Z]{4}$/ig;
       if(!yzm.match(ypattern)){
       	    $flag = false;
        	$('.error').html('验证码格式不正确');
        	return false;
       }
       //如果数据格式正确则才可以发送ajax请求
    	if(flag){
    		//错误信息清除
    		$('.error').html('');
    		$('.js-ajax-submit').html('正在登陆');
    		//发送ajsx请求
    		$.post(
    		'./login/login',      //请求的地址
    		{             //数据
    			username:$('#js-admin-name').val(),
    			password:$('#admin_pwd').val(),
    			yzm:$('.verify').val()
    	    },
    	    //回调函数
    	    function(data){
    	    	if(data.code != 1){
    	    	   $('.error').html(data.message);     //如果不正确，打印错误信息
    	    	   $('.js-ajax-submit').html('提交');
    	    	}else{
    	    		$('.js-ajax-submit').html('登录成功');
    	    		window.location.href = './Index/index';
    	    	}
    	    //刷新验证码
             $('.verifycode-wrapper img').get(0).src = "./Login/yzm/rand="+ new Date().getTime();                
    	    }
    		);
    	}
    	    	return false;        
    });
})();