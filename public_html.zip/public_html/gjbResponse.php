<?php
/**
 * 绕过ajax跨域，通过php获取凯德福数据
 */

$domain = 'http://www.jyjrwx.com';

// 指定允许其他域名访问
header('Access-Control-Allow-Origin:'. $domain);
// 响应类型
header('Access-Control-Allow-Methods:POST');
// 响应头设置
header('Access-Control-Allow-Headers:x-requested-with,content-type');


if(isset($_POST['url']) && $_POST['url']){
    $ch = curl_init($_POST['url']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ;
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true) ;
    $output = curl_exec($ch) ;
    echo $output;
}