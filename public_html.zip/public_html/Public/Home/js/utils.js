(function() {
	window.$U = {};
	/*********************************Ajax***********************************/
	var Ajax = function(obj) {
		if(typeof(obj) != 'object') return false;
		this.type = obj.type == undefined ? 'POST' : obj.type.toUpperCase();
		this.url = obj.url == undefined ? window.location.href : obj.url;
		this.async = obj.async == undefined ? true : obj.type;
		this.dataType = obj.dataType == undefined ? 'HTML' : obj.dataType.toUpperCase();
		this.data = obj.data == undefined ? {} : obj.data;
		obj.success && (this.successcb = obj.success);
		obj.error && (this.errorcb = obj.error);
		obj.beforeSend && (this.beforeSend = obj.beforeSend);
		if(window.XMLHttpRequest) {
			this.xmlhttp = new XMLHttpRequest();
		} else {
			this.xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
		obj.onabort && (this.xmlhttp.onabort = obj.onabort);
		this.xmlhttp.timeout = (obj.timeout ? obj.timeout : 0); //0则表示不设置超时
		obj.ontimeout && (this.xmlhttp.ontimeout = obj.ontimeout);
		this._start();
	}
	Ajax.prototype = {
		_formatParams: function(data) {
			if(typeof(data) == "object") {
				var str = "";
				for(var pro in data) {
					str += pro + "=" + data[pro] + "&";
				}
				data = str.substr(0, str.length - 1);
			}
			if(this.type == 'GET' || this.dataType == 'JSONP') {
				if(this.url.lastIndexOf('?') == -1) {
					this.url += '?' + data;
				} else {
					this.url += '&' + data;
				}
			}
		},
		_start: function() {
			if(this.dataType == 'JSONP') {
				if(typeof(obj.beforeSend) == 'function') obj.beforeSend(this.xmlhttp);
				var callbackName = ('jsonp_' + Math.random()).replace(".", "");
				var oHead = document.getElementsByTagName('head')[0];
				this.data.callback = callbackName; //添加callback到data
				var ele = document.createElement('script');
				ele.type = "text/javascript";
				ele.onerror = function() {
					console.log('请求失败');
					this.errorcb && this.errorcb("请求失败");
				}.bind(this);

				oHead.appendChild(ele);
				window[callbackName] = function(json) {
					oHead.removeChild(ele);
					window[callbackName] = null;
					this.successcb && this.successcb(json);
				}.bind(this);
				this._formatParams(this.data); //此参数含callback
				ele.src = this.url;
				return;
			} else {
				this._formatParams(this.data);
				this.xmlhttp.open(this.type, this.url, this.async);
				this.xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
				this.beforeSend && this.beforeSend(this.xmlhttp);
				this.xmlhttp.send(this.data);
				this.xmlhttp.onreadystatechange = function() {

					if(this.xmlhttp.status != 200) { //this.xmlhttp.status为0，表示被abort()阻止或者超时;
						console.log(this.xmlhttp.status + '错误');
						this.errorcb && this.errorcb(this.xmlhttp.status + '错误');
						return;
					}

					if(this.xmlhttp.readyState == 4 && this.xmlhttp.status == 200) {

						if(this.dataType == 'JSON') {
							try {
								res = JSON.parse(this.xmlhttp.responseText);
							} catch(e) {
								console.log('返回的json格式不正确');
								this.errorcb('返回的json格式不正确');
							}

						} else if(this.dataType == 'XML') {
							res = this.xmlhttp.responseXML;
						} else {
							res = this.xmlhttp.responseText;
						}
						this.successcb && this.successcb(res, this._AllHeadersDeal());
					}
				}.bind(this);
			}
		},
		_abort: function() { //阻止此次请求(varName._proto_._abort());
			this.xmlhttp.abort();
		},
		_AllHeadersDeal: function() { //原生getAllResponseHeaders的值处理
			var str = this.xmlhttp.getAllResponseHeaders();
			var oarr = str.match(/.*(\n||\r)/gi);
			for(var i = 0; i < oarr.length; i++) {
				if(!oarr[i].replace(/\n||\r/gi, "")) {
					oarr.splice(i, 1);
					i--;
				}
			}
			var obj = {};
			for(var i = 0; i < oarr.length; i++) {
				var temp = oarr[i].split(":");
				obj[temp[0]] = temp[1].replace(" ", "");
			}
			return obj;
		}
	}
	/*********************************Router*******************************/
	var Router = function() {
		this.routes = {};
		this.currentUrl = '';
		this.isStorege = false;
		this.init();
	}
	Router.prototype = {
		route: function(path, callback) {
			this.routes[path] = callback || function() {};
		},
		refresh: function() {
			//this.currentUrl = location.hash.slice(1) || '/';
			if(this.isStorege) {
				this.isStorege = false;
				return false;
			}
			if(location.hash.slice(1)) {
				this.currentUrl = location.hash.slice(1);
			} else {
				this.currentUrl = this.defaultRoute || '/';
				location.hash = this.currentUrl;
				this.isStorege = true;
			}
			this.routes[this.currentUrl]();
		},
		init: function() {
			window.addEventListener('load', this.refresh.bind(this), false);
			window.addEventListener('hashchange', this.refresh.bind(this), false);
		},
		config: function(obj) {
			obj.defaultRoute && (this.defaultRoute = obj.defaultRoute)
		}
	}
	$U.ajax = function(obj) {
		return new Ajax(obj);
	};
	$U.router = function() {
		return new Router();
	};
	$U.getStyle = function(obj, attr) {
		if(obj.currentStyle) {
			return obj.currentStyle[attr];
		} else {
			return getComputedStyle(obj, false)[attr];
		}
	}
	$U.map = function(obj, cb) {
		for(var i = 0; i < obj.length; i++) {
			cb(obj[i], i);
		}
		return obj;
	}
	$U.getOffset = function(Node, offset) {
		if(!offset) {
			offset = {};
			offset.top = 0;
			offset.left = 0;
		}
		if(Node == document.body) {
			return offset;
		}
		offset.top += Node.offsetTop;
		offset.left += Node.offsetLeft;
		return getOffset(Node.offsetParent, offset); //递归
	}
	//add them for item
	$U.getTem = function(t, cb) {
		this.ajax({
			type: "get",
			url: t,
			async: true,
			dataType: 'html',
			success: function(data) {
				cb(data);
			}
		});
	}
	$U.dealTem = function(o, t) {
		o.innerHTML = t;
		var s;
		t.match(/(<script.*>)[\s\S]*(<\/script>)/g) && (s = t.match(/(<script.*>)[\s\S]*(<\/script>)/gi)[0].replace(/(<script.*>)|(<\/script>)/g, ""));
		eval(s);
	}
})();