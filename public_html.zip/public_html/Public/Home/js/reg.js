/*注册页面表单校验*/
$(function(){
    var regName = $("#reg-name");//姓名
    var tel = $("#tel");//手机号
    var regEmail = $("#reg-email");//电子邮箱
    var regIb = $("#reg-ib");//邀请码
    var regCode = $("#reg-code");//用户手机验证码
    var sendCode = $("#sendCode");//发送验证码
    var zcError = $("#zcError");//错误提示框
    var regSubmit = $('#reg_submit');//提交按钮
	var txyzm = $('#txyzm');//图形验证码
	
	
    
	
	//鼠标失焦时判断
    regName.blur(function(){
        if(regName.val() == ""){
            zcError.text("*姓名不能为空！");
            $(this).addClass("red-border");
        }
        else{
            zcError.text("");
            $(this).removeClass("red-border");
        }
    });
    tel.blur(function(){
        if(!(/^1([23578])\d{9}$/.test(tel.val()))){
            zcError.text("*请输入正确的手机号码！");
            $(this).addClass("red-border");
        }
        else{
            zcError.text("");
            $(this).removeClass("red-border");
        }
    });
    regEmail.blur(function(){
        if(!(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(regEmail.val()))){
            zcError.text("*请输入正确的邮箱地址！");
            $(this).addClass("red-border");
        }
        else{
            zcError.text("");
            $(this).removeClass("red-border");
        }
    });
    regIb.blur(function(){
        if(regIb.val()){
        	if(!(/^\d+$/.test(regIb.val())))
        	{
                zcError.text("*IB编码是数字！");
                $(this).addClass("red-border");
        	}
        	else
        	{
             zcError.text("");
             $(this).removeClass("red-border");
        	}
        }
    });
    regCode.blur(function(){
        if(regCode.val() == ""){
            zcError.text("*手机验证码不能为空！");
            $(this).addClass("red-border");
        }
        else if(regCode.val().length !== 6){
            zcError.text("*请填写6位短信验证码！");
            $(this).addClass("red-border");
        }
        else{
            zcError.text("");
            $(this).removeClass("red-border");
        }
  	}); 
  	txyzm.blur(function(){
        if(txyzm.val() == ""){
            zcError.text("*图形验证码不能为空！");
            $(this).addClass("red-border");
        }
        else if(txyzm.val().length !== 4){
            zcError.text("*请填写4位图形验证码！");
            $(this).addClass("red-border");
        }
        else{
            zcError.text("");
            $(this).removeClass("red-border");
        }
  	}); 
	
	
	
	
	
	//获取短信验证码倒计时120秒
    var allTime = 120 , time;
    sendCode.click(function(){
        $("#reg_form").ajaxSubmit({
            url : telcodeurl,
            type : "POST",
            beforeSubmit : function (formData, jqForm, options) {
                if(!(/^1([23578])\d{9}$/.test(tel.val()))){
                    zcError.text("*请输入正确的手机号码！");
					tel.addClass("red-border");
                    return false;
                }
                else{
                    zcError.text("");
                    return true;
                }
            },
            success : function (responseText, statusText) {
			    if(responseText.code == 1)
                {
                    zcError.text(responseText.message);
                    sendCode.text("剩余120秒").attr("disabled", "disabled");
                    time = setInterval(subTime, 1000);
                    sendCode.css("backgroundColor", "#cccccc");
                }
                else{
                    zcError.text(responseText.message);
                }
            }
        });
    });
    
    
    //获取验证码倒计时处的回调函数
    function subTime(){
        allTime--;
        sendCode.text("剩余" + allTime + "秒");
        if(allTime < 0){
            clearInterval(time);
            sendCode.text("重新获取").removeAttr("disabled");
            sendCode.css("backgroundColor", "#373d4b");
        }
    }
    
    //提交登录时判断
    regSubmit.click(function(){
        $('#reg_form').ajaxSubmit({
            url : formurl,
            type : 'POST',
            beforeSubmit : function (formData, jqForm, options) {
                if(regName.val() == ""){
                    zcError.text("*姓名不能为空！");
                    regName.addClass("red-border");
					return false;
                }
                if(!(/^1([23578])\d{9}$/.test(tel.val()))){
                    zcError.text("*请输入正确的手机号码！");
					return false;
                }
                if(!(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(regEmail.val()))){
                    zcError.text("*请输入正确的邮箱地址！");
                    regEmail.addClass("red-border");
					return false;
                }
                if(regIb.val()){
                	if(!(/^\d+$/.test(regIb.val())))
                	{
                        zcError.text("*邀请码必须是数字！");
                        regIb.addClass("red-border");
                        return false;
                	}
                }
                if(regCode.val().length !== 6){
                    zcError.text("*请填写6位短信验证码！");
                    regCode.addClass("red-border");
                    return false;
                }
                if(txyzm.val().length !== 4){
                    zcError.text("*请填写4位图形验证码！");
                    txyzm.addClass("red-border");
                    return false;
                }
                zcError.text("");
                return true;
          },
            success : function (responseText, statusText) {
                if(responseText.code == "1"){
                    zcError.text("*注册成功，等待客服发送登录账号密码到您手机！");
                  	window.location.href = successurl;
                }
                else{
                    zcError.text(responseText.message);
                }
            }
        });
    });

	
	
	
	/*验证码刷新*/
    $(".codeImg").click(function(){
        randyzm();
    });
	randyzm=function(){
		 $(".codeImg").attr('src',txyzmUrl +'?ramd=' + Math.random());
	};

    //Enter键提交表单
    $("#reg_form").keyup(function(e){
        if(e.keyCode == 13){
            regSubmit.click();
        }
    });
});
