/*用户登录表单校验*/
$(function(){
    var loginUser = $("#loginUser");
    var loginPassword = $("#loginPassword");
    var loginCode = $("#loginCode");
    var Error = $("#error");
    var loginSubmit = $('#login_submit');
    
    
    //鼠标失焦时判断
    loginUser.blur(function(){
        if(loginUser.val() == ""){
            Error.text("*用户名不能为空！");
            $(this).parent().addClass("red-border");
        }
        else{
            Error.text("");
            $(this).parent().removeClass("red-border");
        }
    });
    loginPassword.blur(function(){
        if(loginPassword.val() == ""){
            Error.text("*密码不能为空！");
            $(this).parent().addClass("red-border");
        }
        else if(loginPassword.val().length < 6){
            Error.text("*密码不能小于6个字符！");
            $(this).parent().addClass("red-border");
        }
        else{
            Error.text("");
            $(this).parent().removeClass("red-border");
        }
    });
    loginCode.blur(function(){
        if(loginCode.val() == ""){
            Error.text("*验证码不能为空！");
            $(this).addClass("red-border");
        }
        else if(loginCode.val().length !== 4){
            Error.text("*请填写4位数验证码！");
            $(this).addClass("red-border");
        }
        else{
            Error.text("");
            $(this).removeClass("red-border");
        }
    });
    
    
    //登录
    loginSubmit.click(function(){
            $('#login_form').ajaxSubmit({
            url : formurl,
            type : 'POST',
            beforeSubmit : function (formData, jqForm, options) {
                if(loginUser.val() == ""){
                    Error.text("*用户名不能为空！");
                    loginUser.parent().addClass("red-border");
                    return false;
                }
                else if(loginPassword.val() == ""){
                    Error.text("*密码不能为空！");
                    loginPassword.parent().addClass("red-border");
                    return false;
                }
                else if(loginPassword.val().length < 6){
                    Error.text("*密码不能小于6个字符！");
                    loginPassword.parent().addClass("red-border");
                    return false;
                }
                else if(loginCode.val() == ""){
                    Error.text("*验证码不能为空！");
                    loginCode.addClass("red-border");
                    return false;
                }
                else if(loginCode.val().length !== 4){
                    Error.text("*请填写4位数验证码！");
                    loginCode.addClass("red-border");
                    return false;
                }
                else{
                    Error.text("");
                    $("#login_form").find("input").removeClass("red-border");
                    $("#login_form").find(".Children_divs").removeClass("red-border");
                    return true;
                }
            },
            success : function (responseText, statusText) {
					randyzm();
                    if(responseText.code == 1){
                        window.location.href = responseText.message;
                    }
                    else{
                    	console.info(responseText.message);
                        Error.text(responseText.message);
                    }
            }
        });
    });
    
    
    
    
    
    
    /*验证码刷新*/
    $(".codeImg").click(function(){
        randyzm();
    });
	randyzm=function(){
		 $(".codeImg").attr('src',yzmurl +'?ramd=' + Math.random());
	};

    //Enter键提交表单
    $("#login_form").keyup(function(e){
        if(e.keyCode == 13){
            $('#login_submit').click();
        }
    });
});






















