// JavaScript Document
$(function(){
    var regName  	= $('input[name="rname"]');
    var tel         = $('input[name="tel"]');
    var regEmail    = $('input[name="email"]');
    var regIb 	    = $('input[name="ibcode"]');
    var zcError   	= $(".zcError");
    var regSubmit   = $('#login_submit');
	var reg_error 	= $('#login_error');

    //提交登录时判断
    regSubmit.click(function(){
			var flag=true;
			zcError.text('');
			$(".red_border").removeClass("red_border");			
			
            $('#reg_form').ajaxSubmit({
            url : formurl,
            type : 'POST',
            beforeSubmit : function (formData, jqForm, options) {
               if(regName.val() == "")
			   {
                    regName.next().text("*姓名不能为空！");
                    regName.addClass("red_border");
                    flag=false;
                }
				if(regName.val().length>30){
                    regName.next().text("*姓名不能大于30位");
                    regName.addClass("red_border");
                    flag=false;
                }
                if(tel.val()=='')
				{
                    tel.next().text("*请输入正确的手机号码！");
                    tel.addClass("red_border");
                    flag=false;
                }
                if(!(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(regEmail.val()))){
                    regEmail.next().text("*请输入正确的邮箱地址！");
                    regEmail.addClass("red_border");
                    flag=false;
                }
                var pattern=/^\d+$/;
                if(!pattern.test(regIb.val())){
                    regIb.next().text("*IB编码是数字！");
                    regIb.addClass("red_border");
                    flag=false;
                }              
				if(flag)
				{
                    $("#loading").show();
                    return true;
                }
				else
				{
					return false;
				}
            },

            success : function (responseText, statusText) {
				$("#loading").hide();				
                if(responseText.code == 1){
                    reg_error.text("*注册成功！");
                }
                else if(responseText.code == -2){
					regName.next().text(responseText.message);
                    regName.addClass("red_border");
                }
                else if(responseText.code == -3){
                    tel.next().text(responseText.message);
                    tel.addClass("red_border");
                }
                else if(responseText.code == -4){
                    regEmail.next().text(responseText.message);
                    regEmail.addClass("red_border");
                }
                else if(responseText.code == -5){
                    regIb.next().text(responseText.message);
                    regIb.addClass("red_border");
                }
                else if(responseText.code == -6){
                    tel.next().text(responseText.message);
                    tel.addClass("red_border");
                }
                else if(responseText.code == -7){
                    regEmail.next().text(responseText.message);
                    regEmail.addClass("red_border");
                }
                else if(responseText.code == -20){
					reg_error.text("*注册失败，请重试！");
                }
                else{
                    reg_error.text('错误代码：'+responseText.code+'，错误信息：'+responseText.message);
                }
            }
        });
    });



    //Enter键提交表单
    $("#reg_form").keyup(function(e){
        if(e.keyCode == 13){
            //$('#reg_submit').focus();
			$('#reg_submit').trigger("click");
        }
    });

});
