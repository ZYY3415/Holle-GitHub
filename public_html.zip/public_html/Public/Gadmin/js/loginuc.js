// JavaScript Document
$(function(){
    var loginuc  		= $("#loginuc");
    var login_submit  	= $("#login_submit");
    var login_error     = $('#login_error');
    var password   		= $('#password');
    var login_submit 	= $('#login_submit');
    var mt4account 		= $('#mt4account');
    
    //提交登录时判断
    login_submit.click(function(){
			var flag=true;
			login_error.text('');
			$(".red_border").removeClass("red_border");			
			
            $.ajax({
            url : formurl,
            type : 'POST',
            data:{'password':password.val(),'mt4account':mt4account.val()},
            beforeSend : function () {
            },

            success : function (responseText, statusText) {
				$("#loading").hide();				
                if(responseText.code == 1){
                	login_error.text("*登陆成功");
                	$('#divpass').hide();
					window.open(openurl);
                }
                else if(responseText.code == -1){
                	login_error.text(responseText.msg);
                	password.addClass("red_border");
                }
                else{
                	login_error.text("异常错误，请重新输入！");
                }
            }
        });
    });


});
