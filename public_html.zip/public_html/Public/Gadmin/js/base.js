// JavaScript Document
$(function(){
	$('.loading-bg').css('height',$(window).height());
	$('.loading-img').css('top',($(window).height()-124)/2);
	$('.loading-img').css('left',($(window).width()-124)/2);
});
