// JavaScript Document
$(function(){
    var loginsubmit  	= $("#login_submit");
    var loginUser       = $('input[name="admin_name"]');
    var loginPassword   = $('input[name="admin_password"]');
    var loginCode 	    = $('input[name="yzm"]');
    var zcError   		= $(".zcError");
	var loginerror 		= $('#login_error');

    //提交登录时判断
    loginsubmit.click(function(){
			var flag=true;
			zcError.text('');
			$(".red_border").removeClass("red_border");			
			
            $('#login_form').ajaxSubmit({
            url : formurl,
            type : 'POST',
            beforeSubmit : function (formData, jqForm, options) {
               if(loginUser.val() == "")
			   {
                    loginUser.next().text("*账号不能为空！");
                    loginUser.addClass("red_border");
                    flag=false;
                }
				if(loginUser.val().length>10){
                    loginUser.next().text("*账号不能大于10位");
                    loginUser.addClass("red_border");
                    flag=false;
                }
                if(loginPassword.val().length != 6){
                    loginPassword.next().text("*密码是6位！");
                    loginPassword.addClass("red_border");
                    flag=false;
                }
                if(loginCode.val().length != 4){
                    loginCode.next().text("验证码是4位！");
                    loginCode.addClass("red_border");
                    flag=false;
                }
				if(flag)
				{
                    $("#loading").show();
                    return true;
                }
				else
				{
					return false;
				}
            },

            success : function (responseText, statusText) {
				$("#loading").hide();				
                if(responseText.code == 1){
                    loginerror.text("*登陆成功");
					window.location.href=responseText.message;
                }
                else if(responseText.code == -1){
                    loginCode.next().text(responseText.message);
					loginCode.addClass("red_border");
                }
                else if(responseText.code == -2){
					loginUser.next().text(responseText.message);
                    loginUser.addClass("red_border");
                }
                else if(responseText.code == -3){
                   	loginUser.next().text(responseText.message);
                    loginUser.addClass("red_border");
                }
                else if(responseText.code == -4){
                  	loginPassword.next().text(responseText.message);
                    loginPassword.addClass("red_border");
                }
                else if(responseText.code == -5){
                    loginUser.next().text(responseText.message);
                    loginUser.addClass("red_border");
					loginPassword.next().text(responseText.message);
                    loginPassword.addClass("red_border");
                }
                else{
                    loginerror.text("异常错误，请重新输入！");
                }
            }
        });
    });



//    //Enter键提交表单
//    $("#reg_form").keyup(function(e){
//        if(e.keyCode == 13){
//            $('#reg_submit').focus();
//        }
//    });
	    /*验证码刷新*/
    $(".codeImg").click(function(){
        $(this).attr("src", yzmurl +'?ramd=' + Math.random());
    });

    //Enter键提交表单
    $("#login_form").keyup(function(e){
        if(e.keyCode == 13){
            $('#login_submit').trigger("click");
        }
    });

});
