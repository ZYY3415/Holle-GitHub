/*交易记录表单校验*/
$(function(){
	balance=$('#balance');
	
	$.ajax({
	url:getmoneyurl,
	type:'POST',
	//data:'',
	dataType:'json',
	beforeSend: function(){

	},
	success : function (response, status, xhr)
	{			
		if(response)
		{
			if(response.success)
			{
				   var data=response.data[0];
				   	balance.parent().show();
				   balance.val(Math.round(data.Balance*100)/100);
			}

		}
	},
	error:function(){},
	});
			
});