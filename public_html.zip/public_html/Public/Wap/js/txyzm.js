/**
 * 
 */
$(function(){

    /*验证码刷新*/
    $(".txyzm").click(function(){
        txyzm();
    });
	txyzm=function(){
		 $(".txyzm").attr("src", txyzmurl +'?ramd=' + Math.random());
	};
	
});
