/**
 * 
 * @authors Sam (645298225@qq.com)
 * @date    2016-03-13 21:24:55
 * @version $Id$
 */

// samBase.js
(function(window){
	function samBase(){};
	samBase.prototype =  {
		construcor:samBase,
		//多次onload
		loadEvent:function(fn){
	        if(fn == null){
	        	window.onload = fn;
	        }
	        var oldOnload = window.onload;
	        if(typeof window.onload != 'function'){
	            window.onload = fn; 
	        }else{
	        	window.onload = function(){
		        	oldOnload();
		        	fn();
	        	}
	        }
		},
		//绑定事件
		addEvent:function(element,type,fn){
			if(element.addEventListener){
				element.addEventListener(type,fn,false);
			}else if(element.attachEvent){
				element.attachEvent('on'+type,function(){
					fn.call(element);
				});
			}
		},
		//移除时间
		removeEvent:function(element,type,fn){
			if(element.removeEventListener){
				element.removeEventListener(type,fn,false);
			}else if(element.detachEvent){
				element.detachEvent('on'+type,fn);
			}else{
				element.detachEvent['on'+type] = null;
			}
		},
		//阻止冒泡
		stopPropagation:function(event){
			//ie支持window.event
			event = event || window.event;
			if(event.stopPropagation){
				event.stopPropagation();
			}else{
				event.cancelBubble = true;
			}
		},
		//防止默认行为
		preventDefault:function(event){
			if(event.preventDefault){
				event.preventDefault();
			}else{
				event.returnValue = false;
			}
		},
		//获取事件当前元素
		getTarget:function(event){
			return window.event.target || event.srcElement;
		},
		//获取屏幕宽度
		getClientWidth:function(){
			return window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
		},
		//获取最终样式
		getStyle:function(element,attr){
			if(element.currentStyle){
	            return element.currentStyle[attr];
			}else{
	            return getComputedStyle(element,false)[attr];
			}
		},
		getAllStyle:function(element){
			var tempStyle = element.currentStyle || getComputedStyle(element,false);
			console.log(tempStyle)
			var tempJson = {};
            for(var k in tempStyle){
               tempJson.k = tempStyle[k];
            }
            return tempJson;
		},
		//css驼峰转化
	    toPeak:function(string){
	    	var arr = string.split('-');
	    	for(var i = 0 ; i < arr.length ; i++){
	    		arr[i].charAt(0).toUpperCase() + arr[i].substring(1)
	    	}
	    	return arr.join('');
	    },
	    //查询字符串字符出现次数最多的
	    maxLength:function(str){
	    	var temp = {};
	    	var num = 0 ;
	    	var value =  0 ;
	    	for(var i = 0 ; i< str.length ; i++){
	    		//判断json中字母所属数组是否存在，不存在则创建
	    		//相当于temp ={a,b,c},如果d不存在的话，就让d作为一个属性，且类型为数组
	    		if(!temp[str[i]]){
	    			temp[str[i]] = [];
	    			
	    		}
	    		temp[str[i]].push(str[i]);
	    	}

	    	for(var i in temp){
	    		if(num < temp[i].length){
	    			num = temp[i].length;
	    			value = temp[i][0];
	    		}
	    	}
	    	return{
	    		char:value,
	    		count:num
	    	}
	    },

	    //正则方法获取字符串出现最多次数的字符
	    maxLenRule:function(str){
	        var temp = '';
	        var num = 0;
	        var value ='';
	        var arr = [];
	        //也可以arr = str.split('');
	        for(var i = 0 ; i < str.length ; i++){
	        	arr.push(str[i]);
	        }
	        arr = arr.sort();
	        str = arr.join('');
	        //$0表示正则匹配到所有项，即是(\w)\1+,\1是对第一个子项的复制，+号表示是复制多次，例如sssss，$1表示的是(\w),是子项，例如s；
	        var regRule = /(\w)\1+/g;
	        str.replace(regRule,function($0,$1){
	        	if(num < $0.length){
	        		num = $0.length;
	        		value = $1
	        	}
	        })
	        return{
	    		char:value,
	    		count:num
	    	}
	    },
	    //数组去重复
	    uniqidArr:function(arr){
	    	var newArr = [];
	    	var b;
	    	for(var i = 0 ; i<arr.length;i++){
	    		b = false;
	    		for(var j = 0 ; j < newArr.length ; j++){
	    			if(arr[i] == newArr[j]){
	    				b = true;
	    				break;
	    			}
	    		}
	    		if(!b){
	    	 	    newArr.push(arr[i]);
	    	    }
	    	}
	    	return newArr;
	    },
	    //千分符
	    toThousand:function(str){

	    	//思路是通过求模判断是否有余数，如果有，就开头截取余数数量的字符到数组，作为第一项；
	    	//剩下的字符通过遍历，每次把3位作为子项放进数组中，最后通过转换数组成为字符串即可；
	    	var prevNum = str.length % 3;
	        var arr= [];
	        var num =0;
	        var temp='';
	    	if(prevNum != 0 ){
	            arr.push(str.substring(0,prevNum));
	    	}
	    	str = str.substring(prevNum);
	    	for(var i = 0 ; i < str.length ; i++){
	    		num++;
	    		temp += str[i];
	    		if(num == 3 && temp){
	    			arr.push(temp);
	    			num=0;
	    			temp='';
	    		}
	    	}
	    	return arr.join(',');
	    },
	    //千分符正则
	    toThousandRule:function(str){
	    	//前相匹配?=n,指定后面的字符为x，反向匹配的应用?!指定后面的字符不能为x 
	        //匹配任何其后紧接n字符串的字符
	    	var regRule = /(?=(?!\b)(\w{3})+$)/g;
	        //把其后紧接符合上述正则的字符替换为‘，’
	    	return str.replace(regRule,',');
	    },
	    //获取字符串里的数字
	    getNumStr:function(str){
	    	var temp='';
	        //isNaN(x),判断x是否是非数值
	    	for(var i = 0 ; i< str.length;i++){
	    		if(!isNaN(str[i])){
	    			temp += str[i];
	    		}
	    	}
	    	return temp;
	    },
	    //不用循环，递归出n个数字的数组
	    noCircle:function(n){
	    	var arr=[];
	    	return (function(){
	            arr.unshift(n);
	    		n--;
	    		if(n != 0){
	    			arguments.callee();
	    		}
	    		return arr;
	    	})()
	    },
	    //不用循环，使用正则方法写出n个数字的数组
	    noCircleRule:function(n){
	    	var arr = [];
	    	arr.length = n+1;
	    	var regRule =/a/g;
	    	var str = arr.join('a');
	    	var arr2 = [];
	    	//想不到正则的全局匹配是想遍历一样进行的！这样就确定了只能匹配5次正则了
	    	str.replace(regRule,function(){
	    		arr2.unshift(n--)
	    	})
	    	return arr2;
	    },
	    //枚举实例
	    mjFunc:function(id){
	    	var obj = document.getElementById(id);
	    	var oUl = obj.getElementsByTagName('ul')[0];
	        var oA = obj.getElementsByTagName('a');
	    	var aLi = oUl.getElementsByTagName('li');
	    	for(var i =0 ; i<oA.length; i++){
	    		oA[i].onclick = function(){
	    			if(mj(this.innerHTML)){
	                    var oLi = document.createElement('li');
	                    oLi.innerHTML = this.innerHTML;
	                    if(!aLi[0]){
	                        oUl.appendChild(oLi);
	                    }else{
	                    	oUl.insertBefore(oLi,aLi[0])
	                    }
	    			}else{
	                    order(this.innerHTML)
	    			}
	    		}
	    	}

	    	function mj(txt){     
	    		for(var i = 0 ;i < aLi.length ; i++){
	    			if(aLi[i].innerHTML == txt){

	    				return false;
	    			}
	    		}
	    		return true;
	    	}

	    	function order(txt){
	    		for(var i = 0 ; i< aLi.length ; i++){
	    			if(aLi[i].innerHTML == txt){
	    				oUl.insertBefore(aLi[i],aLi[0])
	    			}
	    		}
	    	}
	    },
	    
	    //奇偶数行颜色不一样
	    evenRowColor:function(className,colorValue){
	    	var obj = typeof className === 'object' ? className : this.getByClass(className);
		 	if(!obj){
		 		return;
		 	}
		 	for(var i = 0 ; i< obj.length ;i++){
		 		if(i%2 == 0){
					obj[i].style.backgroundColor = colorValue;
				}
		 	}
	    },
	    //去左右空格
	    trimStr:function (str){
		 	var reg = /^\s*|\s*$/g;
		 	return str.replace(reg,'');
		},
		//数组是否包含
		inArr:function(value,arr){
	        
	        for(var i = 0 ; i< arr.length ;i++){
	        	if(arr[i] == value){
	        		return true;
	        	}
	        }
	 
			return false;
		},
		//数组查找制定value的位置
		indexArr:function(value,arr){
			for(var i = 0 ; i< arr.length ;i++){
	        	if(arr[i] == value){
	        		return i;
	        	}
	        }
			return -1;
		},
		//删除数组中制定的value
		removeArr:function(value,arr){
	        var i = this.indexArr(value,arr);
	        var tempArr = [];
	        if( i > -1){
	        	// splice(startPos,length,replaceValue),删除替换添加
	        	arr.splice(i,1)
	        }
	        return arr;
		},
		//检测ie
		isIE:function(){
			if(!+[1,]){
				return true;
			}
			return false;
		},
		//根据元素的类名获取dom对象
	    getByClass:function(tClass,oParent){
	    	var oParent = typeof oParent === 'object' ? oParent : document.getElementById(oParent) || document;
		    var arrResult = [];
		    var  oClass = oParent.getElementsByTagName('*');
		    for(var i= 0 ;i<oClass.length ;i++){
		        var tempArr = oClass[i].className.split(/\s+/);
		        for(var j = 0 ;j < tempArr.length ; j++){
		            if(tempArr[j] == tClass){
		                arrResult.push(oClass[i]);
		            }
		        }
		    }
		    return arrResult;
	    },
		//检测是否有制定class
		//<div class="c1 c2 c3">
		//class操作，要求是，行间的样式名称排序要严格一个空格分开的格式，否则失效
		//正则的方式来实现，总是多了一个空格，我还没写出来，我也是醉
		hasClass:function(oClass,obj){
			//obj可以为dom对象，可以是id，可以是class
			var obj = typeof obj == 'object' ? obj : document.getElementById(obj);
			var locClass = obj.className;
			// var reg = new RegExp('(/^|\s*)'+oClass+'(\s*|$/)');
			// if(reg.test(obj.className)){
			// 	return true;
			// }
			var arr = [];
			arr = obj.className.split(' ');
			if(this.inArr(oClass,arr)){
				return true
			}
			return false;
		},
		//给obj添加class
		addClass:function(oClass,obj){
			var obj = typeof obj == 'object' ? obj : document.getElementById(obj) ;
			var locClass = obj.className;
			var arr = [];
			arr = obj.className.split(' ');
			if(!this.hasClass(oClass,obj)){
				arr.push(oClass);
			}
			obj.className = arr.join(' ');	
		},
		//删除obj制定的class
		removeClass:function(oClass,obj){
			var obj = typeof obj == 'object' ? obj : document.getElementById(obj) ;
	        var locClass = obj.className;
	        var arr = [];
	        var tempArr = [];
	        // var reg = new RegExp('(/^|\s*)'+oClass+'(\s*|$/m)');
	        // alert(obj.className.match(reg))
	        arr = obj.className.split(' ');
			if(this.hasClass(oClass,obj)){
				tempArr = this.removeArr(oClass,arr);
				obj.className = tempArr.join(' ');	
			}
			return false;
			
		},
		//模仿confirm,msg为提示消息，fn为回调
		confirmFunc:function(msg,fn){
			var mask = document.createElement('div');
		    var msg = typeof msg !== 'undifined' ? msg : '请您再确认一次！' ;
			mask.style.cssText = 'background: #000; opacity: 0.3; filter: alpha(opacity = 30); width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; display: block; z-index: 100;';

			var pop = document.createElement('div');
			pop.style.cssText= 'width: 300px; z-index: 101; height: 150px; position: fixed;font-size:100%; left: 50%; top: 50%; display: block; margin-left: -150px; margin-top: -75px; border: 1px solid #0098E1; background: #fff;';
			var str = '';
			str = '<a href="javascript:;" id="close" style="position:absolute;right:10px;top:10px;color:#0098E1;font-size:100%;text-decoration:none;">关闭</a><p style="padding:20px;text-align: center;font-size: 14px;">'+msg+'</p><div style="margin-top:20px;height:50px;text-align: center;overflow: hidden;"><a href=\"javascript:;\" style="width:80px;height:30px;display: inline-block;font-size:14px;text-align: center;margin:auto 10px;text-decoration:none;color:#fff;line-height: 30px;border-radius: 4px;background: #0098E1;" id=\"yes\">确定</a><a href=\"javascript:;\" style="width:80px;font-size:14px;height:30px;text-decoration:none;display: inline-block;text-align: center;margin:auto 10px;color:#fff;line-height: 30px;border-radius: 4px;background: #0098E1;" id=\"no\">取消</a></div>';
			pop.innerHTML = str;
			document.body.appendChild(mask);
			document.body.appendChild(pop);
		    document.onclick = function(e){
		    	var e = e || window.event;
		    	var target = e.target || e.srcElement;
		    	if(target.id == 'yes'){
		    		document.body.removeChild(mask);
			        document.body.removeChild(pop);
			        if(fn && typeof fn == 'function'){
			        	fn();
			        }        
		    	}
		    	if(target.id == 'no'){
		    		document.body.removeChild(mask);
			        document.body.removeChild(pop);
		    	}
		    	if(target.id == 'close'){
		    		document.body.removeChild(mask);
			        document.body.removeChild(pop);
		    	}
		    }
		},
		//渐隐.不兼容ie8以下
		fadeIn:function(dur,obj,fn){
			var opacity = 0;
			if(this.getStyle(obj,'opacity') == 1){
				return false;
			}
			//设置动画时间间隔
			var interval = 50;
			//相应动画间隔的透明度增长大小
			var gap = interval / dur;
	        obj.style.display = 'block';
			function tempFunc(){	    
	            if(opacity <= 1){
	            	opacity = opacity + gap;
			        obj.style.opacity = opacity;
			        if(this.isIE()){
				        obj.style.filter = 'alpha(opacity='+opacity *100+')';
				        obj.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(Opacity=' + opacity * 100 + ')';
			        }
			        if(opacity >= 1){
			        	clearInterval(obj.timer);
			        	obj.style.opacity = Math.round(opacity)
		            	if(typeof fn == 'function'){
		            		fn();
		            	}
			        }
	            } 

			}
			obj.timer = window.setInterval(tempFunc,interval);
		},
		fadeOut:function(dur,obj,fn){
	        var opacity = 1;
			if(this.getStyle(obj,'opacity') == 0){
				return false;
			}
			//设置动画时间间隔
			var interval = 50;
			//相应动画间隔的透明度增长大小
			var gap = interval / dur;
			function tempFunc(){	    
	            if(opacity <= 1){
	            	opacity = opacity - gap;
			        obj.style.opacity = opacity;
			        if(this.isIE()){
				        obj.style.filter = 'alpha(opacity='+opacity *100+')';
				        obj.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(Opacity=' + opacity * 100 + ')';
			        }
			        if(opacity <= 0){
			        	obj.style.display = 'none'
			        	clearInterval(obj.timer);
			        	obj.style.opacity = Math.round(opacity)
		            	if(typeof fn == 'function'){
		            		fn();
		            	}
			        }
	            } 

			}
			obj.timer = window.setInterval(tempFunc,interval);
		},

		// //动画
		// animation:function(obj,start,end){
  //           if(start < end){
                
  //           }else{

  //           }
  //           function tempFunc(){

  //           }
		// }

		//倒计时，通常用于发送短信验证
		limitTime:function(n,o){
	        var t = n;
	        if(n == 0 ){
	            o.disabled = false;
	            o.innerHTML = '重新发送';
	            n = t;
	        }else{
	            n--;
	            o.disabled = true;
	            o.innerHTML = n +'s';
	            setTimeout(function(){
	               time(n,o);
	            },1000);
	        }
		},
		//运动函数
		moveStart:function(obj,json,fn){
            var that = this;
            clearInterval(obj.timer);
            obj.timer = setInterval(function() {
                var bStop = true;
                for (attr in json) {
                    var icur = 0;
                    icur = (attr == 'opacity') ? Math.round(that.getStyle(obj, attr) * 100) : parseInt(that.getStyle(obj, attr));
                    var iSpeed = (json[attr] - icur) / 8;
                    // alert('iSpeed'+iSpeed)
                    iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);
                    if (icur != json[attr]) {
                        bStop = false;
                    }
                    if (attr == 'opacity') {
                        obj.style.filter = 'alpha(opacity:' + (icur + iSpeed) + ')';
                        obj.style.opacity = (icur + iSpeed) / 100;
                    } else {
                        obj.style[attr] = icur + iSpeed + 'px';
                    }
                }
                if (bStop) {
                    clearInterval(obj.timer);
                    if (fn) {
                            fn();
                    }
 
                }
            }, 30);
        }
	};
	if(typeof define === 'function'){
        //定义接口
        define(function(require,exports,module){
        	exports.sam = new samBase();
        })
    }else{
    	window.sam = new samBase();
    }
	
})(window)

   

