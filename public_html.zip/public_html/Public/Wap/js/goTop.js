/**
 * @authors Sam (645298225@qq.com)
 * @date    2016-04-13 11:15:02
 * @version \1.0
 */

define(function(require,exports,module){
   
	function goTop(scrollTopValue,defineTopValue){
		// var $$ = require('./samBase').sam;
		// var aBtn = document.createElement('a');
		// var body = document.body;
		// var bodyLenth = body.childNodes.length;
		// aBtn.className = 'go-top';
		// aBtn.href='javascript:';

		// if(scrollTopValue > defineTopValue){
		// 	if(!$$.getByClass(aBtn.className)[0]){
		// 		body.appendChild(aBtn);
		// 	}
			
		// 	$$.addEvent(document,'touchstart',function(e){
		// 		var oTarget = e.target;
  //                if(oTarget.className == aBtn.className){
  //               	var $ = require('./jquery');

  //               	if(scrollTopValue > defineTopValue){
  //               	    $('html,body').stop(true,true).animate({scrollTop:0});
  //               	}
  //               }
		// 	})
		// }else{
  //           if(document.body.childNodes[bodyLenth-1].className==aBtn.className){
  //           	document.body.removeChild(document.body.childNodes[bodyLenth-1]);
  //           	$$.addEvent(document,'touchstart',null)
  //           }
			
		// }
		var $ = require('./jquery');
		var $$ = require('./samBase').sam;
		var oBtn = $$.getByClass('go-top')[0];
		if(scrollTopValue>defineTopValue){
            $('.go-top').show(300);
		}else{
			 $('.go-top').hide(300);
		}
         
         $$.addEvent(oBtn,'touchstart',function(){
         	$('html,body').stop(true,false).animate({scrollTop:0},300);
         })
		
	}
	
	exports.goTop = goTop;

})
