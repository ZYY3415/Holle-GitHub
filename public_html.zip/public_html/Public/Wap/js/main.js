/**
 * @authors Sam (645298225@qq.com)
 * @date    2016-04-12 14:28:18
 * @version \1.0
 */

define(function(require,exports,module){
	require('./loader').loader();
	window.onscroll = function(){
		var headerId = document.getElementById('header');
		var scrollTopValue = document.body.scrollTop;
		require('./fixedFunc').fixedFunc(headerId,scrollTopValue);
		require('./goTop').goTop(scrollTopValue,400)
	}
	var oPhoto = document.getElementById('photo');
	if(oPhoto)
	{
		
		var slider = require('./photoSlider').photoSlider;
		new slider({
		wrap: oPhoto,
		loop: true,
		autoPlay:true,
		autoTime:4000,
		pagination:true
		});
	
	}
	
})	
