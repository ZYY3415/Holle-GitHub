/**
 * 
 */
$(function(){

var button1		=$('#button1');
var bank		=$('#bank');
var subbank		=$('#subbank');
var bankaccount	=$('#bankaccount');
var money		=$('#money');
var balance		=$('#balance');


var error		=$('.error');

	
	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		 $.ajax({
			url:formurl,
			type:'POST',
			data:{'bank':bank.val(),'subbank':subbank.val(),'bankaccount':bankaccount.val(),'money':money.val()},
			dataType:'json',
			beforeSend: function(){
				if(bank.val()=='')
				{
					error.text('选择收款银行');
					flag=false;
				}
				if(subbank.val()=='')
				{
					error.text('收款银行地址');
					flag=false;
				}
				if(bankaccount.val()=='')
				{
					error.text('收款银行卡号');
					flag=false;
				}
				var pattern=/^\d+(\.\d{2})?$/;
				if( !pattern.test(money.val()) )
				{
					error.text('取款金额最小单位是分');
					flag=false;
				}
				if(money.val()>balance.val())
				{
					error.text('取款金额不能大于余额');
					flag=false;
				}				
				if(flag)
				{
					button1.attr('disable','disable');
					error.last().text('正在提交中，请稍等....');
					return true;
				}
				else
				{
					return false;
				}
			},
			success: function(redata){
				if(redata.code==1)
				{
					error.text('申请成功，2个工作日内到账！');
					setTimeout(function(){
						window.location.href=successurl;
					},1000);
				}
				else
				{
					button1.removeAttr('disable');
				}
					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.last().text('异常错误');
			}
		});
	
	});
	
});
