/*
 * 
 * photoSlider.v1.0
 * create by Gavin
 * 2015-3-26
 * http://www.j--d.com/photoSlider/
 * 
 * */

(function(window){
	function photoSlider(a) {
		if(!a){
			return;
		}
		this.wrap = a.wrap;
		this.wrapWidth = this.wrap.offsetWidth;
		this.wrapInner = this.wrap.getElementsByTagName("ul")[0];
		this.lists = this.wrap.getElementsByTagName("li");
		this.listLength = this.lists.length;
		this.forOffset = document.getElementById('for-offset') ? document.getElementById('for-offset') :null;
		
		var d = {
			loop: false,
			autoPlay: 0,
			autoTime: 5000,
			speed: 300,
			pagination: true
		};
		this.ops = a || {};
		for (var b in d) {
			if (typeof a[b] === "undefined") {
				a[b] = d[b]
			} else {
				if (typeof a[b] === "object") {
					for (var c in d[b]) {
						if (typeof a[b][j] === "undefined") {
							a[b][j] = d[b][j]
						}
					}
				}
			}
		}
        console.log(this.ops)
		this.init();
		this.bindEvent()
	}

	//创建加载前动画
	photoSlider.prototype.createSprite = function() {
		console.log(this.lists.length)
		var c = document.createElement("div");
		c.className = "spinner";
		for (var b = 0; b < 3; b++) {
			var e = document.createElement("div");
			e.className = "bounce" + parseInt(b + 1);
			c.appendChild(e)
		}
		this.wrap.appendChild(c);
		var a = new Image();
		a.src = this.lists[this.listLength - 1].getElementsByTagName("img")[0].src;
		console.log(a.src)
	
		var d = this;
		
		a.onload = function() {
			c.remove();
			d.wrapInner.style.opacity = "1"
		}
		
		console.log(d.listLength)
		if(d.listLength > 0){
			
			c.remove();
			d.wrapInner.style.opacity = "1"
		}
		
	};

	//初始化组件的各种参数
	photoSlider.prototype.init = function() {
		this.lists = this.wrap.getElementsByTagName("li");
		this.listLength = this.lists.length;
		this.ratio = this.wrap.offsetHeight / this.wrap.offsetWidth;
		this.wrapWidth = this.wrap.offsetWidth;
		this.wrapHeight = this.wrap.offsetHeight;
		this.wrapInner.style.width = this.wrapWidth + "px";
		this.index = 0;
		console.log(this.listLength)
		if(this.listLength == 1){
			this.ops.autoPlay = false ;
		}
		// this.lists.length == 1 && this.ops.autoPlay = false ;
		
		for (var c = 0; c < this.listLength; c++) {
			this.lists[c].style.width = this.wrapWidth + "px";
			this.lists[c].style.webkitTransform = "translate3d(" + c * this.wrapWidth + "px,0,0)";
			var b = this.lists[c].getElementsByTagName("img")[0] ? this.lists[c].getElementsByTagName("img")[0] : this.lists[0];
			if (b.height / b.width > this.ratio) {
				b.style.height = this.wrapHeight + "px" ;
			}else if(b.height / b.width < this.ratio){
				b.style.width = this.wrapWidth + "px"
			}else{
				this.wrap.style.height = this.forOffset.offsetHeight + 'px'
			}

			//delete只能删除节点属性
			delete b
		}
		if (this.ops.pagination) {

			this.createBullet()
		}
		if (this.ops.loop) {
			this.copyLists();
			this.index = 1;
			this.listLength = this.wrapInner.getElementsByTagName("li").length
		}
		if (this.ops.autoPlay) {
			this.autoPlay()
		}
		var d = this,
			a = null;
		window.onresize = function() {
			if (a) {
				clearTimeout(a)
			}
			a = setTimeout(function() {
				d.resizeInit()
			}, 300)
		}
	};
	photoSlider.prototype.resizeInit = function() {
		this.ratio = this.wrap.offsetHeight / this.wrap.offsetWidth;
		this.wrapWidth = this.wrap.offsetWidth;
		this.wrapHeight = this.wrap.offsetHeight;
		this.wrapInner.style.width = this.wrapWidth + "px";
		for (var b = 0; b < this.listLength; b++) {
			this.lists[b].style.width = this.wrapWidth + "px";
			if (this.index > b) {
				this.Transform3d(this.lists[b], -this.wrapWidth, false)
			} else {
				if (this.index < b) {
					this.Transform3d(this.lists[b], this.wrapWidth, false)
				}
			}
			var a = this.lists[b].getElementsByTagName("img")[0];
			if (a.height / a.width > this.ratio) {
				a.style.height = this.wrapHeight + "px";
				a.style.width = "auto"
			} else {
				a.style.width = this.wrapWidth + "px";
				a.style.height = "auto"
			}
			delete a
		}
	};
	photoSlider.prototype.copyLists = function() {
		var b = document.createElement("li"),
			a = document.createElement("li");
		b.style.cssText = this.wrapWidth + "px";
		b.style.webkitTransform = "translate3d(-" + this.wrapWidth + "px,0,0)";
		b.innerHTML = this.lists[this.listLength - 1].innerHTML;
		a.style.cssText = this.wrapWidth + "px";
		a.style.webkitTransform = "translate3d(" + this.listLength * this.wrapWidth + "px,0,0)";
		a.innerHTML = this.lists[0].innerHTML;
		this.wrapInner.insertBefore(b, this.wrapInner.firstChild);
		this.wrapInner.appendChild(a)

	};
	photoSlider.prototype.createBullet = function() {
		pagination = document.createElement("div");
		pagination.className = "pagination";

		for (var a = 0; a < this.listLength; a++) {
			span = document.createElement("span");
			if (this.index == a) {
				span.className = "active"
			}
			pagination.appendChild(span)
		}
		this.wrap.appendChild(pagination);
		this.bulletLists = pagination.getElementsByTagName("span");
		this.bllength = this.bulletLists.length
	};
	photoSlider.prototype.autoPlay = function() {
		var a = this;
		clearInterval(a.timer);
		if(a.ops.autoPlay){
			a.timer = setInterval(function() {
				a.move("+1")
			}, a.ops.autoTime)
		}
		
	};
	photoSlider.prototype.stopPlay = function() {
		clearInterval(this.timer)
	};
	photoSlider.prototype.Transform3d = function(c, b, a) {
		if (!c) {
			throw new Error("未指定动画元素！")
		} else {
			c.style.webkitTransform = "translate3d(" + b + "px,0,0)"
		}
		if (a) {
			c.style.webkitTransition = this.ops.speed + "ms ease-out"
		} else {
			c.style.webkitTransition = "none"
		}
	};
	photoSlider.prototype.loopSetting = function(b) {
		var a = this;
	
		switch (b) {
			case 0:
				console.log(b)
				setTimeout(function() {
					mindex = a.listLength - 2;
					a.index = mindex;
					a.Transform3d(a.lists[0], -a.wrapWidth, false);
					a.Transform3d(a.lists[mindex], 0, false);
					a.Transform3d(a.lists[mindex + 1], a.wrapWidth, false);
					a.Transform3d(a.lists[mindex - 1], -a.wrapWidth, false);
					for (var c = mindex - 1; c > 0; c--) {
						a.Transform3d(a.lists[c], -a.wrapWidth, false)
					}
				}, a.ops.speed);
				break;
			case a.listLength - 1:
				setTimeout(function() {
					mindex = 1;
					a.index = mindex;
					a.Transform3d(a.lists[mindex], 0, false);
					a.Transform3d(a.lists[mindex + 1], a.wrapWidth, false);
					a.Transform3d(a.lists[mindex - 1], -a.wrapWidth, false);
					a.Transform3d(a.lists[a.listLength - 1], a.wrapWidth, false);
					for (var c = mindex + 1; c < a.listLength - 1; c++) {
						a.Transform3d(a.lists[c], a.wrapWidth, false)
					}
				}, a.ops.speed);
				break
		}
	};
	photoSlider.prototype.move = function(a) {
		var c;
		if (typeof a == "number") {
			c = this.index
		} else {
			if (typeof a == "string") {
				c = this.index + a * 1
			}
		}
		if (c > this.listLength - 1) {
			c = this.listLength - 1
		} else {
			if (c < 0) {
				c = 0
			}
		}
		if (this.ops.pagination) {
			for (var b = 0; b < this.bllength; b++) {
				if (b == c - 1) {
					this.bulletLists[b].setAttribute("class", "active")
				} else {
					this.bulletLists[b].setAttribute("class", "");
					if (c > this.bllength) {
						this.bulletLists[0].setAttribute("class", "active")
					} else {
						if (c == 0) {
							this.bulletLists[this.bllength - 1].setAttribute("class", "active")
						}
					}
				}
			}
		}
		this.index = c;
		this.lists[c] && (this.Transform3d(this.lists[c], 0, true));
		this.lists[c + 1] && (this.Transform3d(this.lists[c + 1], this.wrapWidth, true));
		this.lists[c - 1] && (this.Transform3d(this.lists[c - 1], -this.wrapWidth, true));
		if (this.ops.loop) {
			this.loopSetting(this.index)
		}
	};
	photoSlider.prototype.bindEvent = function() {
		var e = this;
		var b = this.wrapWidth / 3;
		var d = function(f) {
			e.startX = f.touches[0].pageX;
			e.offsetX = 0;
			e.startTime = new Date() * 1;
			e.stopPlay()
		};
		var a = function(h) {
			h.preventDefault();
			e.offsetX = h.touches[0].pageX - e.startX;
			var g = e.index - 1;
			var f = g + 3;
			for (g; g < f; g++) {
				e.lists[g] && (e.Transform3d(e.lists[g], (g - e.index) * e.wrapWidth + e.offsetX, false))
			}
		};
		var c = function(g) {
			var f = new Date() * 1;
			if (f - e.startTime > 700) {
				if (e.offsetX >= b) {
					e.move("-1")
				} else {
					if (e.offsetX < -b) {
						e.move("+1")
					} else {
						e.move("0")
					}
				}
			} else {
				if (e.offsetX >= 60) {
					e.move("-1")
				} else {
					if (e.offsetX < -60) {
						e.move("+1")
					} else {
						e.move("0")
					}
				}
			}
			if(e.ops.autoPlay){
				console.log(e.ops.autoPlay)
			    e.autoPlay()
			}
		};
		e.wrap.addEventListener("touchstart", d, false);
		e.wrap.addEventListener("touchmove", a, false);
		e.wrap.addEventListener("touchend", c, false)
	};
	if(typeof define === 'function'){
        //定义接口
        define(function(require,exports,module){
        	exports.photoSlider = photoSlider;
        })
    }else{
    	window.photoSlider = photoSlider;
    }
})(window)