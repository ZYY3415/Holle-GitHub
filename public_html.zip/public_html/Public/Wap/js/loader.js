/**
 * @authors Sam (645298225@qq.com)
 * @date    2016-04-13 10:20:54
 * @version \1.0
 */

 function loader(){
   
 	var body = document.getElementsByTagName('body')[0];
    var loader = document.createElement('div');
    loader.className = 'loader-container';
    loader.innerHTML = '<div class="loader"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div><span class="dy-page-loader-text">正在加载</span>';
    body.appendChild(loader);
    window.onload = function () {
        setTimeout(function () {
            loader.style.display = 'none';
        }, 200);
    };
 }
 if(typeof define === 'function'){
 	define(function(require,exports,module){
 		exports.loader = loader;
 	});
 }