/**
 * 
 */
$(function(){

var fromtime	=$('#fromtime');
var totime		=$('#totime');
var submit1	  	=$('#submit1');
var pic_view	=$('.pic-view');    

	
	submit1.click(function(){

		var rehtml='';
		var temptml='';
		pic_view.html('');
		
		 $.ajax({
			url:czjlurl,
			type:'POST',
			data:{'fromtime':fromtime.val(),'totime':totime.val()},
			dataType:'json',
			beforeSend: function(){
				submit1.attr('disable','disable');
			},
			success: function(redata){
				submit1.removeAttr('disable');
				$.each(redata,function(index,value){
					
					rehtml='<li>'+
						'<span>'+value.id+'</span>'+
						'<span>'+value.pay_time+'</span>'+
						'<span>'+value.money+'</span>'+
						'<span>0</span>'+
						'<span>'+value.status+'</span>'+
						'<span>'+value.retime+'</span>'+
					'</li>';
					temptml=temptml+rehtml;
				});	
				pic_view.html(temptml);

			},
			error: function(){
				submit1.removeAttr('disable');
				pic_view.html('<li><span>信错误，请重新查询！！！</span></li>');
			}
		});
	
	});
	
});
