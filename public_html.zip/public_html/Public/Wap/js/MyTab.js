/**
 * 
 * @authors sam (you@example.org)
 * @date    2016-02-25 16:15:51
 * @version 1.0
 */
//MyTab构造函数+原型模式
(function(window){
	function MyTab(id,options){
		var that = this,
		    doc = document;
		that.wrapper = typeof id == 'object' ? id : doc.getElementById(id);

		
        //选项
		that.options = options || {};

		//返回核心函数，不用在外部重新调用
		return this.tabAni();
	} 
	MyTab.prototype = {

		//获取css类名称函数
		getByClass : function(oParent,tClass){

			//保存目标到数组
			var arrResult = [];

			//获取父级元素
 			var  oClass = oParent.getElementsByTagName('*');

			//在全部的获取到子元素循环
			for(var i= 0 ;i<oClass.length ;i++){

			    //通过空格获取每个classname
				var tempArr = oClass[i].className.split(/\s+/);
				for(var j = 0 ;j < tempArr.length ; j++){
					if(tempArr[j] == tClass){
						arrResult.push(oClass[i]);
					}
				}

			}
			return arrResult;
		},

		//获取css样式函数
		getStyle : function(obj, attr){
			if (obj.currentStyle) {
				return obj.currentStyle[attr];
			} else {
				return getComputedStyle(obj, false)[attr];//获取样式的最终值，改变之后的值，没有的话就获取css样式的值
			}
		},

		//动画函数
		moveStart : function(obj,json,fn){
			var that = this;
            clearInterval(obj.timer);
			obj.timer = setInterval(function() {

				var bStop = true;
				for (attr in json) {
					var icur = 0;
					icur = (attr == 'opacity') ? Math.round(that.getStyle(obj, attr) * 100) : parseInt(that.getStyle(obj, attr));
					//icur 不断变化
					//json[attr]值写死，1920

					var iSpeed = (json[attr] - icur) / 8;
					// alert('iSpeed'+iSpeed)
					iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);
					if (icur != json[attr]) {
						bStop = false;
					}
					if (attr == 'opacity') {
						obj.style.filter = 'alpha(opacity:' + (icur + iSpeed) + ')';
						obj.style.opacity = (icur + iSpeed) / 100;
					} else {
						obj.style[attr] = icur + iSpeed + 'px';
					}
				}
				if (bStop) {
					clearInterval(obj.timer);
					if (fn) {
						    fn();
					}

				}
			}, 30);
		},

		//运动核心函数
		tabAni:function(){
			var that = this;
			that.tabNav = that.getByClass(that.wrapper,'tab-nav')[0].getElementsByTagName('li');
            that.line =that.getByClass(that.wrapper,'line')[0];

		    that.tabTxt = that.getByClass(that.wrapper,'txt');
		    that.b = true;
			for(var i = 0 ;i < that.tabNav.length ; i++){
		    	that.tabNav[i].onclick = (function(arg){
		            return function(){ 
			    		for(var j = 0 ; j < that.tabTxt.length ; j++){
			    			if(that.tabTxt[j].style.left == '0px' && j == arg){
			    				return false;
			    			}
			    			//判断滑动横线
			    			if(that.line){
			    				that.moveStart(that.line,{left:arg*60 + (arg+1)*50})
			    			}

			    			//添加class
			    			if(that.options.onClass){
                                that.tabNav[j].className ='';
                                that.tabNav[arg].className = that.options.onClass;
                            }
                            

                            //判断方向,事先要在css声明top or left
                            //默认横向

                            if(that.options.direction == 'horizontal'){
				                that.moveStart(that.tabTxt[j],{left:-that.options.moveStep},function(){
				                	that.tabNav[arg].className = that.options.onClass;
				                	that.moveStart(that.tabTxt[arg],{left:that.options.intMove})
				                })
			                }else if(that.options.direction == 'vertical'){
			                	that.moveStart(that.tabTxt[j],{bottom:-that.options.moveStep},function(){
				                	that.moveStart(that.tabTxt[arg],{bottom:that.options.intMove})
				                })
			                }else{
			                	that.moveStart(that.tabTxt[j],{left:-that.options.moveStep},function(){				                	
				                	that.moveStart(that.tabTxt[arg],{left:that.options.intMove})
				                })
			                }         
			            }
		            } 
		    	})(i);
		    }
		} 
	}

	//输出对象
	if(typeof exports !== 'undefined'){
		exports.MyTab = MyTab;
	}else{
		window.MyTab = MyTab;	
	} 
})(window)