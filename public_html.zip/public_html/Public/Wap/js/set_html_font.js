// JavaScript Document
var _w=$(window).width()>=640?640:$(window).width(); //640 / 4 = 160
var fontPercent=_w/4;
$('html').css('font-size',fontPercent); 


$(window).resize(
	function(){
	 _w=$(window).width()>=640?640:$(window).width(); //640 / 4 = 160
	 fontPercent=_w/4;
	$('html').css('font-size',fontPercent); 
	}

)


//html font-size:160px;
/*
1000/ 4  250px
640 / 4  160px
360 / 4  90px
320 / 4  80px

1rem = html的字体大小 160 
640 height 117
360 height  
320 height 

拿量度的数值 / 160 
*/