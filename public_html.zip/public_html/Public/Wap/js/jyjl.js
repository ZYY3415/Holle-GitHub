/**
 * 
 */
$(function(){

var fromtime	=$('#fromtime');
var totime		=$('#totime');
var submit1	  	=$('#submit1');
var pic_view	=$('.pic-view');    
	
	submit1.click(function(){
		var rehtml='';
		var temptml='';
		pic_view.html('');
		
		 $.ajax({
			url:jyjlurl,
			type:'POST',
			data:{'fromtime':fromtime.val(),'totime':totime.val()},
			dataType:'json',
			beforeSend: function(){
				submit1.attr('disable','disable');
				
			},
			success: function(redata){

				submit1.removeAttr('disable');
				if(redata&&redata.success)
				{	
					$.each(redata.data,function(index,value){
			         
					var Deal=value.Deal;
					var Opentime=getDate(value.Opentime*1000);
					var Openprice=value.Openprice;
					var Volume=value.Volume;
					var Profit=Math.floor(value.Profit*100)/100;
					var Stoploss=value.Stoploss;
					var Takeprofit=value.Takeprofit;
					var Closetime=getDate(value.Closetime*1000);
					var Closeprice=value.Closeprice;
					var Spread=value.Spread;					
					
					if(value.Type!='balance')
					{
						temptml='<li>'+
							'<span>'+Deal+'</span>'+
							'<span>'+Opentime+'</span>'+
							'<span>'+Openprice+'</span>'+
							'<span>'+Volume+'</span>'+
							'<span>'+Profit+'</span>'+
							'<span>'+Stoploss+'</span>'+
							'<span>'+Takeprofit+'</span>'+
							'<span>'+Closetime+'</span>'+
							'<span>'+Closeprice+'</span>'+
							'<span>'+Spread+'</span>'+
						'</li>';					
	
						rehtml=temptml+rehtml;
						}
					});
					

					pic_view.html(rehtml);
					
				}
				else
				{
					pic_view.text('异常错误或者无交易数据，请重新查询');
				}
			
					 
			},
			error: function(){
				submit1.removeAttr('disable');
				pic_view.text('异常错误，请重新查询');
			}
		});
	
	});
	
	getDate=function(tm)
	{
		var   now  =new Date(tm);
		var   year  =now.getFullYear();     
		var   month =now.getMonth()+1;     
		var   date  =now.getDate();     
		var   hour  =now.getHours();     
		var   minute=now.getMinutes();     
		var   second=now.getSeconds();
		if(minute*1<10)
		{
			minute='0'+minute;
		}
		if(second*1<10)
		{
			second='0'+second;
		}
		return   year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second; 
	}
	
});
