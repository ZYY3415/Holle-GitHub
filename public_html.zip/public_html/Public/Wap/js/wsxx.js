/**
 * 
 */
$(function(){

var button1		=$('#button1');
var vname		=$('#vname');
var rname		=$('#rname');
var sex			=$('#sex');
var birthday	=$('#birthday');
var cardtype	=$('#cardtype');
var card		=$('#card');
var province	=$('#s_province');
var city		=$('#s_city');
var county		=$('#s_county');
var address		=$('#address');
var tel			=$('#tel');
var email		=$('#email');

var error		=$('.error');
	
	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		 $.ajax({
			url:formurl,
			type:'POST',
			data:{'vname':vname.val(),'rname':rname.val(),'sex':sex.val(),'birthday':birthday.val(),'cardtype':cardtype.val(),'card':card.val(),'province':province.val(),'city':city.val(),'county':county.val(),'address':address.val(),'tel':tel.val(),'email':email.val()},
			dataType:'json',
			beforeSend: function(){
				if(rname.val()=='')
				{
					rname.parent().next().text('请填写姓名');
					flag=false;
				}
				if(rname.val().length>30)
				{
					rname.parent().next().text('姓名不得大于30个字符！');
					flag=false;
				}
				if(vname.val().length>30)
				{
					vname.parent().next().text('昵称不得大于30个字符！');
					flag=false;
				}
				if( new Date(birthday.val()).getTime() > new Date().getTime() )
				{
					birthday.parent().next().text('出生年月日大于现在');
					flag=false;
				}
				if(!cardtype.val())
				{
					cardtype.parent().next().text('请选择证件类型');
					flag=false;
				}

				if(card.val()==1)
				{
					var pattern=/^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
					if(!pattern.test(card.val()))
					{
						card.parent().next().text('身份证号码格式错误！');
						flag=false;
					}
				}

				if(!card.val())
				{
					card.parent().next().text('请填写证件号码');
					flag=false;
				}
				if(card.val().length>20)
				{
					card.parent().next().text('证件号码超过20位了');
					flag=false;
				}
				if(address.val().length>200)
				{
					address.parent().next().text('联系地址不能大于200个字符');
					flag=false;
				}
				pattern=/^1(\d){10}$/;
				if(!pattern.test(tel.val()))
				{
					tel.parent().next().text('手机号码格式不正确');
					flag=false;
				}
				pattern=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
				if(!pattern.test(email.val()))
				{
					email.parent().next().text('电子邮箱格式不正确');
					flag=false;
				}
				if(flag)
				{
					button1.attr('disable','disable');
					error.last().text('正在提交中，请稍等....');
					return true;
				}
				else
				{
					return false;
				}
			},
			success: function(redata){
				button1.removeAttr('disable');
				if(redata.code==1)
				{
					error.last().text(redata.message);
				}
				else
				{
					error.last().text(redata.message);
				}
					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.last().text('异常错误');
			}
		});
	
	});
	
});
