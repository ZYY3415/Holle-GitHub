/**
 * 
 */
$(function(){

var button1		=$('#button1');

var money		=$('#money');
var bank		=$('#bank');

var error		=$('.error');


	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		$.ajax({
			url:formurl,
			type:'POST',
			data:{'money':money.val(),'bank':bank.val()},
			dataType:'json',
			beforeSend: function(){
				if(money.val()*1<100)
				{
					error.first().text('充值不能小于100美元');
					flag=false;
				}
				if(bank.val()=='')
				{
					error.last().text('选择收款银行');
					flag=false;
				}			
				if(flag)
				{
					button1.attr('disable','disable');
					error.last().text('正在提交中，请稍等....');
					return true;
				}
				else
				{
					return false;
				}
			},
			success: function(response){
				if(response.code==1)
				{
					document.write('<form action="https://www.rongyf.com/user/HC0001.tran" method="post" id="pay">'+
				    '<input type="hidden" name="Merno" 	    value="'+response.Merno+'">'+
				    '<input type="hidden" name="Signtype"   value="'+response.Signtype+'">'+
				    '<input type="hidden" name="Prdordno"   value="'+response.Prdordno+'">'+
				    '<input type="hidden" name="bizType"    value="'+response.bizType+'">'+
				    '<input type="hidden" name="Prdordnam"  value="'+response.Prdordnam+'">'+
				    '<input type="hidden" name="Ordamt"     value="'+response.Ordamt+'">'+
				    '<input type="hidden" name="TranType"   value="'+response.TranType+'">'+
				    '<input type="hidden" name="Paytype"    value="'+response.Paytype+'">'+
				    '<input type="hidden" name="bankCode"   value="'+response.bankCode+'">'+
				    '<input type="hidden" name="custnam"    value="'+response.custnam+'">'+
				    '<input type="hidden" name="custmob"    value="'+response.custmob+'">'+
				    '<input type="hidden" name="custmail"   value="'+response.custmail+'">'+
				    '<input type="hidden" name="custcardno" value="'+response.custcardno+'">'+
				    '<input type="hidden" name="Return_url" value="'+response.Return_url+'">'+
				    '<input type="hidden" name="Notify_url" value="'+response.Notify_url+'">'+
				    '<input type="hidden" name="inMsg"      value="'+response.inMsg+'">'+
				    '<input type="hidden" name="ThirdParty" value="'+response.ThirdParty+'">'+
				    '<input style="display:none;" type="submit" value="确定提交">'+
				    '</form><script>document.forms["pay"].submit();</script>');
		    
				}
				else
				{
					button1.removeAttr('disable');
				}
					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.last().text('异常错误');
			}
		});
		
	
	
	});
	
});
