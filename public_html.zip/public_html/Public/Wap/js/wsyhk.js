/**
 * 
 */
$(function(){

button1		=$('#button1');
bank	=$('#bank');
subbank=$('#subbank');
bankaccount=$('#bankaccount');
error		=$('.error');

	
	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		 $.ajax({
			url:formurl,
			type:'POST',
			data:{'bank':bank.val(),'subbank':subbank.val(),'bankaccount':bankaccount.val()},
			dataType:'json',
			beforeSend: function(){
				if(bank.val()=='')
				{
					bank.parent().next().text('请选择开户银行');
					flag=false;
				}
				if(subbank.val()=='')
				{
					subbank.parent().next().text('请填写开户支行');
					flag=false;
				}
				if(bankaccount.val()=='')
				{
					bankaccount.parent().next().text('请填写银行卡号');
					flag=false;
				}
				
				if(flag)
				{
					button1.attr('disable','disable');
					error.last().text('正在提交中，请稍等....');
					return true;
				}
				else
				{
					return false;
				}
			},
			success: function(redata){
				button1.removeAttr('disable');
				if(redata.code==1)
				{
					error.last().text(redata.message);
				}
				else
				{
					error.last().text(redata.message);
				}
					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.last().text('异常错误');
			}
		});
	
	});
	
});
