/*注册页面表单校验*/
$(function(){
	var bnt_telcode	=$('#bnt_telcode');
	var reg_form	=$('#reg_form');
	var reg_button	=$('#reg_button');
	var rname		=$('input[name="rname"]');
	var tel			=$('input[name="tel"]');
	var telcode		=$('input[name="telcode"]');
//	var txyzm		=$('input[name="txyzm"]');
	var ibcode		=$('#ibcode');
	var email	=$('#email');
	
	reg_button.click(function(){
		
		var flag=true;
		$('.red-border').removeClass('red-border');			
		$('.error').text('');
		
		$.ajax
        ({
            type : 'POST',
            url : formurl,
            data : {'rname':rname.val(),'tel':tel.val(),'telcode':telcode.val(),'email':email.val(),'ibcode':ibcode.val()},
            dataType : 'json',
            beforeSend : function (xhr, settings){
            	if(rname.val() == ""){
					rname.parent().addClass("red-border");
                    rname.parent().next().text('姓名不能为空!');
                    flag=false;
                }
                if(!(/^1([23578])\d{9}$/.test(tel.val()))){
					tel.parent().addClass("red-border");
                    tel.parent().next().text('请输入正确的手机号码！');
                    flag=false;
                }
                if(telcode.val() == ""){
					telcode.parent().addClass("red-border");
                    telcode.parent().next().text('验证码不能为空！');
                    flag=false;
                }
                if(telcode.val().length !== 6){
					telcode.parent().addClass("red-border");
                    telcode.parent().next().text('请填写6位数短信验证码！');
                    flag=false;
                }
 				if(!(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(email.val()))){
					email.parent().addClass("red-border");
                    email.parent().next().text('请填写正确的电子邮箱！');
					return false;
                }
				if(flag)
				{
					reg_button.attr('disabled','disabled');
				}
				else
				{
					return false;
				}
            },
            complete : function (xhr, status){},
            success : function (responseText, status, xhr)
            {
            	reg_button.removeAttr('disabled','disabled');
                if(responseText.code == 1){
					telcode.parent().addClass("red-border");
                    telcode.parent().next().text('注册成功，等待客服发送登录账号密码到您手机！');
                    window.location.href = successurl;
                }
                else{
					telcode.parent().next().text(responseText.message);
                }
            },
            error : function()
            {
            	telcode.parent().next().text('异常错误请联系工作人员协助开户');
            },
        });
	});
	
	//获取短线验证码
	bnt_telcode.click(function(){
			
		$('.red-border').removeClass('red-border');
		$('.error').text('');
        $.ajax
        ({
            type : 'POST',
            url : telcodeurl,
            data : {'tel':tel.val()},
            dataType : 'json',
            beforeSend : function (xhr, settings) 
            {
                var pattern1=/^1\d{10}$/;
                if(!pattern1.test(tel.val()))
                {
                    tel.parent().addClass('red-border');
                    tel.parent().next().text('请输入正确的手机号码!');
					randyzm();
                    return false;
                }
				else{
					bnt_telcode.attr('disabled','disabled');return true;
				}

            },
            complete : function (xhr, status) 
            {
            },
            success : function (response, status, xhr)
            {
				bnt_telcode.removeAttr('disabled');                
                if(response.code==1)
                {
                    var i=120;
                    t=setInterval(function(){
                        if(i<=0)
                        {                               
                            bnt_telcode.text('获取动态码');
                            clearInterval(t); 
                        }
                        else
                        {
                            bnt_telcode.text(i+'秒后重获');
                        }
                        i=i-1;           
                    },1000);
                }
                else if(response.code==-1)
                {
                    tel.parent().addClass('red-border');
                    tel.parent().next().text(response.message);
					randyzm();
                }
                else
                {
					bnt_telcode.parent().addClass('red-border');
                    bnt_telcode.parent().next().text(response.message);
					randyzm();
                }   
            },
        });

	});
	
	
	/*验证码刷新*/
    $(".codeImg").click(function(){
        randyzm();
    });
	
	randyzm=function(){
		$(".codeImg").attr("src", yzmurl +'?ramd=' + Math.random());
	}
});
