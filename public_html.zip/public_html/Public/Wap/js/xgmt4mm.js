/**
 * 
 */
$(function(){

button1		=$('#button1');
newpassowrd1=$('#newpassowrd1');
newpassowrd2=$('#newpassowrd2');
yzm	  		=$('#yzm');
error		=$('.error');

	
	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		 $.ajax({
			url:formurl,
			type:'POST',
			data:{'newpassowrd1':newpassowrd1.val(),'newpassowrd2':newpassowrd2.val(),'yzm':yzm.val()},
			dataType:'json',
			beforeSend: function(){
				if( newpassowrd1.val().length<6)
				{
					newpassowrd1.parent().next().text('新密码最少6位！');
					flag=false;
				}
				if( newpassowrd1.val().length>10)
				{
					newpassowrd1.parent().next().text('新密码不能大于10位！');
					flag=false;
				}
				if( !(/[a-zA-Z]/.test(newpassowrd1.val())&&/[0-9]/.test(newpassowrd1.val())) )
				{
					newpassowrd1.parent().next().text('新密码是6-10位的字母和数字！');
                    flag=false;
				}
				if( newpassowrd2.val().length<6)
				{
					newpassowrd2.parent().next().text('确认密码最少6位！');
					flag=false;
				}
				if( newpassowrd2.val().length>20)
				{
					newpassowrd2.parent().next().text('确认密码不能大于20位！');
					flag=false;
				}
				if( !(/[a-zA-Z]/.test(newpassowrd2.val())&&/[0-9]/.test(newpassowrd2.val())) )
				{
					newpassowrd2.parent().next().text('新密码是6-10位的字母和数字！');
                    flag=false;
				}
				if(newpassowrd2.val()!=newpassowrd1.val())
				{
					newpassowrd2.parent().next().text('确认密码和新密码不一致！');
					flag=false;
				}
				var pattern=/^\d{4}$/;
				if(!pattern.test(yzm.val()))
				{
					yzm.parent().next().text('验证码是4位数字');
					flag=false;
				}
				
				if(flag)
				{
					button1.attr('disable','disable');
					error.last().text('请稍等，正在提交数据中....');
					return true;
				}
				else
				{
					txyzm();
					return false;
				}
			},
			success: function(redata){
				txyzm();
				button1.removeAttr('disable');
				if(redata.code==1)
				{
					error.last().text(redata.message);
				}
				else
				{
					error.last().text(redata.message);
				}
					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.last().text('异常错误');
			}
		});
	
	});
	
});
