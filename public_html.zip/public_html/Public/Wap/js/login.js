/**
 * 
 */
$(function(){

form1		=$('#form1');
button1		=$('#button1');
mt4account	=$('#form1 input[name="mt4account"]');
password	=$('#form1 input[name="password"]');
yzm	  		=$('#form1 input[name="yzm"]');
error		=$('.error');

	
	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		 $.ajax({
			url:formurl,
			type:'POST',
			data:{'mt4account':mt4account.val(),'password':password.val(),'yzm':yzm.val()},
			dataType:'json',
			beforeSend: function(){
				if(mt4account.val()=='')
				{
					mt4account.parent().next().text('请输入MT4账号');
					flag=false;
				}
				if(password.val()=='')
				{
					password.parent().next().text('请输入密码');
					flag=false;
				}				
				var pattern=/^\d{4}$/;
				if(!pattern.test(yzm.val()))
				{
					yzm.parent().next().text('验证码是4位数字');
					flag=false;
				}
				
				if(flag)
				{
					button1.attr('disable','disable');
					return true;
				}
				else
				{
					txyzm();
					return false;
				}
			},
			success: function(redata){
				txyzm();
				button1.removeAttr('disable');
				if(redata.code==1)
				{
					window.location.href=ucurl;
				}
				else
				{
					error.last().text(redata.message);
				}
					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.last().text('异常错误');
			}
		});
	
	});
	
});
