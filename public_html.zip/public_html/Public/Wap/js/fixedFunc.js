/**
 * @authors Sam (645298225@qq.com)
 * @date    2016-04-12 12:09:22
 * @version \1.0
 */

define(function(require,exports,module){
	function fixedFunc(obj,scrollTopValue){
        obj = typeof obj == 'object' ? obj : document.getElementById(obj);
        if(!obj){
        	return;
        }
        var	thisOffsetHeight = obj.offsetHeight;
        var $$ = require('./samBase').sam;
    	if(scrollTopValue > thisOffsetHeight){
    		$$.addClass('active',obj);
    	}else{
    		$$.removeClass('active',obj)
    	}        
	}
	exports.fixedFunc = fixedFunc;
})