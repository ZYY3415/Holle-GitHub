/**
 * 
 */
$(function(){

var button1		=$('#button1');
var button2		=$('#button2');
var filebank	=$('#filebank');
var error		=$('.error');


    $('#upcard').dropzone({
        url:upload,
        autoProcessQueue:true,
        maxFiles: 1,
        maxFilesize: 0.512,
        thumbnailWidth: 569,
        thumbnailHeight: 333,
        acceptedFiles: ".jpg,.jpeg,.png,.gif",
		dictFileTooBig:'图片最大为512K，请重新上传',
		dictInvalidInputType:'图片类型只能jpg、jpeg、png、gif格式',
		init: function() {
			this.on("success", function(file,response) {
				if(response.code==1){
					filebank.val(response.url);
				}
				else{
					error.text(response.errormsg);
				}
			});
		}
    });
	
	button2.click(function(){
		$('#upcard').html('');
		$('#filebank').val('');
	});
	
	button1.click(function(){
		
		error.text('');
		var flag=true;
		
		 $.ajax({
			url:formurl,
			type:'POST',
			data:{'filebank':filebank.val()},
			dataType:'json',
			beforeSend: function(){
				if($('#filebank').val==''){
	                error.text("* 请上传有效银行卡照片！");
	                return false;
	            }
	            else{
	            	button1.attr('disabled','disabled')
	                return true;
	            }
			},
			success: function(responseText){
				button1.removeAttr('disabled');
				if(responseText.code == 1)
				{
                    error.text("银行卡上传成功！");
				}
                else
                {
                    error.text(responseText.message);
                }					 
			},
			error: function(){
				button1.removeAttr('disable');
				error.text('异常错误');
			}
		});
	
	});
	
});
