<?php
return array(
    //PDO连接方式
    'DB_TYPE' => 'mysql', // 数据库类型
<<<<<<< .mine
    //'DB_HOST' => '192.168.1.108', // 服务器地址
    'DB_HOST' => '127.0.0.1', // 服务器地址
    'DB_NAME' => 'jyjrwx_com', // 数据库名 jyjrwx_com
||||||| .r419
    'DB_HOST' => '192.168.1.108', // 服务器地址
    'DB_NAME' => 'firma_db', // 数据库名 jyjrwx_com
=======
    'DB_HOST' => '192.168.1.196', // 服务器地址
    'DB_NAME' => 'firma_db', // 数据库名 jyjrwx_com
>>>>>>> .r451
    'DB_USER' => 'root', // 用户名 jieyin
   // 'DB_PWD' => 'Dykj123!@#', // 密码 Jie^&*yin
    'DB_PWD' =>'root',
    'DB_PORT' => 3306, // 端口
    'DB_PREFIX' => 'gjb_', // 数据库表前缀
    'DB_CHARSET' => 'utf8', // 字符集

    //页面Trace，调试辅助工具
    'SHOW_PAGE_TRACE'  =>false,
    'LOG_RECORD' => true,
    'LOG_LEVEL' => 'EMERG,ALERT,CRIT,ERR,DEBUG',
    'SHOW_ERROR_MSG' => false,    // 显示错误信息

    //伪静态的设置
    'URL_HTML_SUFFIX' => 'html',
    // 配置你原来的分组列表
    'MODULE_ALLOW_LIST' => array('Home', 'Gadmin', 'Wap'),
    // 配置你原来的默认分组
    'DEFAULT_MODULE' => 'Home',
    // 默认模板文件后缀
    'TMPL_TEMPLATE_SUFFIX' => '.html',
    //设置默认主题目录
    'DEFAULT_THEME' => 'Default',

    'SESSION_PREFIX' => 'b2222', // session 前缀
    'COOKIE_PREFIX' => 'b2222', //Cookie前缀 避免冲突

    // 默认false 表示URL区分大小写 true则表示不区分大小写
    'URL_CASE_INSENSITIVE' => true,

    'URL_MODEL' => 2,

    //客服qq
    'KFQQ' => '773538831',

    //短信通知电话
    'DX_TEL' => array(
        'REG' => '4008520618',               //注册通知 客服电话
        'PAYIN' => '13349508783,13766506055',   //入金通知
        'PAYOUT' => '13349508783,13766506055',   //出金通知
    ),

    'PAYMENT' => array('account' => 'JIEYING', 'key' => 'npN=&v8cax57nKKV2$5UI^X1#vNEnG8d'),
    'MT4SRV' => array('address' => '101.200.233.225:8443',//srv.firma1999.com
                        'defaultgroup'=>'1000'),//5,14
    'DYZF_APP_ID'=>'10',//第一支付的应用id
    'DYZF_CLIENT'=>'firma',//第一支付的应用名称
    'DYZF_KEY'=>'Na8JAMrrJ9BjcXDK3B5BGwzfgd6Np0kJ',//第一支付蜜月

    'SMS_APP_ID'=>'8aaf07085dcad420015dcf73c84f0198',//云通讯中的飞尔玛中的应用id,验证码tmpid=200739

);
