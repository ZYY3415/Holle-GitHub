<?php
/**
 * 返回日志记录对象
 *
 * @param string $name
 * @return Logger
 */
function getlogger($name='root'){
    vendor('apache_log4php.Logger');
    Logger::configure('log4php.config.xml');
    $log=Logger::getLogger($name);
    return $log;
}

function paysign($params, $key)
{
    if (!is_array($params)) return false;

    ksort($params);

    $tmp = '';
    foreach ($params as $k => $v) {
        if ($k == 'signature' || !$v) continue;
        $tmp .= sprintf('%s%s', strtolower($k), strtolower($v));
    }

    $tmp .= $key;

    return sha1($tmp);
}

function payverify($params, $sig, $key)
{
    if (!is_array($params)) return false;

    $s1 = paysign($params, $key);

    return $s1 == $sig;
}


/**
 * 从数据库Exchangerate读取最后一条汇率
 * @return 返回汇率
 */
function exchangerate()//获取汇率
{
    return M('Exchangerate')->order('id desc')->limit(1)->getField('exchangerate');
}

function sxf()//获取汇率
{
    return M('Sxf')->where(['id' => 1])->getField('fl');
}

/**
 * 生成mt4账号
 * @return 返回mt4账号
 */
function greataccount()
{
    //$initmt4=20001;
    $initmt4 = 18080001;//MT4初始账号
    //$initmt4=1000001;  //测试账号
    $User = M('User');
    //非第一次
    if ($User->field('id')->where(array('mt4account' => $initmt4))->find()) {
        $mt4 = $User->order('id desc')->limit(1)->getField('mt4account');
        $mt4 = $mt4 + 1;
        if ($mt4 < $initmt4) $mt4 = $initmt4;
    } else//如果是第一次
    {
        $mt4 = $initmt4;
    }
    //检查是否重复
    while ($User->field('id')->where(array('mt4account' => $mt4))->find()) {
        $mt4 = $mt4 + 1;
    }
    return $mt4;
}

/**
 * 生成mt4密码
 * @return 生成mt4密码
 */
function greatmt4pass()
{
    $bigletter = array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z');
    $smallletter = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z');
    return $bigletter[mt_rand(0, 25)] . $smallletter[mt_rand(0, 25)] . mt_rand(1000, 9999);
}

/**
 * 验证码验证
 * @param $code 要验证的验证码
 * @param $id =1
 * @return true or false
 */
function checkcode($code, $id = 1)
{
    $verify = new \Think\Verify();
    $verify->reset = false;
    return $verify->check($code, $id);
}

/**
 * 手机验证码
 * @param $tel 手机号码
 * @return $errormsg
 */
//function telcode($tel)//手机验证码
//{
//    if (session('?telcode') && (time() - session('telcode')['teltime'] < 120)) {
//        $errormsg['code'] = -20;
//        $errormsg['message'] = '短信验证码只能2分钟发送一次';
//        return $errormsg;
//    } else {
//        $smscode = mt_rand(100001, 999999);
//        $telcode['smscode'] = $smscode;
//        $telcode['teltime'] = time();
//        session('telcode', $telcode);
//        $re=sendsms($tel, array($smscode), "200739");
//        getlogger()->debug($re);//debug
//        $errormsg['code'] = 1;
//        $errormsg['message'] = '手机验证码发送成功！';
//        return $errormsg;
//    }
//}

/**
 * 证件类型
 * @param $para 参数 1身份证、2护照、3其它
 * @return string 证件类型
 */
function showcardtype($para)
{
    $cardtype = array('', '身份证', '护照', '其它');
    return $cardtype[$para];
}

/**
 * 性别
 * @param $para 参数 1男、2女
 * @return string 证件类型
 */
function showsex($para)
{
    $sex = array('', '男', '女');
    return $sex[$para];
}

/**
 * 支付状态
 * @param $para 参数 0新申请、1已完成
 * @return string 支付状态
 */
function showpayinstatus($para)
{
    $sta = array('新申请', '已完成');
    return $sta[$para];
}

/**
 * url地址中文字符url编码
 * @return 无
 */
function myurl()
{
    if (stripos(__SELF__, '?') !== false) {
        $param = I('get.');
        foreach ($param as $key => $val) {
            $param[$key] = urlencode($val);
        }
        redirect(U(ACTION_NAME, $param));
    }
}

function mychecktime()
{

    $fromtime = I('fromtime') ? strtotime(I('fromtime')) :strtotime('2000-01-01');
    $totime = I('totime') ? strtotime(I('totime')) : time();

    $errormsg['code'] = 1;
    $errormsg['message'] = '校验通过';

//    if (!$fromtime) {
//        $errormsg['code'] = -1;
//        $errormsg['message'] = '请选择开始时间';
//        return $errormsg;
//    }
//    if (!$totime) {
//        $errormsg['code'] = -2;
//        $errormsg['message'] = '请选择结束时间';
//        return $errormsg;
//    }
    if ($fromtime > $totime) {
        $errormsg['code'] = -3;
        $errormsg['message'] = '开始时间不可以大于结束时间';
        return $errormsg;
    }
    if ($fromtime > time()) {
        $errormsg['code'] = -4;
        $errormsg['message'] = '开始时间不能大于当前时间';
        return $errormsg;
    }
    if ($totime > time()) {
        $errormsg['code'] = -5;
        $errormsg['message'] = '结束不能大于当前时间';
        return $errormsg;
    }
    return $errormsg;
}


/**
 * 发送模板短信
 * @param to 手机号码集合,用英文逗号分开
 * @param datas 内容数据 格式为数组 例如：array('Marry','Alon')，如不需替换请填 null：array('Marry','Alon')，如不需替换请填 null
 * @param $tempId 模板Id,测试应用和未上线应用使用测试模板请填写1，正式应用上线后填写已申请审核通过的模板ID
 */
function sendsms($to, $datas, $tempId)
{
    Vendor('Sms.SendTemplateSMS');
    return sendTemplateSMS($to, $datas, $tempId);
}

/**
 * 手机验证码
 * @param $tel 手机号码
 * @param string $tmpid 短信模板id
 * @return $errormsg
 */
function telcode($tel,$tmpid)//手机验证码
{
    if (session('?telcode') && (time() - session('telcode')['teltime'] < 120)) {
        $result['code'] = -1;
        $result['message'] = '短信验证码只能2分钟发送一次';
        return $result;
    } else {
        $smscode = mt_rand(100001, 999999);
        $telcode['smscode'] = $smscode;
        $telcode['teltime'] = time();
        $telcode['tel']=$tel;
        session('telcode', $telcode);
        Vendor('Sms.SendTemplateSMS');
        $re=sendTemplateSMS($tel, array($smscode), $tmpid);
        if ($re->statusCode==0) {
            $result['code'] = 1;
            $result['message'] = '验证码已发送至您的手机';
        }else{
            $result['code'] = -1;
            $result['message'] = $re->statusMsg;
        }
        return $result;
    }
}

/**
 * 手机验证码检查，验证完后销毁验证码增加安全性 ,<br>返回true验证码正确，false验证码错误
 *
 * @return boolean <br>true：手机验证码正确，false：手机验证码错误
 */
function check_mobile_code($mobile = '', $verifycode = ''){
    $session_mobile_code=session('telcode');
    $verifycode= empty($verifycode)?I('request.telcode'):$verifycode;
    $mobile= empty($mobile)?I('request.tel'):$mobile;

    $result= false;

    if (!empty($session_mobile_code) && $session_mobile_code['smscode'] == $verifycode
        &&$session_mobile_code['tel']==$mobile) {
        session('telcode',null);//取消session
        $result = true;
    }

    return $result;
}

/**
 * 发送邮件
 * @param $status [选择邮件内容1、2、3、4、5]
 * @param array $arr [发送内容]
 * @return 无
 */
function email($status, $arr)
{
    $mail = new \Vendor\phpmailer\PHPMailer();
    $mail->IsSMTP(); // 使用SMTP方式发送
    $mail->CharSet = 'UTF-8';// 设置邮件的字符编码
    $mail->Host = 'smtp.163.com'; // 您的企业邮局服务器
    $mail->Port = 465; // 设置端口
    $mail->SMTPSecure = 'ssl';
    $mail->SMTPAuth = true; // 启用SMTP验证功能

//     $mail->Username = '1097575111@qq.com'; // 邮局用户名(请填写完整的email地址)
//     $mail->From = '1097575111@qq.com'; //邮件发送者email地址
//     $mail->Password = 'jbsrxrzjzavshaga'; // 邮局密码

    // $mail->Username = '805001166@qq.com'; // 邮局用户名(请填写完整的email地址)
    // $mail->From = '805001166@qq.com'; //邮件发送者email地址
    // $mail->Password = 'grznnneytvrlbebj'; // 邮局密码
    // $mail->FromName = "来自百富金融网站的通知"; //发邮件者的姓名
    $mail->Username = 'hj_100dykj@163.com'; // 邮局用户名(请填写完整的email地址)
    $mail->From = 'hj_100dykj@163.com'; //邮件发送者email地址
    $mail->Password = 'qhdykj123'; // 邮局密码
    $mail->FromName = "来自FIRMA的通知"; //发邮件者的姓名

    // 3460606757@qq.com
    if ($status == '4')//注册账户
    {
        //$mail->AddAddress('805001166@qq.com', 'FIRMA');
        //$mail->AddAddress('814180088@qq.com', 'FIRMA');
        $mail->AddAddress('3460606757@qq.com', 'FIRMA');
        $mail->AddAddress('qibiao222@126.com', 'FIRMA');
        $mail->AddAddress('2583581990@qq.com', 'FIRMA');
        $mail->AddAddress('156228566@qq.com', 'FIRMA');//测试邮箱，后期可以删除
    } elseif ($status == '2' || $status == '3')//出入金
    {
        //$mail->AddAddress('906008800@qq.com', 'FIRMA');
        //$mail->AddAddress('853109593@qq.com', 'FIRMA');
        //$mail->AddAddress('814180088@qq.com', 'FIRMA');
        $mail->AddAddress('3460606757@qq.com', 'FIRMA');
        $mail->AddAddress('qibiao222@126.com', 'FIRMA');
        $mail->AddAddress('2583581990@qq.com', 'FIRMA');
        $mail->AddAddress('156228566@qq.com', 'FIRMA');//测试邮箱，后期可以删除
    } elseif ($status == '6')//取回邮件
    {
        //$mail->AddAddress($arr['myemail'], 'FIRMA');
        $mail->AddAddress('3460606757@qq.com', 'FIRMA');
        $mail->AddAddress('qibiao222@126.com', 'FIRMA');
        $mail->AddAddress('2583581990@qq.com', 'FIRMA');
    } elseif ($status == '7' || $status == '8')//发送开户邮件给客户
    {
        //$mail->AddAddress($arr['myemail'], 'FIRMA');
        $mail->AddAddress('3460606757@qq.com', 'FIRMA');
        $mail->AddAddress('qibiao222@126.com', 'FIRMA');
        $mail->AddAddress('2583581990@qq.com', 'FIRMA');
    }
    $mail->IsHTML(true); // set email format to HTML //是否使用HTML格式
    $mail->Subject = '来自FIRMA网站的通知';//"PHPMailer测试邮件"; //邮件标题
    $arr = array("1" => '<meta charset="utf-8"><div><p>来自FIRMA网站的通知:在
					<span style="color:red">' . date('Y-m-d H:i:s') . '</span>，有一个人申请了<span style="color:red;">模拟账户</span>：
					</p><p>姓名：<span style="color:red">' . $arr['name'] . '</span></p>
					<p>手机号：<span style="color:red">' . $arr['tel'] . '</span></p></div>',
        "2" => '<meta charset="utf-8"><div>
					<p>【FIRMA】提现通知：<span style="color:red">' . date('Y-m-d H:i:s') . '</span></p>
					<p>姓名：<span style="color:red">' . $arr['rname'] . '</span></p>
                    <p>账号：<span style="color:red">' . $arr['mt4account'] . '</span></p>
					<p>手机号：<span style="color:red">' . $arr['tel'] . '</span></p>
					<p>提现金额：<span style="color:red">' . $arr['money'] . '美元</span></p>
					<p>手续费：<span style="color:red">' . $arr['sxf'] . '美元</span></p>
				    <p>到账金额：<span style="color:red">' . $arr['dzje'] . '美元</span></p>
					<p>银行账号：<span style="color:red">' . $arr['bank_account'] . '</span></p>
					<p>开户支行地址：<span style="color:red">' . $arr['bank_address'] . '</span></p>
                    <p>自动扣余额：<span style="color:red">' . $arr['mt4log'] . '</span></p>
					</div>',
        "3" => '<meta charset="utf-8"><div>
					<p>【FIRMA】入金通知:在<span style="color:red">' . date('Y-m-d H:i:s') . '</span></p>
					<p>姓名：<span style="color:red">' . $arr['rname'] . '</span></p>
					<p>账户：<span style="color:red">' . $arr['account'] . '</span></p>
					<p>手机：<span style="color:red">' . $arr['tel'] . '</span></p>
					<p>入金：<span style="color:red">' . $arr['money'] . '美元</span></p>
					<p>订单号：<span style="color:red">' . $arr['prdordno'] . '</span></p>
                    <p>自动入金返回状态：<span style="color:red">' . $arr['mt4log'] . '</span></p>
					<p>入金状态：<span style="color:red">成功</span></p></div>',
        "4" => '<meta charset="utf-8"><div>
					<p>【FIRMA】网站注册申请通知:<span style="color:red">' . date('Y-m-d H:i:s') . '</span></p>
					<p>姓名：<span style="color:red">' . $arr['rname'] . '</span></p>					
					<p>账号：<span style="color:red">' . $arr['mt4account'] . '</span></p>
                    <p>密码：<span style="color:red">' . $arr['mt4pass'] . '</span></p>
					<p>邀请码：<span style="color:red">' . $arr['ibcode'] . '</span></p>
                    <p>手机号：<span style="color:red">' . $arr['tel'] . '</span></p>
					<p>邮箱：<span style="color:red">' . $arr['email'] . '</span></p>
                    <p>状态：<span style="color:red">' . $arr['suceess'] . '</span></p>',
        "5" => '<meta charset="utf-8"><div>
					<p>来自FIRMA网站的通知:在<span style="color:red">' . date('Y-m-d H:i:s') . '</span>，有一个用户申请了<span style="color:red">开立账户</span>：</p>
					<p>姓名：<span style="color:red">' . $arr['name'] . '</span></p>
					<p>手机号：<span style="color:red">' . $arr['tel'] . '</span></p>
					<p>性别：<span style="color:red">' . $arr['sex'] . '</span></p>
					<p>证件号码：<span style="color:red">' . $arr['card'] . '</span></p>
					<p>国籍：<span style="color:red">' . $arr['country'] . '</span></p>
					<p>银行账号：<span style="color:red">' . $arr['cardnum'] . '</span></p>
					<p>邮箱：<span style="color:red">' . $arr['email'] . '</span></p>
					<p>开户支行地址：<span style="color:red">' . $arr['address'] . '</span></p>',
        "6" => '<meta charset="utf-8"><div>
					<p>来自FIRMA网站的通知:在<span>' . date('Y-m-d H:i:s') . '
					<p>您的验证码是：<span style="color:red">' . $arr['emailcode'] . '</span>请于2分钟内正确输入</p>',
        "7" => '<meta charset="UTF-8"><div style="font-size:16px;">
                    <p style="font-weight:bold;">尊敬的 <span style="color:#c2425b;" >' . $arr['rname'] . '</span></p>
                    <p>您好，您于<b> ' . date('Y-m-d') . ' </b>在<a href="http://firma2010.hk" target="_blank">FIRMA官网</a>提交的注册申请已审核通过，您的账户已成功开通。</p>
                    <p><b style="background:#c2425b;color:#ffffff;padding:5px 5px 5px 5px;border-radius:2px;">账户号码：</b><span style="padding:0 30px 0 10px;">' . $arr['mt4account'] . '</span><b style="background:#c2425b;color:#ffffff;padding:5px 5px 5px 5px;border-radius:2px;">账户密码：</b><span style="padding:0 0 0 10px;">' . $arr['mt4pass'] . '</span></p>		
                    <p>&nbsp;</p>
                    <p>◆<a href="http://firma2010.hk/login.html" target="_blank">点击此处</a>登录用户中心完善您的个人资料和银行资料。</p>
                    <p>◆<a href="http://shang.qq.com/open_webaio.html?sigt=1ff95772d9b970c4e0019f11832e419f53e2f97b6291fe18d87e85c0262118cb1167a57a49447b9d65cb1fc4eb8773c4&sigu=b15c670289d5d9d06cffa7d8a91fded973aef8516a75508c4cedec4b62dcb1a3d76670a039f5758a&tuin=3460606757"  target="_blank" >点击此处</a>咨询24小时在线客服。</p>
                    <p>◆<a href="http://firma2010.hk/downloadcenter/pc.html" target="_blank">点击此处</a>立即下载FIRMAMT4交易软件。</p>
                    <p>&nbsp;</p>
                    <p>若有任何疑问，请随时致电<b>4008-547-659</b>，或联系FIRMA官网24小时在线客服。</p>
                    <p><b>感谢您对FIRMA外汇交易平台的支持！</b></p></div>',
        "8" => '<meta charset="UTF-8"><div style="font-size:14px;">
                    <p>尊敬的' . $arr['rname'] . '</p>
                    <p style="margin-top:30px;">您好，您在我司提交的经纪商合作申请已通过审核，您的经纪商：</p>
                    <p style="margin-top:30px;">1. 编号详细信息【 IB：' . $arr['ibcode'] . ' ，后台密码：' . $arr['ibpass'] . ' 】</p>
                    <p>2. MT4交易账户【账户：' . $arr['mt4account'] . ' ， 密码：' . $arr['mt4pass'] . ' 】</p>
                    <p style="font-weight:bold;margin-top:30px;">温馨提示：请勿轻易删除或泄露该信息</p>
                    <p style="margin-top:30px;"><a href="http://firma2010.hk/login.html">◆点击此处</a> 登录用户中心完善个人资料</p>
                    <p><a href="http://firma2010.hk/downloadcenter/pc.html">◆点击此处</a> 立即下载FIRMA MT4 交易软件。</p>
                    <p><a href="http://firma2010.hk/">◆点击此处</a> 咨询客服安装经纪商后台软件及使用教程。</p>
                    <p style="margin-top:30px;">若有任何疑问，请随时致电FIRMA官网24小时在线客服电话：13766506055。</p>
                    <p>感谢您对FIRMA外汇交易平台的支持和信赖！</p>
                    </div>',
    );
    $mail->Body = $arr[$status];
    $mail->Send();
//     if(!$mail->Send())
//     {
//         return "错误原因: " . $mail->ErrorInfo;
//         exit;
//     }

//     return  "邮件发送成功";
}

/**
 * 请求接口返回内容
 * @param  string $url [请求的URL地址]
 * @param  string $params [请求的参数]
 * @param  int $ipost [是否采用POST形式]
 * @return  string
 */

function juhecurl($url, $params, $ispost = 1)
{
    $httpInfo = array();
    $ch = curl_init();
    foreach ($params as $key => $value) {
        $params[$key] = iconv("utf-8", "gb2312//IGNORE", $value);
    }
    //$params = iconv("utf-8","gb2312//IGNORE",$params);//utf-8转成gb2312
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.172 Safari/537.22');
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    if ($ispost) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);

        curl_setopt($ch, CURLOPT_URL, $url);
    } else {
        if ($params) {
            curl_setopt($ch, CURLOPT_URL, $url . '?' . $params);
        } else {
            curl_setopt($ch, CURLOPT_URL, $url);
        }
    }
    $response = curl_exec($ch);
    if ($response === FALSE) {
        //echo "cURL Error: " . curl_error($ch);
        return false;
    }
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $httpInfo = array_merge($httpInfo, curl_getinfo($ch));
    //var_dump($httpInfo);
    curl_close($ch);
    //echo $response;
    return $response;
}

/**
 * 向MT4发送POST数据
 * @param $url [请求的URL地址]
 * @param array $post_data [发送参数]
 * @param int $flag [1是json解码,0是json不解码]
 * @return array
 */
function postmt4($url, $post_data, $flag = 1)
{
    $srv = C('MT4SRV.address');
    $url = 'https://' . $srv . '/' . $url;
    foreach ($post_data as $key => $value) {
        $post_data[$key] = iconv("utf-8", "gb2312//IGNORE", $value);
    }
//    如果是数组,则转换
    if(is_array($post_data)){
        $temp='';
        foreach ($post_data as $key => $value) {
            $temp=$temp.$key.'='.$value.'&';
        }
        $post_data=substr($temp,0,strlen($temp)-1);//去掉末尾的&
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    $output = curl_exec($ch);

    getlogger()->debug($output);//debug
    getlogger()->debug(curl_error($ch));//debug
    getlogger()->debug($url);
    getlogger()->debug($post_data);

    curl_close($ch);


    if ($output && ($flag == 1)) $output = json_decode($output, true);
    return $output;
}


//-----------------------------------
/**
 * @param $str
 * @param int $start
 * @param $length
 * @param string $charset
 * @param bool $suffix
 * @return string
 * @todo 截取中文字符
 */
function msubstr($str, $start = 0, $length, $charset = "utf-8", $suffix = true, $laststr = '...')
{
    if (function_exists("mb_substr")) {
        if ($suffix)
            return mb_substr($str, $start, $length, $charset) . $laststr;
        else
            return mb_substr($str, $start, $length, $charset);
    } elseif (function_exists('iconv_substr')) {
        if ($suffix)
            return iconv_substr($str, $start, $length, $charset) . $laststr;
        else
            return iconv_substr($str, $start, $length, $charset);
    }
    $re['utf-8'] = "/[x01-x7f]|[xc2-xdf][x80-xbf]|[xe0-xef]
                  [x80-xbf]{2}|[xf0-xff][x80-xbf]{3}/";
    $re['gb2312'] = "/[x01-x7f]|[xb0-xf7][xa0-xfe]/";
    $re['gbk'] = "/[x01-x7f]|[x81-xfe][x40-xfe]/";
    $re['big5'] = "/[x01-x7f]|[x81-xfe]([x40-x7e]|xa1-xfe])/";
    preg_match_all($re[$charset], $str, $match);
    $slice = join("", array_slice($match[0], $start, $length));
    if ($suffix) return $slice . $laststr;
    return $slice;
}

function curl_get($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

function greatecode()
{
    $Verify = new \Think\Verify();
    $Verify->useImgBg = true;
    $Verify->fontSize = 35;
    $Verify->length = 4;
    $Verify->codeSet = '0123456789';
    $Verify->useCurve = true;
    $Verify->entry(1);
}

/**
 * 检测移动端还是pc端
 * @return boolean
 */
function isMobile()
{
    if (isset($_SERVER['HTTP_X_WAP_PROFILE'])) {
        return true;
    }

    if (isset($_SERVER['HTTP_VIA'])) {
        if (stristr($_SERVER['HTTP_VIA'], "wap") !== false) {
            return true;
        }
    }

    if (isset($_SERVER['HTTP_USER_AGENT'])) {
        $clientKeyword = array('nokia',
            'sony',
            'ericsson',
            'mot',
            'samsung',
            'htc',
            'sgh',
            'lg',
            'sharp',
            'sie-',
            'philips',
            'panasonic',
            'alcatel',
            'lenovo',
            'iphone',
            'ipod',
            'blackberry',
            'meizu',
            'android',
            'netfront',
            'symbian',
            'ucweb',
            'windowsce',
            'palm',
            'operamini',
            'operamobi',
            'openwave',
            'nexusone',
            'cldc',
            'midp',
            'wap',
            'mobile');
        if (preg_match('/' . implode('|', $clientKeyword) . '/i', $_SERVER['HTTP_USER_AGENT'])) {
            return true;
        }
    }

    if (isset($_SERVER['HTTP_ACCEPT'])) {
        if ((stripos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (stripos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (stripos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < stripos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
            return true;
        }
    }

    return false;
}

function getgroup($mt4accounts)
{
    $url = 'getaccount';
    $accounts['accounts'] = array($mt4accounts);
    $accounts = json_encode($accounts);
    $post_data['data'] = $accounts;
    $result = postmt4($url, $post_data, 1);
    return $result['data'][0]['Group'];
}

?>
