<?php
namespace Gadmin\Controller;
use Think\Controller;

class LoginController extends Controller {

    public function index()
    {
        $this->display();
    }
    public function dologin()
    {
        if(IS_AJAX)
        {
            $Admin=D('Admin');
            $this->ajaxReturn($Admin->dologin());
        }
        else
        {
            $this->error('非法访问');
        }
    }
//     public function add()
//     {
//         $data['admin_name']='gjb';
//         $admin_password='gjb123';
//         $data['admin_password']=sha1($admin_password.'gjb123');
        
//         $Admin=M('Admin');
//         $Admin->add($data);
//     }

//     public function edit()
//     {
//         $where['admin_name']='admin';
//         $admin_password='gjb123';
//         $data['admin_password']=sha1($admin_password.'gjb123');

//         $Admin=M('Admin');
//         $Admin->where($where)->save($data);
//     }

    public function logout()
    {
        session('admin',null);
        session('loginuc',null);
        $this->redirect('/Gadmin/login');
    }
}