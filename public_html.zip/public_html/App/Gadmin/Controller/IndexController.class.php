<?php
namespace Gadmin\Controller;
use Think\Controller;

class IndexController extends Controller {
    
    //构造方法
    protected function _initialize()
    {
        header("Content-Type:text/html; charset=utf-8");
        $this->islogin();
    }
    private function islogin()
    {
        if(!session('?admin'))
        {
            $this->redirect('/Gadmin/login');
        }
    }
    
    public function index()
    {
        $this->display();
    }
    public function reg()
    {
        $this->display();
    }
    public function ibreg()
    {
        $this->display();
    }
    public function regadddo()
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn($User->regadddo());
        }
    }
    public function ibregadddo()
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn($User->ibregadddo());
        }
    }
    
    public function loginuc()
    {
        if(IS_AJAX)
        {
            if( session('?loginuc') || I('post.password')=='gjb888' )
            {
                $errormsg['code']=1;
                $errormsg['msg']='密码正确！';
                
                $mt4account=I('post.mt4account');
                $userinfo=M('User')->field('id,rname,tel,mt4account,agentid')->where(array('mt4account'=>$mt4account))->find();
                session('user',$userinfo);
                cookie('group',getgroup($mt4account));                
                session('loginuc','gjb888');
                
                $this->ajaxReturn($errormsg) ;
            }
            else
            {
                $errormsg['code']=-1;
                $errormsg['msg']='密码错误！';
                $this->ajaxReturn($errormsg) ;
            }
        }
        else
        {
            $this->display();
        }
    }
    
}