<?php
namespace Gadmin\Model;
use Think\Model;

class AdminModel extends Model
{
    public function dologin()
    {    
        if(!checkcode(I('post.yzm')))
        {
            $errormsg['code']=-1;
            $errormsg['message']='验证码不正确';
            return  $errormsg;
        }
        if(I('post.admin_name')=='')
        {
            $errormsg['code']=-2;
            $errormsg['message']='账号不能为空';
            return  $errormsg;
        }
        
        mb_internal_encoding("UTF-8");
        if(mb_strlen(I('post.admin_name'))>10)
        {
            $errormsg['code']=-3;
            $errormsg['message']='账号不能大于10位';
            return  $errormsg;
        }
        if(mb_strlen(I('post.admin_password'))!=6)
        {
            $errormsg['code']=-4;
            $errormsg['message']='密码是6位';
            return  $errormsg;
        }
        
        $list=$this->where(array('admin_name'=>I('post.admin_name')))->find();
        
        if($list['admin_password']!=sha1(I('post.admin_password').'gjb123'))
        {
            $errormsg['code']=-5;
            $errormsg['message']='用户名或密码错误!';
            return  $errormsg;
        }
        $admin['id']=$list['id'];
        $admin['admin_name']=$list['admin_name'];
        session('admin',$admin);
        
        $data['id']=$list['id'];
        $data['login_ip']=get_client_ip(1);
        $data['login_time']=time();
        $this->save($data);
        
        $errormsg['code']=1;
        $errormsg['message']=U('/Gadmin/index');
        return  $errormsg;
    }
    

}
?>