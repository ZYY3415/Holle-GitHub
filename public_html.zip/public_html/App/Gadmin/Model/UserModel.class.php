<?php
namespace Gadmin\Model;
use Think\Model;

class UserModel extends Model
{

    public function regadddo()
    {
        ini_set("max_execution_time", "200");
        $errormsg=$this->checkdata();
        if($errormsg['code']!=1) return $errormsg;
        $re=$this->receviedata();
    
        if($this->add($re['data'])===false)
        {
            $re['successgjb']=$re['successgjb'].'网站注册失败';
            $errormsg['code']=-20;
            $errormsg['message']='数据库新增失败！';
        }
        else
        {
            $re['successgjb']=$re['successgjb'].'网站注册成功';
            $errormsg['code']=1;
            $errormsg['message']='数据库新增成功！';
        }
        
        //发送短信给客服
        //sendsms(C('DX_TEL.REG'),array($data['mt4account'],$re['mt4pass']),"49200");
        sendsms(C('DX_TEL.REG'),array($re['data']['rname'],$re['data']['mt4account'],$re['mt4pass']),"82449");
        
        //发送短信客户
        sendsms($re['data']['tel'],array($re['data']['rname'],$re['data']['mt4account'],$re['mt4pass']),"82449");
        
        //邮件通知客服
        email('4',array(
        'rname'     =>$re['data']['rname'],
        'tel'       =>$re['data']['tel'],
        'mt4account'=>$re['data']['mt4account'],
        'email'     =>$re['data']['email'],
        'mt4pass'   =>$re['mt4pass'],
        'ibcode'    =>$re['data']['ibcode'],
        'suceess'   =>$re['successgjb']
        ));
        //邮件通知普通客户
        email('7', array(
        'rname'     =>$re['data']['rname'],
        'myemail'   =>$re['data']['email'],
        'mt4account'=>$re['data']['mt4account'],
        'mt4pass'   =>$re['mt4pass']
        ));

        return $errormsg;
    }
    
    
    private function checkdata()
    {
        ini_set("max_execution_time", "200");
        $errormsg['code']=1;
        $errormsg['message']='表单校验通过';
    
//         if(!checkcode(I('post.txyzm')))
//         {
//             $errormsg['code']=-8;
//             $errormsg['message']='图形验证码错误！';
//             return  $errormsg;
//         }
//         //手机验证码校验
//         if( (I('post.telcode')!=session('telcode')['smscode']) )
//         {
//             $errormsg['code']=-1;
//             $errormsg['message']='手机验证码错误！';
//             return $errormsg;
//         }
        mb_internal_encoding("UTF-8");
        if( (!I('post.rname')) || mb_strlen(I('post.rname'))>30 )
        {
            $errormsg['code']=-2;
            $errormsg['message']='用户名为空或用户名不得超过30个字符';
            return $errormsg;
        }
        $pattern='/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel')))
        {
            $errormsg['code']=-3;
            $errormsg['message']='手机号码错误！';
            return  $errormsg;
        }
        $pattern='/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/';
        if (!preg_match($pattern, I('post.email')))
        {
            $errormsg['code']=-4;
            $errormsg['message']='电子邮箱错误！';
            return  $errormsg;
        }
    
        if(I('post.ibcode'))
        {
            $pattern='/^\d+$/';
            if (!preg_match($pattern,I('post.ibcode')))
            {
                $errormsg['code']=-5;
                $errormsg['message']='IB编码是数字！';
                return  $errormsg;
            }
        }
        if($this->where(array('tel' => I('post.tel') ))->find())
        {
            $errormsg['code']=-6;
            $errormsg['message']='手机号码已经注册过！';
            return  $errormsg;
        }
        if($this->where(array('email' => I('post.email')))->find())
        {
            $errormsg['code']=-7;
            $errormsg['message']='电子邮箱已经注册过！';
            return  $errormsg;
        }
        return $errormsg;
    }
    
    private function receviedata()
    {
        ini_set("max_execution_time", "200");
        $re['mt4pass']=greatmt4pass();
    
        $data['rname']=trim(I('post.rname'));
        $data['tel']=trim(I('post.tel'));
        $data['email']=trim(I('post.email'));
        $data['ibcode']=trim(I('post.ibcode'));
        if(!I('post.ibcode')) $data['ibcode']=10000;
        $data['password']=sha1($re['mt4pass'].'gjb');
        $data['reg_time']=time();
        $data['reg_ip']=get_client_ip(1);
        $data['status']=0;
        $data['agentid']=0;
        $data['mt4account']=greataccount();


    
        //注册捷引金融
        $post_data=array(
            'group'=>$data['ibcode'],//必须参数
            //'group'=>'TEST',//必须参数
            'name'=>$data['rname'],//必须参数
            'account'=>$data['mt4account'],
            'telephone'=>$data['tel'],
            'email'=>$data['email'],
            'primary_passwd'=>$re['mt4pass'],//必须参数
            'investor_passwd'=>$re['mt4pass']
        );
    
        $result=postmt4('addaccount', $post_data);
    
        $i=0;
        while( ($result['success']!=true)&&($i<8) )
        {
            sleep(3);
            $result=postmt4('addaccount', $post_data);
            $i=$i+1;
        }
    
        if($result['success'])
        {
            $data['mt4_success']=1;
            $data['mt4_errno']=$result['error'];
            $re['successgjb']='捷引金融注册成功；';
        }
        else
        {
            $data['mt4_success']=0;
            $data['mt4_errno']=$result['error'];
            $re['successgjb']="捷引金融注册失败，错误代码：{$result['error']}；";
        }
    
        $re['data']=$data;
        return $re;
    }    

    
    public function ibregadddo()
    {        
        ini_set("max_execution_time", "200");
        $errormsg=$this->checkdata();
        if($errormsg['code']!=1) return $errormsg;
        
        if(!I('post.ibpass'))
        {
            $errormsg['code']=-8;
            $errormsg['msg']='ib密码不能为空';
            return $errormsg;
        }
        
        $re=$this->receviedata();
        
        if($this->add($re['data'])===false)
        {
            $re['successgjb']=$re['successgjb'].'网站注册失败';
            $errormsg['code']=-20;
            $errormsg['message']='数据库新增失败！';
        }
        else
        {
            $re['successgjb']=$re['successgjb'].'网站注册成功';
            $errormsg['code']=1;
            $errormsg['message']='数据库新增成功！';
        }
        
        //发送短信给客服
        //sendsms(C('DX_TEL.REG'),array($data['mt4account'],$re['mt4pass']),"49200");
        sendsms(C('DX_TEL.REG'),array($re['data']['rname'],$re['data']['mt4account'],$re['mt4pass']),"82449");
        //发送短信客户
        sendsms($re['data']['tel'],array($re['data']['rname'],$re['data']['mt4account'],$re['mt4pass']),"82449");
        
        //邮件通知客服
        email('4',array(
            'rname'     =>$re['data']['rname'],
            'tel'       =>$re['data']['tel'],
            'mt4account'=>$re['data']['mt4account'],
            'email'     =>$re['data']['email'],
            'mt4pass'   =>$re['mt4pass'],
            'ibcode'    =>$re['data']['ibcode'],
            'suceess'   =>$re['successgjb']
        ));
        
        //代理商邮件
        email('8', array(
            'myemail'    =>$re['data']['email'],
            'rname'      =>$re['data']['rname'],
            'ibcode'     =>$re['data']['ibcode'],
            'ibpass'     =>I('post.ibpass'),
            'mt4account' =>$re['data']['mt4account'],
            'mt4pass'    =>$re['mt4pass']
        ));
        return $errormsg;
    }
}
?>