<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="/Public/Gadmin/css/base.css" type="text/css">
<script src="/Public/Gadmin/js/jquery.min.js" type="text/javascript"></script>
<script src="/Public/Gadmin/js/jquery.form.js" type="text/javascript"></script>
<script src="/Public/Gadmin/js/base.js" type="text/javascript"></script>

<link rel="stylesheet" href="/Public/Gadmin/css/login.css" type="text/css">
<script src="/Public/Gadmin/js/login.js" type="text/javascript"></script>
<script type="text/javascript">
var formurl="<?php echo U('login/dologin');?>";
var yzmurl="<?php echo U('/login/greatecode');?>";
</script>
    <title>捷引金融临时后台登陆</title>

</head>
<body>



<div id="login">
    <div class="lWelcome"><h3>捷引金融临时后台登陆</h3></div>
    
    <form id="login_form">
            <div><span>用户名：</span><input type="text" placeholder="请输入账号" name="admin_name"><b class="zcError"></b></div>
            <div><span>密码：</span><input type="password" placeholder="请输入密码" name="admin_password" maxlength="6"><b class="zcError"></b></div>
            <div><span>&nbsp;</span><img class="codeImg" src="<?php echo U('/Login/greatecode');?>" title="点击切换验证码"/></div>
            <div><span>验证码：</span><input type="text" placeholder="请输入验证码" name="yzm" maxlength="4"><b class="zcError"></b></div>
            <div id="button_center"><span>&nbsp;</span><button type="button" id="login_submit">登录</button></div>
    </form>
    
<p id="login_error"><P>
</div>

<div id="loading">
    <div class="loading-bg">&nbsp;</div>
    <div class="loading-img"><img src="/Public/Home/images/loading.gif" width="100" height="100" alt="正在加载"></div>
</div>
<!--正在加载-->
    

<footer>
</footer>
</body>
</html>