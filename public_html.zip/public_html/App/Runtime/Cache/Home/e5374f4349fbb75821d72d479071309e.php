<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>注册成功</title>
	</head>
	<body>
		<h1>恭喜您注册成功</h1>
	</body>
</html>