<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>下载中心</title>
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/dlCenter.css" />
		<style>
			.common-top-secnav .nav-list .item:nth-child(4) span {
			    color: #00c0ff; border-bottom: 3px solid #00c0ff;
			}
		</style>
	</head>

	<body>
		<div class="top-sec">
			<div class="common-top-secnav" id="unique-nav">
				<!--头部-->
				<div class="common-top-secnav">
	<a href="<?php echo U('/');?>" style="position: absolute; left:0; width:200px; height:95px;"></a>
	<ul class="nav-list">
		<li class="item">
			<span class="click-ele" href="<?php echo U('/');?>">首页</span>
		</li>
		<li class="item">
			<span class="click-ele" href="<?php echo U('about/product');?>">产品介绍</span>
		</li>
		<li class="item"><span class="click-ele" href="<?php echo U('about/aboutus');?>">关于我们</span></li>
		<li class="item"><span class="click-ele" href="<?php echo U('Downloadcenter/pc');?>">下载中心</span></li>
		<li class="item">
			<span class="click-ele personalCenter" href="<?php echo U('Usercenter/index');?>">
				个人中心<i></i>
			</span>
			<ul class="sub_list">
				<div class="box-s"></div>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/set">账户设置</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/recharge">账户充值</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/withdraw">账户提现</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/history">流水记录</li>
			</ul>
		</li>
	</ul>
	<ul class="right">
		<?php if(session('user')): ?><div class="topRight_login">
				<a href="<?php echo U('Usercenter/index');?>">
					<?php echo session('user')['rname']; ?>
				</a>&ensp;|&ensp;
				<a href="<?php echo U('login/logout');?>">退出</a>
			</div>
		<?php else: ?>
			<li class="click-ele" href="<?php echo U('login/index');?>">登录</li>
			<li class="click-ele" href="<?php echo U('reg/index');?>">注册</li><?php endif; ?>
	</ul>
</div>
			</div>
		</div>
		<div class="main-description">
			<div class="top">下载中心</div>
			<div class="des"><span>MT4 交易平台</span> 全称 MetaTrader4 客户终端，由 MetaQuotes 软件公司研发，MT4 交易平台功能强大，页面简洁，操作方便，最主要的建仓平仓功能简单易用，投资者可以透过设置止赚止损来进行控制风险，MT4 交易平台除了提供实时行情和交易功能外，还包括 18 种画线工具、9 个交易时段图表选项、30 种国际流行技术指标和声音预警提示。用户可进行下单、平仓、限价单、止损、止赢、查看实时新闻、公告、预警、查看报表，以及数据分析和处理等操作。 可谓集所有功能于一身，而且 MT4 交易平台占用计算机资源少，运行速度快，还可下载历史数据和图表，广受国际投资公司和投资者的青睐，截止至 2015 年底已有超过 70%的经纪公司和来自全世界三十多个国家的银行选择了 MT4 交易软件作为网络交易平台。全球超过 90%的零售交易量是通过 MT4 平台成交。</div>
		</div>
		<div class="meta-trader">
			<div class="left">
				<div>
					<p class="title">MetaTrader 4</p>
					<p class="p d">最流行的交易平台之一</p>
					<p class="p">适用于PC端</p>
					<p class="p">移动设备</p>
				</div>
			</div>
			<div class="right">
				<div>
					<div>
						<a class="a" href="javascript:void(0)">PC端下载</a>
						<a class="a" href="javascript:void(0)">iPhone下载</a>
						<a class="a" href="javascript:void(0)">Android下载</a>
					</div>
				</div>
			</div>
		</div>
		<div class="sub-footer">
			<div class="content">
				<p class="title">CONTACT FIRMA</p>
				<ul class="a-list">
					<li>
						<a href="index.html">首页</a>
					</li>
					<li>
						<a href="aboutUs.html">关于我们</a>
					</li>
					<li>
						<a href="#">下载中心</a>
					</li>
					<li>
						<a href="aboutUs.html">联系我们</a>
					</li>
				</ul>
				<div class="main">
					<ul>
						<li><span>+64（9）969-0750</span></li>
						<li><span>1136592462@qq.com</span></li>
						<li><span>香港九龙旺角道33号凯途发展大厦704室</span></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="ft-copy">Copyright © 2017 Firma公司版权所有</div>
	</body>

</html>
<script src="/Public/Home/js/utils.js"></script>
<script type="text/javascript">
(function() {
	var oclicks = document.querySelectorAll(".click-ele");
	for(var i = 0; i < oclicks.length; i++) {
		oclicks[i].onclick = function() {
			location.href = this.getAttribute("href");
		}
	}
})();
</script>