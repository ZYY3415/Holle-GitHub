<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>用户注册</title>
		<script src="/Public/Home/js/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/Home/css/common.css" />
		<link type="text/css" rel="stylesheet" href="/Public/Home/css/userRegistration.css" />
		<style>
			header{
				background: rgba(0,0,0,0); height:95px; border-bottom:3px solid #eee ;
			}
			.common-top-secnav .nav-list .item span {
				color:#000;
			}
			.common-top-secnav .nav-list .item.drop {
			    background: url(/Public/Home/img/down-arrow.png) 98.5px 47px no-repeat;
			}
			.common-top-secnav {
			    background: url(/Public/Home/img/logo1092.png) 10px 26px no-repeat;
			}
			.common-top-secnav .right li:first-of-type {
				background: rgba(0,0,0,0); color:#00c0ff;
				border:1px solid #00c0ff; 
			}
			.common-top-secnav .right li:last-of-type {
				background-color: #00c0ff;
				border:1px solid #00c0ff;
			}
			.common-top-secnav .right li:first-of-type::after {
			    content: "";
			    position: absolute;
			    display: block;
			    right: -12px;
			    top: 0;
			    bottom: 0;
			    width: 1px;
			    background-color: #00c0ff;
			}
			.item .personalCenter i{
				border-left: 6px solid transparent;
			    border-right: 6px solid transparent;
			    border-top: 9px solid #000;
			}
		</style>
	</head>

	<body style="background-color: #edf3f6;">
		<div class="main">
			<div>
				<header>
					<!--头部-->
					<div class="common-top-secnav">
	<a href="<?php echo U('/');?>" style="position: absolute; left:0; width:200px; height:95px;"></a>
	<ul class="nav-list">
		<li class="item">
			<span class="click-ele" href="<?php echo U('/');?>">首页</span>
		</li>
		<li class="item">
			<span class="click-ele" href="<?php echo U('about/product');?>">产品介绍</span>
		</li>
		<li class="item"><span class="click-ele" href="<?php echo U('about/aboutus');?>">关于我们</span></li>
		<li class="item"><span class="click-ele" href="<?php echo U('Downloadcenter/pc');?>">下载中心</span></li>
		<li class="item">
			<span class="click-ele personalCenter" href="<?php echo U('Usercenter/index');?>">
				个人中心<i></i>
			</span>
			<ul class="sub_list">
				<div class="box-s"></div>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/set">账户设置</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/recharge">账户充值</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/withdraw">账户提现</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/history">流水记录</li>
			</ul>
		</li>
	</ul>
	<ul class="right">
		<?php if(session('user')): ?><div class="topRight_login">
				<a href="<?php echo U('Usercenter/index');?>">
					<?php echo session('user')['rname']; ?>
				</a>&ensp;|&ensp;
				<a href="<?php echo U('login/logout');?>">退出</a>
			</div>
		<?php else: ?>
			<li class="click-ele" href="<?php echo U('login/index');?>">登录</li>
			<li class="click-ele" href="<?php echo U('reg/index');?>">注册</li><?php endif; ?>
	</ul>
</div>
				</header>
				<div class="w1200">
					<div class="title01">欢迎注册 Firma</div>
					<div class="w500">
						<form id="reg_form">
						
							<div class="rankingBar">
								<label>姓名:</label>
								<input id="reg-name" type="text" placeholder="请输入您的真实姓名" name="rname" />
							</div>
							<div class="rankingBar">
								<label>手机号:</label>
								<input id="tel" type="text" placeholder="请输入您的手机号" name="tel" maxlength="11" />
							</div>
							<div class="rankingBar">
								<label>邮箱:</label>
								<input id="reg-email" type="text" placeholder="请输入您的邮箱" name="email"/>
							</div>
							<div class="rankingBar">
								<label>邀请码:</label>
								<input id="reg-ib" type="text" placeholder="没有可不填" name="ibcode"/>
							</div>
							<div class="rankingBar">
								<label>短信验证码:</label>
								<input id="reg-code" style="width:42%;" type="text" placeholder="请输入短信验证码"  name="telcode" maxlength="6"/>
								<a id="sendCode" href="javascript:;">获取短信验证码</a>
							</div>
							<div style="width:78%; margin-left:22%; margin-bottom:20px;">
								<input id="checkBox" type="checkbox" checked/>
								<label for="checkBox">
								我已阅读并同意《<a href="/App/Home/View/Default/Reg/客户协议.pdf" style="color:#41BFFF;">客户协议书</a>》
							</label>
							</div>
							<div class="rankingBar" style="margin-top: 40px;">
								<!--<label>&nbsp;</label>-->
								<input id="reg_submit" style="padding-left: 0;display: block;margin: 0 auto;" type="button" value="注 册" />
							</div>
							<!--错误提示-->
							<div id="zcError" style="text-align:center; color:#f00; line-height:40px; font-size:16px;"></div>
						</form>
					</div>
				</div>
			</div>
			<footer>Copyright © 2017 Firma公司版权所有</footer>
		</div>
	</body>
</html>
<script src="/Public/Home/js/jquery.form.js"></script>
<script src="/Public/Home/js/reg.js"></script>
<script type="text/javascript">
var formurl="<?php echo U('reg/saveadd');?>";//用户注册
var telcodeurl="<?php echo U('reg/telcode');?>";//手机验证码
var yzmurl="<?php echo U('login/greatecode');?>";//图形验证码
var successurl="<?php echo U('reg/success');?>";//注册成功
(function() {
	var oclicks = document.querySelectorAll(".click-ele");
	for(var i = 0; i < oclicks.length; i++) {
		oclicks[i].onclick = function() {
			location.href = this.getAttribute("href");
		}
	}
})();
</script>