<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<title>关于我们</title>
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/aboutUs.css" />
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/common.css" />
		<script type="text/javascript" src="/Public/Home/js/jquery.js"></script>
		<!--引用百度地图API-->
		<style type="text/css">
		    .iw_poi_title {color:#CC5522;font-size:14px;font-weight:bold;overflow:hidden;padding-right:13px;white-space:nowrap}
		    .iw_poi_content {font:12px arial,sans-serif;overflow:visible;padding-top:4px;white-space:-moz-pre-wrap;word-wrap:break-word}
			.common-top-secnav .nav-list .item:nth-child(3) span {
			    color: #00c0ff; border-bottom: 3px solid #00c0ff;
			}
		</style>
		<script type="text/javascript" src="http://api.map.baidu.com/api?key=&v=1.1&services=true"></script>
	</head>
	<body>
		<div class="main-hy">
			<header style="background:rgba(0,0,0,0.1); position: absolute; width:100%; z-index:111;">
			<!--头部-->
			<div class="common-top-secnav">
	<a href="<?php echo U('/');?>" style="position: absolute; left:0; width:200px; height:95px;"></a>
	<ul class="nav-list">
		<li class="item">
			<span class="click-ele" href="<?php echo U('/');?>">首页</span>
		</li>
		<li class="item">
			<span class="click-ele" href="<?php echo U('about/product');?>">产品介绍</span>
		</li>
		<li class="item"><span class="click-ele" href="<?php echo U('about/aboutus');?>">关于我们</span></li>
		<li class="item"><span class="click-ele" href="<?php echo U('Downloadcenter/pc');?>">下载中心</span></li>
		<li class="item">
			<span class="click-ele personalCenter" href="<?php echo U('Usercenter/index');?>">
				个人中心<i></i>
			</span>
			<ul class="sub_list">
				<div class="box-s"></div>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/set">账户设置</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/recharge">账户充值</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/withdraw">账户提现</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/history">流水记录</li>
			</ul>
		</li>
	</ul>
	<ul class="right">
		<?php if(session('user')): ?><div class="topRight_login">
				<a href="<?php echo U('Usercenter/index');?>">
					<?php echo session('user')['rname']; ?>
				</a>&ensp;|&ensp;
				<a href="<?php echo U('login/logout');?>">退出</a>
			</div>
		<?php else: ?>
			<li class="click-ele" href="<?php echo U('login/index');?>">登录</li>
			<li class="click-ele" href="<?php echo U('reg/index');?>">注册</li><?php endif; ?>
	</ul>
</div>
			</header>
			<div class="w1920">
				<div class="banner01">
					<img class="aboutUs_" src="images/aboutUs.png" />
				</div>
				<div class="nr w1200">
					<div class="h550 gsjs_01">
						<div class="left_nav">
							<div class="Subtitle">01</div>
							<div style="font-size:14px; color:#999; margin-top: 20px;">Company introduction</div>
							<div class="Modular_title">公司介绍</div>
							<ul class="left_nav_ul">

							</ul>
						</div>
						<div class="right_content" style="background: #fff;">
							<div class="right_nr01 z_content">
								<div style=" background: #fff; padding-top:160px;">
									<div class="r_img">
										<img width="100%" src="/Public/Home/images/aboutUs01.png" />
									</div>
									<div class="r_Article">
										<p>
											Firma 是一家创新性在线金融经纪服务的公司。Firma 成立初期，主要从事信息咨询及信息服务支持，当 Firma 发现客户 需要更 公平的交易环境，需要更好的服务时，Firma 开始转型为金融零售商，充足的资本及规范的运作一次就通过了日趋严 格的 FSP 的所 有启动要求。Trust 信赖、Reliability 可靠、Integrity诚信,让 Firma 成为全球金融交易客户的首选。 Firma 从未停止过用户体验的改善，网站打开速度过慢，出入金不顺畅，没办法为初级客户提供全方位指引，交易执行速度慢， 不友好的 IB 及客户管理端，毫无用处的赠金及虚假的回馈客户方案，都不会在 Firma 的字典里出现 .
										</p>
										<div style="text-align:center; margin:25px 0;">
											<button onclick="$('.z_Article').slideToggle()">展开全部</button>
										</div>
									</div>
									<div class="z_Article" hidden>
										Firma 是一家创新性在线金融经纪服务的公司。Firma 成立初期，主要从事信息咨询及信息服务支持，当 Firma 发现客户 需要更 公平的交易环境，需要更好的服务时，Firma 开始转型为金融零售商，充足的资本及规范的运作一次就通过了日趋严 格的 FSP 的所 有启动要求。Trust 信赖、Reliability 可靠、Integrity诚信,让 Firma 成为全球金融交易客户的首选。 Firma 从未停止过用户体验的改善，网站打开速度过慢，出入金不顺畅，没办法为初级客户提供全方位指引，交易执行速度慢， 不友好的 IB 及客户管理端，毫无用处的赠金及虚假的回馈客户方案，都不会在 Firma 的字典里出现 . Firma 是一家创新性在线金融经纪服务的公司。Firma 成立初期，主要从事信息咨询及信息服务支持，当 Firma 发现客户 需要更 公平的交易环境，需要更好的服务时，Firma 开始转型为金融零售商，充足的资本及规范的运作一次就通过了日趋严 格的 FSP 的所 有启动要求。Trust 信赖、Reliability 可靠、Integrity诚信,让 Firma 成为全球金融交易客户的首选。 Firma 从未停止过用户体验的改善，网站打开速度过慢，出入金不顺畅，没办法为初级客户提供全方位指引，交易执行速度慢， 不友好的 IB 及客户管理端，毫无用处的赠金及虚假的回馈客户方案，都不会在 Firma 的字典里出现 .
									</div>
									<div style="clear: both;"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="h550 xywh_02">
						<div class="left_nav">
							<div class="Subtitle">02</div>
							<div style="font-size:14px; color:#999; margin-top: 20px;">Corporate culture</div>
							<div class="Modular_title">企业文化</div>
							<ul class="left_nav_ul">
								<li class="currentStyle">
									<span class="leftNavFspan"> 企业使命 <i class="leftNav_i"></i></span>
									<span class="leftNav_span"></span>
								</li>
								<li>
									<span class="leftNavFspan"> 经营理念 <i class="leftNav_i"></i></span>
									<span class="leftNav_span"></span>
								</li>
								<li>
									<span class="leftNavFspan"> 企业愿景 <i class="leftNav_i"></i></span>
									<span class="leftNav_span"></span>
								</li>
								<li>
									<span class="leftNavFspan"> 企业精神 <i class="leftNav_i"></i></span>
									<span class="leftNav_span"></span>
								</li>
							</ul>
						</div>
						<div class="right_content">
							<div class="right_nr01 z_content">
								<div style="padding-top:160px;">
									<div class="r_Article">
										<div style="color:#0f0e0e; font-size:22px;">金融感知世界</div>
										<span style="font-size:15px;">Financial perception world</span>
										<p style="font-size:15px; text-indent:40px;margin-top: 30px;">
											探索企业业务流程管理提升问题不断丰富与完善，以流程信息化引领企业进步 探索企业业务流程管理提升问题不断丰富与完善，以流程信息化引领企业进步
										</p>
									</div>
									<div class="r_img">
										<img width="100%" src="/Public/Home/images/aboutUs02.png" />
									</div>
									<div style="clear: both;"></div>
								</div>
							</div>
							<div class="right_nr02 z_content">
								<div style="padding-top:160px;">
									<div class="r_Article">
										<div style="color:#0f0e0e; font-size:22px;">用户至上</div>
										<span style="font-size:15px;">User first</span>
										<p style="font-size:15px; text-indent:40px;margin-top: 30px;">
											一切以用户价值为依归，注重长远发展关注并深刻理解用户需求不断以卓越的产品和服务满足用户需求与用户共成长 一切以用户价值为依归，注重长远发展关注并深刻理解用户需求不断以卓越的产品和服务满足用户需求与用户共成长
										</p>
									</div>
									<div class="r_img">
										<img width="100%" src="/Public/Home/images/aboutUs03.png" />
									</div>
									<div style="clear: both;"></div>
								</div>
							</div>
							<div class="right_nr03 z_content">
								<div style="padding-top:160px;">
									<div class="r_Article">
										<div style="color:#0f0e0e; font-size:22px;">让客户信赖，员工自豪</div>
										<span style="font-size:15px;">Let customer trust, employee pride</span>
										<p style="font-size:15px; text-indent:40px;margin-top: 30px;">
											一切以用户价值为依归，注重长远发展关注并深刻理解用户需求不断以卓越的产品和服务满足用户需求与用户共成长 一切以用户价值为依归，注重长远发展关注并深刻理解用户需求不断以卓越的产品和服务满足用户需求与用户共成长
										</p>
									</div>
									<div class="r_img">
										<img width="100%" src="/Public/Home/images/aboutUs04.png" />
									</div>
									<div style="clear: both;"></div>
								</div>
							</div>
							<div class="right_nr03 z_content">
								<div style="padding-top:160px;">
									<div class="r_Article">
										<div style="color:#0f0e0e; font-size:22px;">倾心投入，分享成功</div>
										<span style="font-size:15px;">Devotion, sharing success</span>
										<p style="font-size:15px; text-indent:40px;margin-top: 30px;">
											为员工提供良好的工作环境和激励机制完善员工培养体系和职业发展通道， 使员工获得与企业同步成长的快乐充分尊重和信任员工，不断引导和鼓励， 使其获得成就的喜悦。
										</p>
									</div>
									<div class="r_img">
										<img width="100%" src="/Public/Home/images/aboutUs05.png" />
									</div>
									<div style="clear: both;"></div>
								</div>
							</div>
						</div>
					</div>
					<div class="h550 lxwm_03">
						<div class="left_nav">
							<div class="Subtitle">03</div>
							<div style="font-size:14px; color:#999; margin-top: 20px;">Contact us</div>
							<div class="Modular_title">联系我们</div>
							<ul class="left_nav_ul">
							</ul>
						</div>
						<div class="right_content" style="background: #90C3F3;">
							<div class="hover_rightContent">
								<div>服务时间 : 周一至周五 8:00-24:00(节假日休息)</div>
								<div>电话 : 400-8520-618</div>
								<div>邮箱 : 1136592462@qq.com</div>
								<div>地址 : 香港九龙旺角道33号凯途发展大厦704室</div>
							</div>
							<!--百度地图容器-->
  							<div style="width:1038px;height:550px;border:#ccc solid 1px;" id="dituContent"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="sub-footer">
			<div class="content">
				<p class="title">CONTACT FIRMA</p>
				<ul class="a-list">
					<li>
						<a href="#">首页</a>
					</li>
					<li>
						<a href="#">关于我们</a>
					</li>
					<li>
						<a href="#">下载中心</a>
					</li>
					<li>
						<a href="#">联系我们</a>
					</li>
				</ul>
				<div class="main">
					<ul>
						<li><span>+64（9）969-0750</span></li>
						<li><span>1136592462@qq.com</span></li>
						<li><span>香港九龙旺角道33号凯途发展大厦704室</span></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="ft-copy">Copyright © 2017 Firma公司版权所有</div>
	</body>

</html>
<script src="js/jquery.js"></script>

<script>
	$(".left_nav_ul li").hover(function() {
		var ind = $(this).index();
		$(this).parents('.h550').find('.left_nav_ul li').removeClass('currentStyle');
		$(this).parents('.h550').find('.right_content >div').hide();
		$(this).addClass('currentStyle').parents('.h550').find('.right_content >div:eq(' + ind + ')').show();
	});
	(function() {
		var oclicks = document.querySelectorAll(".click-ele");
		for(var i = 0; i < oclicks.length; i++) {
			oclicks[i].onclick = function() {
				location.href = this.getAttribute("href");
			}
		}
	})();
</script>

<script type="text/javascript">
    //创建和初始化地图函数：
    function initMap(){
        createMap();//创建地图
        setMapEvent();//设置地图事件
        addMapControl();//向地图添加控件
        addMarker();//向地图中添加marker
    }
    
    //创建地图函数：
    function createMap(){
        var map = new BMap.Map("dituContent");//在百度地图容器中创建一个地图
        var point = new BMap.Point(114.180064,22.32344);//定义一个中心点坐标
        map.centerAndZoom(point,18);//设定地图的中心点和坐标并将地图显示在地图容器中
        window.map = map;//将map变量存储在全局
    }
    
    //地图事件设置函数：
    function setMapEvent(){
        map.enableDragging();//启用地图拖拽事件，默认启用(可不写)
        map.enableScrollWheelZoom();//启用地图滚轮放大缩小
        map.enableDoubleClickZoom();//启用鼠标双击放大，默认启用(可不写)
        map.enableKeyboard();//启用键盘上下左右键移动地图
    }
    
    //地图控件添加函数：
    function addMapControl(){
        //向地图中添加缩放控件
	var ctrl_nav = new BMap.NavigationControl({anchor:BMAP_ANCHOR_TOP_LEFT,type:BMAP_NAVIGATION_CONTROL_LARGE});
	map.addControl(ctrl_nav);
        //向地图中添加缩略图控件
	var ctrl_ove = new BMap.OverviewMapControl({anchor:BMAP_ANCHOR_BOTTOM_RIGHT,isOpen:1});
	map.addControl(ctrl_ove);
        //向地图中添加比例尺控件
	var ctrl_sca = new BMap.ScaleControl({anchor:BMAP_ANCHOR_BOTTOM_LEFT});
	map.addControl(ctrl_sca);
    }
    
    //标注点数组
    var markerArr = [{title:"凯途发展大厦",content:"香港九龙旺角道33号凯途发展大厦",point:"114.179853|22.323432",isOpen:1,icon:{w:21,h:21,l:0,t:0,x:6,lb:5}}
		 ];
    //创建marker
    function addMarker(){
        for(var i=0;i<markerArr.length;i++){
            var json = markerArr[i];
            var p0 = json.point.split("|")[0];
            var p1 = json.point.split("|")[1];
            var point = new BMap.Point(p0,p1);
			var iconImg = createIcon(json.icon);
//          var marker = new BMap.Marker(point,{icon:iconImg});
            var marker = new BMap.Marker(point);
			var iw = createInfoWindow(i);
			var label = new BMap.Label(json.title,{"offset":new BMap.Size(json.icon.lb-json.icon.x+10,-20)});
			marker.setLabel(label);
            map.addOverlay(marker);
            label.setStyle({
                        borderColor:"#808080",
                        color:"#333",
                        cursor:"pointer"
            });
			
			(function(){
				var index = i;
				var _iw = createInfoWindow(i);
				var _marker = marker;
				_marker.addEventListener("click",function(){
				    this.openInfoWindow(_iw);
			    });
			    _iw.addEventListener("open",function(){
				    _marker.getLabel().hide();
			    })
			    _iw.addEventListener("close",function(){
				    _marker.getLabel().show();
			    })
				label.addEventListener("click",function(){
				    _marker.openInfoWindow(_iw);
			    })
				if(!!json.isOpen){
					label.hide();
					_marker.openInfoWindow(_iw);
				}
			})()
        }
    }
    //创建InfoWindow
    function createInfoWindow(i){
        var json = markerArr[i];
        var iw = new BMap.InfoWindow("<b class='iw_poi_title' title='" + json.title + "'>" + json.title + "</b><div class='iw_poi_content'>"+json.content+"</div>");
        return iw;
    }
    //创建一个Icon
    function createIcon(json){
        var icon = new BMap.Icon("img/down-arrow.png", new BMap.Size(json.w,json.h),{imageOffset: new BMap.Size(-json.l,-json.t),infoWindowOffset:new BMap.Size(json.lb+5,1),offset:new BMap.Size(json.x,json.h)})
        return icon;
    }    
    initMap();//创建和初始化地图
</script>