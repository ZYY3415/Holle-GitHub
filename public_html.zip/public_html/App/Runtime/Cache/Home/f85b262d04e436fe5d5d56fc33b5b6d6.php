<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>产品介绍</title>
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/product.css" />
		<style>
			.common-top-secnav .nav-list .item:nth-child(2) span {
			    color: #00c0ff; border-bottom: 3px solid #00c0ff;
			}
		</style>
	</head>
	<body>
		<div class="top-sec">
			<header>
				<!--头部-->
				<div class="common-top-secnav">
	<a href="<?php echo U('/');?>" style="position: absolute; left:0; width:200px; height:95px;"></a>
	<ul class="nav-list">
		<li class="item">
			<span class="click-ele" href="<?php echo U('/');?>">首页</span>
		</li>
		<li class="item">
			<span class="click-ele" href="<?php echo U('about/product');?>">产品介绍</span>
		</li>
		<li class="item"><span class="click-ele" href="<?php echo U('about/aboutus');?>">关于我们</span></li>
		<li class="item"><span class="click-ele" href="<?php echo U('Downloadcenter/pc');?>">下载中心</span></li>
		<li class="item">
			<span class="click-ele personalCenter" href="<?php echo U('Usercenter/index');?>">
				个人中心<i></i>
			</span>
			<ul class="sub_list">
				<div class="box-s"></div>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/set">账户设置</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/recharge">账户充值</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/withdraw">账户提现</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/history">流水记录</li>
			</ul>
		</li>
	</ul>
	<ul class="right">
		<?php if(session('user')): ?><div class="topRight_login">
				<a href="<?php echo U('Usercenter/index');?>">
					<?php echo session('user')['rname']; ?>
				</a>&ensp;|&ensp;
				<a href="<?php echo U('login/logout');?>">退出</a>
			</div>
		<?php else: ?>
			<li class="click-ele" href="<?php echo U('login/index');?>">登录</li>
			<li class="click-ele" href="<?php echo U('reg/index');?>">注册</li><?php endif; ?>
	</ul>
</div>
			</header>
		</div>
		<div class="main-description">
			<div class="top">产品介绍</div>
			<div class="des">外汇交易市场，也称为“foreign exchange”或“FX”市场，是指一国货币与另一国货币进行兑换。外汇市场是全球交易量最大的金融市场，相当于美国所有证券市场交易总和的30余倍，每天成交额逾20,000亿美元。影响外汇走势的重要信息有经济数据、央行政策等，均由国家央行及统计局等权威机构统一发布，交易公平、公正、公开。 </div>
		     <div class="bottom">
		     	<div><img src="/Public/Home/img/51230.png"/></div>     	
		     	<div></div>
		     </div>
		</div>
	     <div class="frame-intro">
	     	<p class="title">Firma 外汇货币对介绍</p>
	     	<table class="product-list">
	     		<tr><th>产品</th><th>中文名字</th><th>合约</th><th>保证金/手</th><th>差点/手</th><th>手续费/手</th><th>过夜费</th><th>挂单距离</th></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     		<tr><td>EURUSD</td><td>欧元美元</td><td>100000美元</td><td>1000美元</td><td>2.0</td><td>2.0</td><td>5美元/天</td><td>200点差</td></tr>
	     	</table>
	     </div>
	      <div class="frame-intro">
	     	<p class="title" style="margin-top: 100px;">Firma 外汇合约细则</p>
	     	<table class="about-rule">
	     		<tr><th>产品细则</th><th>外汇</th></tr>
	     		<tr><td>合约单位（每手）</td><td>100000基础货币</td></tr>
	     		<tr><td>单笔最少交易量</td><td>0.1手</td></tr>
	     		<tr><td>单笔最大交易量</td><td>100手</td></tr>
	     		<tr><td><span>*</span>买卖点差</td><td>20美元/手</td></tr>
	     		<tr><td>即市保证金</td><td>1000美元/手</td></tr>	
	     		<tr><td>维持保证金</td><td>1000美元/手</td></tr>
	     		<tr><td>手续费</td><td>30美元/手</td></tr>
	     		<tr><td><span>*</span>隔夜利息</td><td>买：-1.5%，卖：-1.5%</td></tr>
	     		<tr><td>交易时间(北京时间)</td><td>周一上午8：00至周六凌晨4:00</td></tr>
	     		<tr><td>结算时间</td><td>每天结算时间04:00（北京时间）</td></tr>
	     		<tr><td rowspan="2">强制平仓线</td><td>（1）周一至周五：净值/所需保证金≤25%；</td></tr>
	     		<tr><td>（2）周末或休市：净值/所需保证金≤100%。</td></tr>
	     		<tr><td rowspan="2">锁仓保证金</td><td>锁仓保证金：500美元/手</td></tr>
	     		<tr><td>解锁：需要补足保证金1000美元/每手</td></tr>
	     		<tr><td colspan="2"><span>*</span>买卖点差：所有卖卖差价根据 银行基础汇差，因市场波动而有所调整</td></tr>
	     		<tr><td colspan="2"><span>*</span>隔夜利息(%)为年利率=收市价*合约单位*手数*利率*（1/360）</td></tr>
	     	</table>
	     </div>
		<div class="sub-footer">
			<div class="content">
				<p class="title">CONTACT FIRMA</p>
				<ul class="a-list">
					<li>
						<a href="index.html">首页</a>
					</li>
					<li>
						<a href="aboutUs.html">关于我们</a>
					</li>
					<li>
						<a href="#">下载中心</a>
					</li>
					<li>
						<a href="aboutUs.html">联系我们</a>
					</li>
				</ul>
				<div class="main">
					<ul>
						<li><span>+64（9）969-0750</span></li>
						<li><span>1136592462@qq.com</span></li>
						<li><span>香港九龙旺角道33号凯途发展大厦704室</span></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="ft-copy">Copyright © 2017 Firma公司版权所有</div>
	</body>

</html>
<script src="/Public/Home/js/utils.js"></script>
<script type="text/javascript">
(function() {
	var oclicks = document.querySelectorAll(".click-ele");
	for(var i = 0; i < oclicks.length; i++) {
		oclicks[i].onclick = function() {
			location.href = this.getAttribute("href");
		}
	}
})();
</script>