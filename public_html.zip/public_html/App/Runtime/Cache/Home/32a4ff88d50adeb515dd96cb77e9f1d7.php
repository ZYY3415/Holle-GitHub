<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>登录</title>
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/login.css" />
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/common.css" />
		<script src="/Public/Home/js/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="/Public/Home/css/common.css" />
	</head>
	<body>
		<div class="main">
			<!--头部-->
			<div class="common-top-secnav">
	<a href="<?php echo U('/');?>" style="position: absolute; left:0; width:200px; height:95px;"></a>
	<ul class="nav-list">
		<li class="item">
			<span class="click-ele" href="<?php echo U('/');?>">首页</span>
		</li>
		<li class="item">
			<span class="click-ele" href="<?php echo U('about/product');?>">产品介绍</span>
		</li>
		<li class="item"><span class="click-ele" href="<?php echo U('about/aboutus');?>">关于我们</span></li>
		<li class="item"><span class="click-ele" href="<?php echo U('Downloadcenter/pc');?>">下载中心</span></li>
		<li class="item">
			<span class="click-ele personalCenter" href="<?php echo U('Usercenter/index');?>">
				个人中心<i></i>
			</span>
			<ul class="sub_list">
				<div class="box-s"></div>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/set">账户设置</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/recharge">账户充值</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/withdraw">账户提现</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/history">流水记录</li>
			</ul>
		</li>
	</ul>
	<ul class="right">
		<?php if(session('user')): ?><div class="topRight_login">
				<a href="<?php echo U('Usercenter/index');?>">
					<?php echo session('user')['rname']; ?>
				</a>&ensp;|&ensp;
				<a href="<?php echo U('login/logout');?>">退出</a>
			</div>
		<?php else: ?>
			<li class="click-ele" href="<?php echo U('login/index');?>">登录</li>
			<li class="click-ele" href="<?php echo U('reg/index');?>">注册</li><?php endif; ?>
	</ul>
</div>
			<div class="w450">
				<form id="login_form">
					<div class="_Title">登录</div>
					<div class="Middle_nr">
						<div class="Children_divs">
							<i class="ico_01"></i>
							<input id="loginUser" type="text" placeholder="请输入您的MT4帐号" name="mt4account"></input>
						</div>
						<div class="Children_divs">
							<i class="ico_02"></i>
							<input id="loginPassword" type="password" placeholder="请输入密码" name="password"></input>
						</div>
						<div class="Children_divs" style=" border:1px solid transparent;">
							<i class="ico_03"></i>
							<input type="text" class="loginCode" id="loginCode" placeholder="请输入验证码" name="yzm"></input>
							<div class="right_yzm">
								<img style="width:100%; margin-top:2px;" class="codeImg" src="<?php echo U('Login/greatecode');?>" />
							</div>
						</div>
						<div style="margin-bottom:30px;">
							<input type="checkbox" id="box" />
							<label for="box" style="font-size:15px; color:#666;">下次自动登录</label>
							<a href="javascript:;" class="ForgotPassword">忘记密码？</a>
						</div>
						<input id="login_submit" type="button" value="登 录" />
						<a href="<?php echo U('reg/index');?>" id="register_">注 册</a>
						<div style="margin-top:15px; text-align:center;">登录遇到问题？请致电400-8520-618</div>
					</div>
					<div id="error" class="ErrorPrompt"></div>
				</form>
			</div>
			<footer>Copyright © 2017 Firma公司版权所有</footer>
		</div>
	</body>

</html>
<script src="/Public/Home/js/jquery.form.js" type="text/javascript"></script>
<script src="/Public/Home/js/login.js" type="text/javascript"></script>
<script type="text/javascript">
var formurl="<?php echo U('login/dologin');?>";//登录验证
var yzmurl="<?php echo U('login/greatecode');?>";//验证码URL
(function() {
	var oclicks = document.querySelectorAll(".click-ele");
	for(var i = 0; i < oclicks.length; i++) {
		oclicks[i].onclick = function() {
			location.href = this.getAttribute("href");
		}
	}
})();
</script>