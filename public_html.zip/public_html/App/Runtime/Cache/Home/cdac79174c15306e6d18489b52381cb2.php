<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

	<head>
		<meta charset="utf-8" />
		<title>飞尔玛</title>
		<link rel="stylesheet" type="text/css" href="/Public/Home/css/style.css" />
		<script src="/Public/Home/js/jquery.js"></script>
		<style>
			.common-top-secnav .nav-list .item:nth-child(1) span {
			    color: #00c0ff; border-bottom: 3px solid #00c0ff;
			}
		</style>
	</head>
	<body>
		<div class="top-sec">
			<!--头部-->
			<div class="common-top-secnav">
	<a href="<?php echo U('/');?>" style="position: absolute; left:0; width:200px; height:95px;"></a>
	<ul class="nav-list">
		<li class="item">
			<span class="click-ele" href="<?php echo U('/');?>">首页</span>
		</li>
		<li class="item">
			<span class="click-ele" href="<?php echo U('about/product');?>">产品介绍</span>
		</li>
		<li class="item"><span class="click-ele" href="<?php echo U('about/aboutus');?>">关于我们</span></li>
		<li class="item"><span class="click-ele" href="<?php echo U('Downloadcenter/pc');?>">下载中心</span></li>
		<li class="item">
			<span class="click-ele personalCenter" href="<?php echo U('Usercenter/index');?>">
				个人中心<i></i>
			</span>
			<ul class="sub_list">
				<div class="box-s"></div>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/set">账户设置</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/recharge">账户充值</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/withdraw">账户提现</li>
				<li class="sub_item click-ele" href="<?php echo U('Usercenter/index');?>#/history">流水记录</li>
			</ul>
		</li>
	</ul>
	<ul class="right">
		<?php if(session('user')): ?><div class="topRight_login">
				<a href="<?php echo U('Usercenter/index');?>">
					<?php echo session('user')['rname']; ?>
				</a>&ensp;|&ensp;
				<a href="<?php echo U('login/logout');?>">退出</a>
			</div>
		<?php else: ?>
			<li class="click-ele" href="<?php echo U('login/index');?>">登录</li>
			<li class="click-ele" href="<?php echo U('reg/index');?>">注册</li><?php endif; ?>
	</ul>
</div>
			<ul class="lunbo" id="lunbo-area">
				<li class="active" style="background: url(/Public/Home/img/1/lb04.jpg) center top/100% auto no-repeat;"></li>
				<li style="background: url(/Public/Home/img/1/image-02-new.jpg) center top/100% auto no-repeat;"></li>
				<li style="background: url(/Public/Home/img/1/image-03-new.jpg) center top/100% auto no-repeat;"></li>
			</ul>
			<div class="firma-font" onmousedown="return false;" onselectstart="return false;">
				<p class="fir">FIRMA——让外汇交易变得更简单</p>
				<p class="sec">Make foreign exchange transactions simple</p>
				<img class="main-logo" src="img/1/banner-logo.png"/>
			</div>
		</div>
		<div class="des-bl">
			<ul>
				<li>
					<div class="fir">
						<p><span>123</span>亿<span>456</span>万</p>
						<p>累计交易金额(元)</p>
					</div>
				</li>
				<li>
					<div class="sec">
						<p><span>699</span>万<span>888</span>千</p>
						<p>累计注册人数(人)</p>
					</div>
				</li>
				<li>
					<div class="thir">
						<p><span>656</span></p>
						<p>运营时间(天)</p>
					</div>
				</li>
			</ul>
		</div>
		<div class="mid-list">
			<div class="ctn-wid">
				<div class="list-title">Firma 让交易更简单</div>
				<div class="dt-des">市场行情丰富 支持双向交易</div>
				<div class="tables">
					<div class="line"></div>
					<table>
						<tr>
							<th>交易产品</th>
							<th>买入价</th>
							<th>卖出价</th>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid drop">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
					</table>
					<table>
						<tr>
							<th>交易产品</th>
							<th>买入价</th>
							<th>卖出价</th>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
					</table>
				</div>
				<div class="tables tables2" style="margin:0; position:relative; top:-50px;" hidden>
					<div class="line"></div>
					<table>
						<tr style="opacity:0;">
							<th>交易产品</th>
							<th>买入价</th>
							<th>卖出价</th>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid drop">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid drop">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
					</table>
					<table>
						<tr style="opacity:0;">
							<th>交易产品</th>
							<th>买入价</th>
							<th>卖出价</th>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid drop">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid drop">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask drop">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
						<tr>
							<td>欧元美元 / EURUSD</td>
							<td><span class="bid">0.78822</span></td>
							<td><span class="ask">0.78822</span></td>
						</tr>
					</table>
				</div>
			</div>
			<?php if(session('user')): ?><a class="common-btn viewMore" href="javascript:;">查看更多</a>
				<?php else: ?>
				<a class="common-btn" href="<?php echo U('reg/index');?>">立即注册</a><?php endif; ?>
		</div>
		<div class="download">
			<div class="content">
				<div class="title">下载 MetaTrader 4</div>
				<div class="des">最流行的交易平台之一，适用于PC端和移动设备</div>
				<div class="a">
					<a href="" class="pc"><span class="main">PC端下载</span></a>
					<a href="" class="ios"><span class="main">iPhone下载</span></a>
					<a href="" class="android"><span class="main">Android下载</span></a>
				</div>
			</div>
		</div>
		<div class="why-sel">
			<div class="list-title">为什么选择 Firma</div>
			<div class="dt-des">开立Firma账户，享受与众不同的交易体验</div>
			<table cellpadding="0" cellspacing="0">
				<tr>
					<td class="fir-td">
						<div class="fir">
							<p class="title">低门槛</p>
							<p class="des">投资低至1美元起</br>提供低门槛理财机会</p>
						</div>
					</td>
					<td>
						<div class="sec">
							<p class="title">高杠杆</p>
							<p class="des">1-100倍杠杠，小投入</br>风险低，高收益</p>
						</div>
					</td>
					<td>
						<div class="thir">
							<p class="title">双向交易</p>
							<p class="des">不管货币价格上涨还是下跌</br>选对方向，就可盈利</p>
						</div>
					</td>
				</tr>
				<tr>
					<td class="fir-td">
						<div class="four">
							<p class="title">交易公平透明</p>
							<p class="des">通过银行、交易所入市交易</br>向客户公开 真正可成交点差水平</p>
						</div>
					</td>
					<td>
						<div class="five">
							<p class="title">投资便捷</p>
							<p class="des">微信+掌上移动APP在线交易</br>网上开户10分钟完成</p>
						</div>
					</td>
					<td>
						<div class="six">
							<p class="title">24小时交易</p>
							<p class="des">使用ECN国际对冲通道交易</br>极速下单，毫秒交易</p>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<div class="footer-bn">
			<div class="content">
				<div class="right">
					<p class="tit">Firma 外汇 —— 开启您的致富之路</p>
					<p class="des">“我生来一贫如洗,但决不能死时仍旧贫困潦倒。”</p>
					<p class="nm">——乔治 · 索罗斯</p>
					<a class="register common-btn" href="<?php echo U('reg/index');?>">立即注册</a>
				</div>
			</div>
		</div>
		<!--脚页-->
		<div class="sub-footer">
	<div class="content">
		<p class="title">CONTACT FIRMA</p>
		<ul class="a-list">
			<li>
				<a href="<?php echo U('/');?>">首页</a>
			</li>
			<li>
				<a href="<?php echo U('about/aboutus');?>">关于我们</a>
			</li>
			<li>
				<a href="<?php echo U('Downloadcenter/pc');?>">下载中心</a>
			</li>
			<!--<li>
				<a href="aboutUs.html">联系我们</a>
			</li>-->
		</ul>
		<div class="main">
			<ul>
				<li><span>+64（9）969-0750</span></li>
				<li><span>1136592462@qq.com</span></li>
				<li><span>香港九龙旺角道33号凯途发展大厦704室</span></li>
			</ul>
		</div>
	</div>
	<div class="ft-copy">Copyright © 2017 Firma公司版权所有</div>
</div>
	</body>

</html>
<script type="text/javascript">
	(function() {
		var olis = document.querySelectorAll("#lunbo-area li");
		var active = 0;
		setInterval(function() {
			(active == olis.length - 1) ? (active = 0) : (active++);
			for(var i = 0; i < olis.length; i++) {
				olis[i].classList.remove("active");
			}
			olis[active].classList.add("active");
		}, 3000)
		var oclicks = document.querySelectorAll(".click-ele");
		for(var i = 0; i < oclicks.length; i++) {
			oclicks[i].onclick = function() {
				location.href = this.getAttribute("href");
			}
		}
		$('.viewMore').click(function(){
			($(this).text()== "查看更多")?$(this).text("收起"):$(this).text("查看更多");
			$('.tables2').slideToggle();
		})
	})();
</script>