<?php
namespace Wap\Model;
use Think\Log;
use Think\Model;

class UserModel extends Model
{

    public function saveadd()
    {
        $errormsg['code']=1;
        $errormsg['message']='dd';
//        ini_set("max_execution_time", "120");
        Log::record(json_encode($errormsg),Log::DEBUG);//debug日志

        $errormsg=$this->checkdata();

        Log::record(json_encode($errormsg),Log::DEBUG);//debug日志

        if($errormsg['code']!=1) return $errormsg;
        $re=$this->receviedata();

        Log::record(json_encode($re),Log::DEBUG);//debug日志

        if($this->add($re['data'])===false)
        {
            $re['successgjb']=$re['successgjb'].'网站注册失败';
            $errormsg['code']=-20;
            $errormsg['message']='数据库新增失败！';
        }
        else
        {   
            session('telcode',null);
            $re['successgjb']=$re['successgjb'].'网站注册成功';
            $errormsg['code']=1;
            $errormsg['message']='数据库新增成功！';
        }
        //发送短信给客服
        //sendsms(C('DX_TEL.REG'),array($data['mt4account'],$re['mt4pass']),"49200");
        sendsms(C('DX_TEL.REG'),array($re['data']['rname'],$re['data']['mt4account'],$re['mt4pass']),"198049");
        
        //发送短信客户
        sendsms($re['data']['tel'],array($re['data']['rname'],$re['data']['mt4account'],$re['mt4pass']),"198049");
        
        //邮件通知客服
        email('4',array(
            'rname'     =>$re['data']['rname'],
            'tel'       =>$re['data']['tel'],
            'mt4account'=>$re['data']['mt4account'],
            'email'     =>$re['data']['email'],
            'mt4pass'   =>$re['mt4pass'],
            'ibcode'    =>$re['data']['ibcode'],
            'suceess'   =>$re['successgjb']
        ));
        
        //邮件通知客人
        email('7', array(
            'rname'     =>$re['data']['rname'],
            'myemail'   =>$re['data']['email'],
            'mt4account'=>$re['data']['mt4account'],
            'mt4pass'   =>$re['mt4pass']
        ));
        
        return $errormsg;
    }
    

    private function checkdata()
    {
        $errormsg['code']=1;
        $errormsg['message']='表单校验通过';
        $pattern='/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/';
        if (!preg_match($pattern, I('post.email')))
        {
            $errormsg['code']=-4;
            $errormsg['message']='电子邮箱错误！';
            return  $errormsg;
        }
        //校验图形验证码
        if (!checkcode(I('post.txyzm'))) {
            $errormsg['code'] = -8;
            $errormsg['message'] = '图形验证码错误！';
            return $errormsg;
        }

        //手机验证码校验
//        if( (I('post.telcode')!=session('telcode')['smscode']) )
//        {
//            $errormsg['code']=-1;
//            $errormsg['message']='手机验证码错误！';
//            return $errormsg;
//        }
        mb_internal_encoding("UTF-8");
        if( (!I('post.rname')) || mb_strlen(I('post.rname'))>30 )
        {
            $errormsg['code']=-2;
            $errormsg['message']='用户名为空或用户名不得超过30个字符';
            return $errormsg;            
        }
        $pattern='/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel')))
        {
            $errormsg['code']=-3;
            $errormsg['message']='手机号码错误！';
            return  $errormsg;
        }
        
        if(I('post.ibcode'))
        {   
            $pattern='/^\d+$/';
            if (!preg_match($pattern,I('post.ibcode')))
            {
                $errormsg['code']=-5;
                $errormsg['message']='邀请码必须是数字！';
                return  $errormsg;
            }
        }
        if($this->where(array('tel' => I('post.tel') ))->find())
        {
            $errormsg['code']=-6;
            $errormsg['message']='手机号码已经注册过！';
            return  $errormsg;
        }
        
        if($this->where(array('email' => I('post.email')))->find())
        {
            $errormsg['code']=-7;
            $errormsg['message']='电子邮箱已经注册过！';
            return  $errormsg;
        }

        getlogger()->debug($errormsg);//debug日志

        return $errormsg;
    }
    
    private function receviedata()
    {
        ini_set("max_execution_time", "120");
        $re['mt4pass']=greatmt4pass();
                
        $data['rname']=trim(I('post.rname'));
        $data['tel']=trim(I('post.tel'));
        $data['email']=trim(I('post.email'));
        $data['ibcode']=trim(I('post.ibcode'));
        if(!I('post.ibcode')) $data['ibcode']=10000;
        $data['password']=sha1($re['mt4pass'].'frm');
        $data['reg_time']=time();
        $data['reg_ip']=get_client_ip(1);
        $data['status']=0;
        $data['agentid']=0;
        $data['mt4account']=greataccount();       
        //注册捷引金融
        $post_data=array(
            'group'=>$data['ibcode'],//必须参数
            //'group'=>'TEST',//必须参数 
            'name'=>$data['rname'],//必须参数
            'account'=>$data['mt4account'],
            'telephone'=>$data['tel'],
            'email'=>$data['email'],
            'primary_passwd'=>$re['mt4pass'],//必须参数
            'investor_passwd'=>$re['mt4pass']
        );

        if (!$post_data['group']){//清除组
            unset($post_data['group']);
        }

        $result=postmt4('addaccount', $post_data);
        $i=0;
        while( ($result['success']!=true)&&($i<3) )
        {            
            sleep(3);
            $result=postmt4('addaccount', $post_data);
            $i=$i+1;
        }

        Log::record($result,Log::DEBUG);//记录日志

        if($result['success'])
        {
            $data['mt4_success']=1;
            $data['mt4_errno']=$result['error'];
            $re['successgjb']='注册成功；';
        }
        else
        {
            $data['mt4_success']=0;
            $data['mt4_errno']=$result['error'];
            $re['successgjb']="注册失败，错误代码：{$result['error']}；";
        }
        $re['data']=$data;
        return $re;
    }
    
    public function getuserbank()
    {
        $list=$this->field('id,bank,subbank,bankaccount')->where(array('id'=>session('user')['id']))->find();
        return $list;
    }
    
    public function wsyhkdo()
    {
        $redata['bank'] = I('post.bank');
        $redata['subbank'] = I('post.subbank');
        $redata['bankaccount'] = I('post.bankaccount');
        

        if(!$redata['bank'])
        {
            $errormsg['code']=-8;
            $errormsg['message']='请选择开户银行';
            return  $errormsg;
        }
        if(!$redata['subbank'])
        {
            $errormsg['code']=-9;
            $errormsg['message']='请填写开户支行';
            return  $errormsg;
        }
        if( mb_strlen($redata['subbank'])>100 )
        {
            $errormsg['code']=-10;
            $errormsg['message']='开户支行大于100个字符';
            return  $errormsg;
        }
        if(!$redata['bankaccount'])
        {
            $errormsg['code']=-11;
            $errormsg['message']='请填写银行账号';
            return  $errormsg;
        }
        if( mb_strlen($redata['bankaccount'])>100 )
        {
            $errormsg['code']=-12;
            $errormsg['message']='银行账号字符大于100个字符';
            return  $errormsg;
        }
        $redata['id']=session('user')['id'];
        
        if($this->save($redata)!==false)
        {
            $errormsg['code']=1;
            $errormsg['message']='修改成功';
            return  $errormsg;
        }
        else
        {
            $errormsg['code']=-20;
            $errormsg['message']='修改失败';
            return  $errormsg;
        }
        
    }
    
    
    public function wsxxdo()
    {   
        $redata['id']       =session('user')['id'];
        
        $redata['vname']    =I('post.vname');
        $redata['rname']    =I('post.rname');
        $redata['sex']      =I('post.sex');
        $redata['birthday'] =I('post.birthday');
        $redata['cardtype'] =I('post.cardtype');
        $redata['card']     =I('post.card');
        $redata['province'] =I('post.province');
        $redata['city']     =I('post.city');
        $redata['county']   =I('post.county');        
        $redata['address']  =I('post.address');
        $redata['tel']      =I('post.tel');
        $redata['email']    =I('post.email');
        
        mb_internal_encoding("UTF-8");

        if($redata['birthday'])
        {
            if( strtotime($redata['birthday'])>time() )
            {
                $errormsg['code']=-3;
                $errormsg['message']='生日不能选择大于现在时间';
                return $errormsg;
            }
        }
        if( !$this->where(array('id'=>$redata['id']))->getField('card') )
        {
            if( (!$redata['rname']) || mb_strlen($redata['rname'])>30 )
            {
                $errormsg['code']=-1;
                $errormsg['message']='用户名为空或用户名不得超过30个字符';
                return $errormsg;
            }
            if( mb_strlen($redata['vname'])>30 )
            {
                $errormsg['code']=-2;
                $errormsg['message']='昵称不得超过30个字符';
                return $errormsg;
            }
            if(!$redata['cardtype'])
            {
                $errormsg['code']=-4;
                $errormsg['message']='请选择证件类型';
                return $errormsg;
            }
            if(!$redata['card'])
            {
                $errormsg['code']=-5;
                $errormsg['message']='请输入证件号码';
                return $errormsg;
            }
            if($redata['cardtype']==1)
            {
                $pattern='/^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/';
                if(!preg_match($pattern,$redata['card']))
                {
                    $errormsg['code']=-15;
                    $errormsg['message']='身份证号码格式不正确';
                    return $errormsg;
                }
            }
            if(mb_strlen($redata['card'])>20)
            {
                $errormsg['code']=-16;
                $errormsg['message']='证件号码太长请联系客服';
                return $errormsg;
            }
            //证件号码重复校验
            if( $this->where(array('card'=>$redata['card'],'id'=>array('neq',$redata['id'])))->find() )
            {
                $errormsg['code']=-13;
                $errormsg['message']='证件号码重复';
                return  $errormsg;
            }
        }
    
        $pattern='/^1(\d){10}$/';
        if (!preg_match($pattern, $redata['tel']))
        {
            $errormsg['code']=-6;
            $errormsg['message']='手机号码错误！';
            return  $errormsg;
        }
        $pattern='/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/';
        if (!preg_match($pattern, $redata['email']))
        {
            $errormsg['code']=-16;
            $errormsg['message']='电子邮箱格式错误！';
            return  $errormsg;
        }
        
        if(mb_strlen($redata['address'])>300)
        {
            $errormsg['code']=-7;
            $errormsg['message']='详细地址超过300个字符';
            return  $errormsg;
        }
    
        //手机号码重复校验
        if( $this->where(array('tel'=>$redata['tel'],'id'=>array('neq',$redata['id'])))->find() )
        {
            $errormsg['code']=-14;
            $errormsg['message']='手机号码重复';
            return  $errormsg;
        }
        //邮箱重复校验
        if( $this->where(array('tel'=>$redata['email'],'id'=>array('neq',$redata['id'])))->find() )
        {
            $errormsg['code']=-15;
            $errormsg['message']='电子邮箱重复';
            return  $errormsg;
        }
              
        $data['id']=session('user')['id'];
        
        $data['vname']=I('post.vname');
        $data['sex']=I('post.sex');
        if(I('post.birthday'))  $data['birthday']=I('post.birthday');
        if( !$this->where(array('id'=>session('user')['id']))->getField('card') )
        {
            $data['rname']=I('post.rname');
            if(I('post.cardtype'))  $data['cardtype']=I('post.cardtype');
            if(I('post.card'))       $data['card']   =I('post.card');
        }
        $data['tel']=I('post.tel');
        if(I('post.province')!='省份')     $data['province']=I('post.province');        
        if(I('post.city')!='地级市')        $data['city']=I('post.city');
        if(I('post.county')!='市、县级市')   $data['county']=I('post.county');
        $data['address']=I('post.address');
        
        if( $this->save($data)===false )
        {
            $errormsg['code']=-20;
            $errormsg['message']='用户资料修改失败！';
        }
        else
        {
            $errormsg['code']=1;
            $errormsg['message']='用户资料修改成功！';
        
            $userinfo['id']         =session('user')['id'];
            $userinfo['rname']      =session('user')['rname'];
            if($data['rname'])      $userinfo['rname']=$data['rname'];
            $userinfo['tel']        =$data['tel'];
            $userinfo['mt4account'] =session('user')['mt4account'];
            $userinfo['agentid']    =session('user')['agentid'];
            session('user',$userinfo);
        }
        return $errormsg;
    }
    public function sczj()
    {
        $userinfo=$this->field('filecard')->where(array('id'=>session('user')['id']))->find();
        if($userinfo['filecard'])
        {
            $userinfo['filecardimg']='<img src="'.__ROOT__.$userinfo['filecard'].'" >';
        }
        return $userinfo;
    }
    public function sczjdo()
    {
        if(!I('post.filecard'))
        {
            $errormsg['code']=-1;
            $errormsg['message']='请上传证件';
            return $errormsg;
        }
        $data['id']=session('user')['id'];
        $data['filecard']=I('post.filecard');
        if($this->save($data)!==false)
        {
            $errormsg['code']=1;
            $errormsg['message']='上传成功';
            return $errormsg;
        }
        else
        {
            $errormsg['code']=-20;
            $errormsg['message']='上传失败';
            return $errormsg;
        }
    }
    
    
    public function scyhk()
    {
        $userinfo=$this->field('filebank')->where(array('id'=>session('user')['id']))->find();
        if($userinfo['filebank'])
        {
            $userinfo['filebankimg']='<img src="'.__ROOT__.$userinfo['filebank'].'" >';
        }
        return $userinfo;
    }
    public function scyhkdo()
    {
        if(!I('post.filebank'))
        {
            $errormsg['code']=-2;
            $errormsg['message']='请上传银行卡';
            return $errormsg;
        }
        $data['id']=session('user')['id'];
        $data['filebank']=I('post.filebank');
        if($this->save($data)!==false)
        {
            $errormsg['code']=1;
            $errormsg['message']='上传成功';
            return $errormsg;
        }
        else
        {
            $errormsg['code']=-20;
            $errormsg['message']='上传失败';
            return $errormsg;
        }
    }
   
    
    public function telcode()//手机验证码
    {
        $pattern='/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel')))
        {
            $errormsg['code']=-1;
            $errormsg['message']='手机号码错误！';
            return  $errormsg;
        }
        return telcode(I('post.tel'));
    }

}
?>