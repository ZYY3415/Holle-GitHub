<?php
return array(
	//设置模版替换变量
	'TMPL_PARSE_STRING' => array(
		'__WAP__'=>__ROOT__.'/Public/'.MODULE_NAME,
		'__HOME__'=>__ROOT__.'/Public/Home',
	    
	),
    
    
    //开启路由模式
    'URL_ROUTER_ON'=>true,
    //配置动态路由规则
    'URL_ROUTE_RULES'=>array(
        '/reg\/(\d+)$/'=>'Wap/Reg/index?ibcode=:1',
        
    ),
    //配置静态路由规则
    'URL_MAP_RULES'=>array(
        'aqbz'=>'Index/aqbz',
        'gsdt'=>'Index/gsdt',
        'gywm'=>'Index/gywm',
        'jycl'=>'Index/jycl',
        'jyxz'=>'Index/jyxz',
        'jyzn'=>'Index/jyzn',
        'lxwm'=>'Index/lxwm',
        'tzys'=>'Index/tzys',
        'yhhd'=>'Index/yhhd',
        'ykjs'=>'Index/ykjs',
        'zjdy'=>'Index/zjdy',
        'zysx'=>'Index/zysx',
        'khl'=>'Index/khl',
        'wzl'=>'Index/wzl',
        'mt4l'=>'Index/mt4l',
    ),
     
    
    //短信通知电话
    'DX_TEL'=>array(
        'REG'   =>'13791949567',               //注册通知 客服电话
        'PAYIN' =>'15875565693,13424372018',   //入金通知 吴总、财务电话
        'PAYOUT'=>'15875565693,13424372018',   //出金通知 吴总、财务电话
    ),
    
//     //测试通知电话
//     'DX_TEL'=>array(
//         'REG'   =>'18938025959,15602910148',     //注册通知
//         'PAYIN' =>'18938025959,15602910148',     //入金 
//         'PAYOUT'=>'18938025959,15602910148',     //出金 
//     ),
    
    
    
    
    
    
    
    
    
    
    
);