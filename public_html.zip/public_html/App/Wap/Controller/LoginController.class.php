<?php
namespace Wap\Controller;

class LoginController extends HomeController {

    public function index()
    {
        $this->display();
    }
    public function greatecode()
    {
        greatecode();
    }
    public function logindo()//用户登陆
    {
        if(IS_AJAX)
        {
            $User=new \Home\Model\UserModel();
            $this->ajaxReturn( $User->dologin() );
        }
        else
        {
            $this->error('非法打开链接');
        }
    }    
}