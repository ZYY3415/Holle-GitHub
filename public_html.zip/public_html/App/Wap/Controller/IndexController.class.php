<?php
namespace Wap\Controller;

class IndexController extends HomeController {

    protected function _initialize()
    {
    }
    
    public function index()
    {
        $this->display();
    }
    
    public function aqbz()
    {
        $this->display();
    }
    public function gsdt()
    {
        $this->display();
    }
    public function gywm()
    {
        $this->display();
    }
    public function jycl()
    {
        $this->display();
    }
    public function jyxz()
    {
        $this->display();
    }
    public function jyzn()
    {
        $this->display();
    }
    public function lxwm()
    {
        $this->display();
    }
    public function tzys()
    {
        $this->display();
    }
    public function yhhd()
    {
        $this->display();
    }
    public function ykjs()
    {
        $this->display();
    }
    public function zjdy()
    {
        $this->display();
    }
    public function zysx()
    {
        $this->display();
    }
    public function khl()
    {
        $this->display();
    }
    public function wzl()
    {
        $this->display();
    }
    public function mt4l()
    {
        $this->display();
    }
    
        
}