<?php
namespace Wap\Controller;

class RegController extends HomeController {
    
    public function index()//注册
    {
        if(I('get.ibcode'))
        {
            cookie('ibcode',I('get.ibcode'),3600*24*7);
        }
        $this->display();
    }
    public function success()//注册成功的页面
    {
        $this->display();
    }
    
    public function saveadd()
    {
        if(IS_AJAX)
        {
           $User=D('User');
           $this->ajaxReturn( $User->saveadd() );
        }
        else
        {
            $this->error('非法打开链接');
        }
    }
    
    public function telcode()//手机验证码
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn( $User->telcode() );
        }
        else
        {
            $this->error('非法打开链接');
        }
    }

}