<?php
namespace Wap\Controller;

class UcController extends HomeController {

    protected function _initialize()
    {
        $this->islogin();
    }
    private function islogin()
    {
        if(!session('?user'))
        {
            $this->redirect('/wap/login');
        }
    }
    public function index()
    {
        $this->display();
    }
    
    public function yhcz()
    {
        $this->display();
    }
    public function yhczdo()
    {
        if(IS_AJAX)
        {
            $Payin=new \Home\Model\PayinModel();
            $rurl=U('/wap/uc/yhczsuccess','','html',$_SERVER['HTTP_HOST']);
            $this->ajaxReturn($Payin->payinshowdo($rurl));
        }
    }
    public function yhczsuccess()
    {
        $this->display();
    }
    public function yhqk()
    {
        $User=M('User');
        $userinfo=$User->field('bank,subbank,bankaccount')->where(array('id'=>session('user')['id']))->find();
        $this->assign('userinfo',$userinfo);
        $this->display();
    }
    public function yhqkdo()
    {
        if(IS_AJAX)
        {
            $Payout=new \Home\Model\PayoutModel();
            $this->ajaxReturn($Payout->payoutdo());
        }
    }
    public function yhqksuccess()
    {
        $this->display();
    }
    public function zlgl()
    {
        $this->display();
    }  
    public function jyls()
    {
        $this->display();
    }
    public function jyjl()
    {
        $this->display();
    }
    public function jyjldo()
    {
        if(IS_AJAX)
        {
            $mychecktime=mychecktime();
            if($mychecktime['code']==1)
            {
                $url='getaccounttrades';
                $data['account']=session('user')['mt4account'];
                $data['from']=strtotime(I('post.fromtime'));
                $data['to']=strtotime(I('post.totime').'23:59:59');    
                $data=json_encode($data);    
                $post_data['data']=$data;    
                $result=postmt4($url,$post_data,0);
                echo $result;
            }
        }
    }
    public function qkjl()
    {
        $this->display();
    }
    public function qkjldo()
    {
        if(IS_AJAX)
        {
            $mychecktime=mychecktime();
            if($mychecktime['code']==1)
            {
                $Payout=new \Home\Model\PayoutModel();
                $this->ajaxReturn($Payout->payoutrecorde());
            }
        }
    }  
    public function czjl()
    {
        $this->display();
    }
    public function czjldo()
    {
        if(IS_AJAX)
        {
            $mychecktime=mychecktime();
            if($mychecktime['code']==1)
            {
                $Payin=new \Home\Model\PayinModel();
                $redata=['id'=>session('user')['id'],'fromtime'=>I('post.fromtime'),'totime'=>I('post.totime')];
                $this->ajaxReturn( $Payin->payinrecorde($redata) );                
            }

        }
    }
 
    public function wsyhk()
    {
        $User=D('User');
        $this->assign('userinfo',$User->getuserbank());
        $this->display();
    }
    public function wsyhkdo()
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn($User->wsyhkdo());
        }
    }
    public function wsxx()
    {
        $User=new \Home\Model\UserModel();
        $this->assign('userinfo',$User->completeinfo());
        $this->display();
    }
    public function wsxxdo()
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn($User->wsxxdo());
        }
    }
    public function xgwzmm()
    {
        $this->display();
    }
    public function xgwzmmdo()
    {
        if(IS_AJAX)
        {
            $User=new \Home\Model\UserModel();
            $this->ajaxReturn($User->editpassworddo());
        }
        else
        {
            $this->error('非法访问');
        }  
    }
    public function xgmt4mm()
    {
        $this->display();
    }
    public function xgmt4mmdo()
    {
        if(IS_AJAX)
        {
            $User=new \Home\Model\UserModel();
            $this->ajaxReturn($User->editmt4passdo());
        }
        else
        {
            $this->error('非法访问');
        }
    }
    public function sczj()
    {
        $User=D('User');
        $this->assign('userinfo',$User->sczj());
        $this->display();
    }
    public function sczjdo()
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn($User->sczjdo());
        }
    }
    
    public function scyhk()
    {
        $User=D('User');
        $this->assign('userinfo',$User->scyhk());
        $this->display();
    }
    public function scyhkdo()
    {
         if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn($User->scyhkdo());
        }
    }
    public function upcard()
    {
        $User=new \Home\Controller\UsercenterController();
        $User->upcard();
    }
    public function grxx()
    {
        $User=new \Home\Model\UserModel();
        $this->assign('userinfo',$User->userinfo());
        $this->display();
    }
    
    public function logout()
    {
        session('user',null);
        $this->redirect('/wap/login');
    }

        
}