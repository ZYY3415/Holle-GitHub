<?php
return array(
	//设置模版替换变量
	'TMPL_PARSE_STRING' => array(
		'__HOME__'=>__ROOT__.'/Public/'.MODULE_NAME,
	),
    //开启路由模式
    'URL_ROUTER_ON'=>true,
    //配置动态路由规则
    'URL_ROUTE_RULES'=>array(
        '/reg\/(\d+)$/' =>'Reg/index?ibcode=:1',
        '/^marketinformation\/(\d)$/' =>'Marketinformation/index?cat=:1',
        '/^investmentcollege\/(\d+)$/'=>'Investmentcollege/index?cat=:1',
        
    ),
    //配置静态路由规则
    'URL_MAP_RULES'=>array(
         'index' => 'Index/index',
         'l'     => 'Login/index',
    ),

    'DOWNLOAD_LINK'=>array(
        'PC'=>'/Public/Home/pc.exe',//PC客户端下载链接
        'APPLE'=>'http://www.pgyer.com/6M4Y',//苹果客户端下载链接
        'ANDROID'=>'http://webGJB.tzbtc.com/MT4Mobile.apk',//安卓客户端下载链接
    
    ),
    
    //客服qq
    'KFQQ'=>'805001166',
    
    
    //短信通知电话
    'DX_TEL'=>array(
        'REG'   =>'13349508783,13766506055',               //13791949567注册通知 客服电话
        'PAYIN' =>'13349508783,13766506055',   //15875565693,13424372018入金通知 吴总、财务电话
        'PAYOUT'=>'13349508783,13766506055',   //15875565693,13424372018出金通知 吴总、财务电话
    ),
    
    //测试通知电话
//     'DX_TEL'=>array(
//         'REG'   =>'18938025959,15602910148',     //注册通知
//         'PAYIN' =>'18938025959,15602910148',     //入金 
//         'PAYOUT'=>'18938025959,15602910148',     //出金 
//     ),

    'HR'=>array(
        'MD5key'=>'ZPGNYZm4V78T',
        'Merno'=>'00000000000205',
        'Signtype'=>'M',
        'bizType'=>'10',
        'TranType'=>'20102',
        'Paytype'=>'01',
        'ThirdParty'=>'LLP',
    ),
);