<?php
namespace Home\Controller;

class IndexController extends HomeController {
    

    public function index()
    {

//         if(isMobile())
//         {
//             $this->redirect('/wap');
//         }

//        echo '<pre>';
//        var_dump($data);exit;

//        传递网站和投资公告数据
//        $this->setGongGao();
        
//        $this->assign('uerinfor',$this->newuser());

//        传递网站动态文章数据
//        $this->setDongTai();


//        传递捷引金融观点, 媒体报道, 活动数据给视图层
//        $this->setZiXun()->setZiXun(4)->setZiXun(5);
        $this->display();
    }


    /**
     * @todo 传递网站公告数据给视图层
     * @param $identity (0: 网站公告; 1: 投资公告)
     * @return $this
     */
    public function  setGongGao($identity=0){
        $gonggao = M('Gonggao');

        $where = 'identity=0';
        $limit = 5;
        $var = 'wangzhangonggao';

        if(1 == $identity){
            $where = 'identity=1';

            $limit = 4;
            $var = 'touzigonggao';
        }
        $data = $gonggao->field('content,date_added')->where($where)->order('id DESC')->limit($limit)->select();

//        转换时间格式
        if(1 == $identity){
            for($i=0,$n=count($data); $i < $n; $i++){

                $data[$i]['date_added'] = date('m-d', strtotime($data[$i]['date_added']));
            }
        }
        $this->assign($var,$data);

        return $this;
    }


    private function chagehdgg()
    {
        $url1='http://news.garhfx.com/news/tactics/';
        $url2='http://news.garhfx.com/news/media/';
        $url3='http://news.garhfx.com/about/company-news/';
        
        $pattern='/<div class="news">[^<>]*<div class="newsLeft">[^<>]*<ul class="newsList">[^<>]*<li>[^<>]*<a class="newsLink" href="(.+)" target="_blank">[^<>]*<div class="newsPic">[^<>]*<img src=".+" width="\d+" height="\d+" alt=".+">[^<>]*<\/div>[^<>]*<div class="newsText">[^<>]*<h4>(.+)<\/h4>[^<>]*<p>(.*)<\/p>[^<>]*<div class="tagTime">[^<>]*<span class="tag">.+<\/span>[^<>]*<span class="time">(\d+)-(\d+)-(\d+)<\/span>[^<>]*<\/div>[^<>]*<\/div>[^<>]*<\/a>[^<>]*<\/li>/';        
        
        $output1=curl_get($url1);     
        $output2=curl_get($url2);       
        $output3=curl_get($url3);

        preg_match($pattern,$output1,$result1);
        preg_match($pattern,$output2,$result2);
        preg_match($pattern,$output3,$result3);

        return [$result1,$result2,$result3];
    }
    public function gethdgg()
    {
        if(IS_AJAX)
        {
            $this->ajaxReturn($this->chagehdgg());
        }       
    }
    
    
    private function newuser()//投资公告
    {
        $User=M('User');
        //$sql='select id,rname from gjb_user where id>=(select rand()*max(id) from gjb_user) limit 10';
        //$uerinfor=$User->query($sql);
        $uerinfor=$User->order('id desc')->field('id,rname,reg_time')->limit(10)->select();
        foreach($uerinfor as $key=>$val)
        {
            $uerinfor[$key]['rname']=msubstr($val['rname'],0,1,"utf-8",true,'**');
            $where['id']=array('ELT',$val['id']);
            $uerinfor[$key]['nowtotal']='2'.mt_rand(0, 9).$User->where($where)->count('id').mt_rand(0, 9);
        }
        return $uerinfor;
    }
    
    public function newuserajax()
    {        
        header('content-type:application:json;charset=utf8');
        $origin = isset($_SERVER['HTTP_ORIGIN'])? $_SERVER['HTTP_ORIGIN'] : '';
        $allow_origin = array(
            'http://www.g5555.com.cn'
        );
        
        if(in_array($origin, $allow_origin)){
            header('Access-Control-Allow-Origin:'.$origin);
            header('Access-Control-Allow-Methods:POST');
            header('Access-Control-Allow-Headers:x-requested-with,content-type');
        }
        $this->ajaxReturn($this->newuser());
    }

    /**
     * @todo 传递网站动态文章数据给视图层
     * @return $this
     */
    public function  setDongTai(){
        $dongtai = M('Dongtai');
        $data = $dongtai->field('title,description,date_added')->where('identity=0')->order('id DESC')->limit(6)->select();
        for($i=0,$n=count($data); $i < $n; $i++){

            $data[$i]['description'] = msubstr($data[$i]['description'], 0, 38,'utf-8').'...';
            $data[$i]['date_added'] = date('Y-m-d', strtotime($data[$i]['date_added']));
        }
        $this->assign('wangzhandongtai',$data);
        return $this;
    }


    /**
     * @todo 传递捷引金融观点, 媒体报道, 活动数据给视图层
     * @param $identity (0:行情资讯; 1: 交易策略; 2: 及时资讯; 3: 捷引金融观点; 4: 媒体报道; 5: 捷引金融活动)
     * @return $this
     */
    public function  setZiXun($identity=3){
        $zixun = M('Zixun');

        $where = ' status=1 and identity=3';
        $limit = 1;
        $var = 'opinion';

        switch($identity){
//                媒体报道
            case 4:
                $where = ' status=1 and identity=4';

//            $limit = 4;
                $var = 'report';
                break;
//                捷引金融活动
            case 5:
                $where = ' status=1 and identity=5';

//            $limit = 4;
                $var = 'activity';
                break;

        }

        $data = $zixun->field('id,title,description,date_added')->where($where)->order('id DESC')->limit($limit)->select();
//        echo '<pre>';
//        var_dump($data);exit;

        $data = $data[0];

//        转换时间格式 限制输出字符数

        $data['description'] = msubstr($data['description'], 0, 58,'utf-8').'...';
        $data['date_added'] = date('m-d', strtotime($data['date_added']));
        $this->assign($var,$data);

        return $this;
    }
    

}
