<?php
namespace Home\Controller;

class LoginController extends HomeController
{
    public function index()//注册
    {
        $this->display();
    }
    public function dologin()//用户登陆
    {
        if(IS_AJAX)
        {
            $user=D('User');
            $this->ajaxReturn( $user->dologin() );
        }
        else
        {
            $this->error('非法打开链接');
        }
    }
    public function greatecode()
    {
        greatecode();
    }
    public function logout()
    {
        session('user',null);
        $this->redirect('/');
    }
}