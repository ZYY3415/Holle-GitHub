<?php

namespace Home\Controller;


use Think\Controller;

class DownloadcenterController extends Controller
{

//    public function index(){ //下载中心
//
//        $this->display();
//    }

    private function setActionName(){ //传送 action name 给视图层
        $this->assign('actionName',ACTION_NAME);
        return $this;
    }

    private function setDownloadLink(){ //传送 action name 给视图层
        $this->assign('DOWNLOAD_LINK', C('DOWNLOAD_LINK'));
        return $this;
    }


    public function android(){ //下载中心_安卓

        $this->setActionName()->setDownloadLink()->display();
    }

    public function pc(){ //下载中心_电脑端

        $this->setActionName()->setDownloadLink()->display();
    }
    public function apple(){ //下载中心_苹果

        $this->setActionName()->setDownloadLink()->display();
    }

    private function help(){ //下载中心_操作指引

        $this->setActionName()->display();
    }



}