<?php
namespace Home\Controller;

class AgentController extends HomeController
{
    protected function _initialize()
    {
        parent::_initialize();
        $this->islogin();
        $this->assign('actionname',ACTION_NAME);
        $this->assign('title',$this->title(ACTION_NAME));
    }
    private function islogin()//检测是否登陆
    {
        if( session('user')['agentid']==0 )  $this->redirect('/usercenter');         
    }
    private function title($para)
    {

    	$title['index']='首页';
    	$title['agentlist']='代理列表';
    	$title['customerlist']='客户列表';
    	$title['commission']='佣金管理';
    	$title['sonagent']='下级代理商返佣';
    	$title['tradersposition']='仓位总结';
    	$title['openposition']='未平仓订单';
    	$title['closeposition']='已平仓订单';
    	$title['setexchangerate']='汇率设置';
    	$title['systemnotice']='系统公告';
        $title['sxf']='手续费设置';
        return $title[$para];
    }

    public function index()//代理商首页
    {
        $User=D('User');
        $userinfo=$User->userinfo();
        $Agent=M('Agent');
        $userinfo['agentibcode']=$Agent->where(array('id'=>$userinfo['agentid']))->getField('ibcode');
        $this->assign('userinfo',$userinfo);
        $this->display();
    }
    public function agentlist()//代理列表
    {  	
        myurl();
        $Agent=D('Agent');
        $allagentid=$Agent->findson(session('user')['agentid']);
        if($allagentid)
        {
            $pagelist=10;
            $where='';
            $User=M('User');            
            if(I('mt4account')) $where['mt4account']=I('mt4account');
            if(I('rname')) $where['rname']=I('rname');
            $allagentid=implode(',', $allagentid);
            $where['agentid']=array('in',$allagentid);
            $allUser=$User->where($where)->select();
            foreach ($allUser as $key=>$val)
            {
                $allUser[$key]['info']=$val['tel']&&$val['email']&&$val['card']?'√':'×';
                $allUser[$key]['sex']=showsex($val['sex']);
                $allUser[$key]['reg_time']=date('Y-m-d',$val['reg_time']);
                $allUser[$key]['agent']=$val['agentid']==0?'客户':'代理商';
                $agentlist=$Agent->where(array('id'=>$val['agentid']))->find();
                $allUser[$key]['customer']=$User->where(array('ibcode'=>$agentlist['ibcode']))->count('id');
                $allUser[$key]['pagent']=$Agent->where(array('id'=>$agentlist['pid']))->getField('ibcode');
                $allUser[$key]['sagent']=count($Agent->findson($val['agentid']));
            }
            $this->assign('allUser',$allUser);        
            $mypage=new \Org\Util\Mypage;
            $this->assign('page',$mypage->page($User->where($where)->count('id'),$pagelist));
        }
        $this->display();
    }
    public function customerlist()//客户列表
    {   
        myurl();
        $Agent=M('Agent');
        $pagelist=10;
        $where='';
        if(I('mt4account')) $where['mt4account']=I('mt4account');
        if(I('rname')) $where['rname']=I('rname');
        if(session('user')['agentid']!=1) $where['ibcode']=$Agent->where(array('id'=>session('user')['agentid']))->getField('ibcode');
        $User=D('User');
        $allUser=$User->field('mt4account,rname,sex,tel,email,card,agentid,reg_time')->where($where)->page(I('page'),$pagelist)->select();
        if($allUser)
        {
            foreach ($allUser as $key=>$val)
            {
                $allUser[$key]['info']=$val['tel']&&$val['email']&&$val['card']?'√':'×';
                $allUser[$key]['sex']=showsex($val['sex']);
                $allUser[$key]['reg_time']=date('Y-m-d',$val['reg_time']);
                $allUser[$key]['agent']=$val['agentid']==0?'客户':'代理商';
            }
            $this->assign('allUser',$allUser);
            $mypage=new \Org\Util\Mypage;
            $this->assign('page',$mypage->page($User->where($where)->count('id'),$pagelist));
        }
        $this->display();
    }
    public function commission()//佣金管理
    {    	
    	$this->display();
    }
    public function sonagent()//下级代理商返佣
    {    	
        $this->display();
    }
    public function tradersposition()//仓位总结
    {    	
    	$this->display();
    }
    public function openposition()//未平仓订单
    { 	
        $this->display();
    }
    public function closeposition()//已平仓订单
    {	
        $this->display();
    }
    public function setexchangerate()//客服设置汇率
    {
        if(session('user')['agentid']!=1) $this->redirect('/agent');
        $this->display();
    }
    public function systemnotice()//系统公告
    {
        $this->display();
    }
    public function setexchangerateod()//客服设置汇率
    {
        if(IS_AJAX)
        {
            $Exchangerate=D('Exchangerate');
            $this->ajaxReturn($Exchangerate->setexchangerateod());
        }
        else
        {
            $this->error('非法访问');
        }
    }

    public function sxf()
    {
        $this->display();
    }
    public function sxfdo()
    {
        if(IS_AJAX)
        {
            $Sxf=D('Sxf');
            $this->ajaxReturn($Sxf->sxfdo());
        }

    }

}