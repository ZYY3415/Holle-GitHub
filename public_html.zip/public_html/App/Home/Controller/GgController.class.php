<?php
namespace Home\Controller;

class GgController extends HomeController {

    public function index()
    {
        redirect('http://news.garhfx.com/about/company-news/7115.html');
    }
    
    public function gg()
    {
        $this->display();
    }

}

