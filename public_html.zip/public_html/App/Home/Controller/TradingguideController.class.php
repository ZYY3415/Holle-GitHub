<?php
namespace Home\Controller;

class TradingguideController extends HomeController {

    private function setActionName(){ //传送 action name 给视图层
        $this->assign('actionName',ACTION_NAME);
        return $this;
    }
    public function insurance() //安全保障
    {
        $this->setActionName()->display();
    }
    public function rules()//交易细则
    {
        $this->setActionName()->display();
    }
    public function calculation()//盈亏计算
    {
        $this->setActionName()->display();
    }
    public function precautions()//注意事项
    {
        $this->setActionName()->display();
    }
    public function advantage()//投资优势
    {
        $this->setActionName()->display();
    }


}