<?php
namespace Home\Controller;
use BestPay\BestPay;
use Think\Log;

class UsercenterController extends HomeController
{
    protected function _initialize()
    {
        parent::_initialize();
        $this->islogin();
        $this->assign('actionname', ACTION_NAME);
    }

    private function islogin()//检测是否登陆
    {
        if (!session('?user')) $this->redirect('/login');
    }

    public function index()//用户中心首页
    {
        $User = M('User');
        $userinfo = $User->field('card,email')->where(array('id' => session('user')['id']))->find();
        //获取mt4账户余额
        $accounts['accounts'] = array(session('user')['mt4account']);
        $accounts = json_encode($accounts);
        $post_data['data'] = $accounts;
        $result = postmt4('getaccount', $post_data);

        getlogger()->debug($result);//debug日志

        if ($result['success']==true){
            $userinfo['money']=$result['data'][0]['Balance'];//余额
        }else{
            $userinfo['money']=0;
        }
        $this->assign('userinfo', $userinfo);
        $this->display();
    }

    public function payinshow()//注资页面
    {
        $this->assign('exchangerate',exchangerate());//汇率
        $this->display();
    }


    public function payinshowdo()//注资
    {
        $Payin = D('Payin');
        $this->ajaxReturn($Payin->payinshowdo());
    }

    /**
     *
     */
    public function payto()
    {
        $payin = D('Payin');

        if (session('?payin')) {

            $exchange= exchangerate();//汇率

            $fee = session('payin')['Ordamt'];//单位 美元

            $orderNo = $payin->orderCreate();
            $bankCode = session('payin')['paytype'];
            $mt4Account = session('user')['mt4account'];


            //记录数据库
            $data['userid'] = session('user')['id'];
            $data['rname'] = session('user')['rname'];
            $data['mt4account'] = $mt4Account;
            $data['tel'] = session('user')['tel'];
            $data['pay_time'] = time();
            $data['pay_ip'] = get_client_ip(1);
            $data['money'] = $fee;//付款金额 ，美元
            $data["exchangerate"] = $exchange;
            $data['status'] = 0;
            $data['prdordno'] = $orderNo;
            $data['prdordnam'] = $mt4Account;
            $data['ordamt'] = $fee*$exchange;//付款金额，元RMB
            $data['orddate'] = date('Ymd');
            $data['bankcode'] = $bankCode;

            Log::record(json_encode($data),Log::DEBUG);//测试

            $rrp = $payin->add($data);

            if (!$rrp) {
                echo '出错啦！无法将入金信息写入数据库';
                Log::write($payin->getDbError());
            }
            $Return_url = U('Usercenter/payinsuccess', '', 'html', $_SERVER['HTTP_HOST']);
            $Notify_url = U('Payresult/payinnotify', '', 'html', $_SERVER['HTTP_HOST']);
            //提交到第一支付的数据
            $order = array(
                "appid" => C('DYZF_APP_ID'),//商户appid,
                'appkey'=>C('DYZF_KEY'),//商户key
                "return_url" => $Return_url,
                "notify_url" => $Notify_url,//后台通知页面
                "out_trade_no" => $orderNo,//$out_trade_no,//订单号
                "subject" => 'Firma入金',//订单名称，必填
                "total_fee" => $fee * $exchange,//付款金额，必填,第一支付接收单位为元
                "paytype" => $bankCode,//银行代号/支付宝/微信
                "partnerUserId" => session('user')['id'],//要换成session('user')['id'];
                "client" => C('DYZF_CLIENT'),
                "rname" => session('user')['rname'],
                'mt4account' => session('user')['mt4account'],
                'tel' => session('user')['tel']
            );

            vendor('bestpay.BestPay');
            $pay = new BestPay();

            getlogger()->debug($order);//debug日志

            $pay->deposit($order);//发起支付请求，入金
        }
    }


    public function payinsuccess()//注资成功返回页面
    {
        $this->display();
    }
    public function payoutshow()//取款页面
    {
        $User = M('User');

        $userwsxx = $User->field('rname,cardtype,card,tel,email,bank,subbank,bankaccount,filecard,filebank')->where(array('id' => session('user')['id']))->find();
        if ( (!$userwsxx['rname']) || (!$userwsxx['cardtype']) || (!$userwsxx['card']) || (!$userwsxx['tel']) || (!$userwsxx['email']) || (!$userwsxx['bank']) || (!$userwsxx['subbank']) || (!$userwsxx['bankaccount']) || (!$userwsxx['filecard']) || (!$userwsxx['filebank'])) {
            $flag = 'abc';
        }
        else {
            $flag = '';
        }
        $this->assign('exchangerate',exchangerate());//汇率
        $this->assign('userinfo', $userwsxx);
        $this->assign('flag', $flag);
        //var_dump($flag);die();
        $this->display();
    }

    public function payoutsuccess()//取款成功页面
    {
        $this->display();
    }

    public function payoutdo()//取款
    {
        $Payout = D('Payout');
        $this->ajaxReturn($Payout->payoutdo());

    }

    /**
     * 取款申请结果回掉
     */
    public function payoutreturn()
    {
        vendor('pay.bestpay.Bestpay');
        //校验数据
        $bestpay = new BestPay();
        if ($bestpay->verify()) {
            //读取传过来的订单数据
            //验证成功，说明是我们的订单数据,更新数据库订单数据
            $orderno = $_POST['order'];//订单号
            $fee = $_POST['money'];//出金金额
            $status = $_POST['trade_status'];//订单状态
            $realmenoy = $_POST['user_money'];//扣了手续费之后的金额

            //从数据库拿订单数据
            $payin = M('Payout');
            $payinrecorde = $payin->where(array('prdordno' => $orderno))->find();

            if ( null != $payinrecorde && $fee == $payinrecorde['ordamt']) {//数据库中有记录
                if ($status == 'TRADE_SUCCESS' ) {// 交易成功
                    $payinrecorde['status'] = 1;
                    $payinrecorde['pay_time'] = time();
                    if (!$payin->save($payinrecorde)) {//无法更新数据库
                        //记录错误日志
                        Log::write($payin->getDbError());
                    }
                    //异步POST通知，输出success字符串，告知服务器已经完成处理
                    echo "success";
                } else {//交易失败
                    //向mt4中入金，退回之前从mt4服务器中减少的金额
                    $post_data = array('account' => $payinrecorde['mt4account'],
                        'command' => 'BALANCE',
                        'price' => $fee,
                        'expiration' => time() + 3000,
                        'balanceno' => $orderno,
                        'comment' => 'D ' . $orderno);
                    try {
                        $result = postmt4('transaction', $post_data, 0);
                    } catch (Exception $e) {
                        Log::write($e->getMessage());
                    }
                    if ($result['success'] != true){//回退资金失败
                        //将mt4操作记录记录至数据库
                        M('Payinlog')->add(['mt4account' => $payinrecorde['mt4account'],
                            'balance' => $payinrecorde['money'] / 100 * (-1),
                            'prdordno' => $payinrecorde['order'], 'log' => $result,
                            'type' => 1, 'create_time' => time()]);
                        Log::write($result);
                    }
                }
                echo 'success';
            }else{
                echo 'fail';
            }
        }else{
            echo 'fail';
        }
    }

    public function getmoney()//获取个人账户信息;
    {
        if (IS_AJAX) {
            $url = 'getaccount';
            $accounts['accounts'] = array(session('user')['mt4account']);
            $accounts = json_encode($accounts);
            $post_data['data'] = $accounts;
            $result = postmt4($url, $post_data, 0);
            echo $result;
        }
        else {
            $this->error('非法打开链接');
        }
    }

    public function traderecorde()//交易记录
    {
        $this->display();
    }

    public function traderecordedo()//获取交易记录
    {
        for ($i=0;$i<50;$i++) {
            $datat[$i]['Deal']='123441'.$i;//订单号
            $datat[$i]['Opentime']='2017-08-24';//建仓时间
            $datat[$i]['Openprice']=34.90+$i;//开仓价
            $datat[$i]['Closeprice']=36.98+$i;//平仓价
            $datat[$i]['Closetime']='2017-08-25';//平仓时间
            $datat[$i]['Volume']=3*$i;//手数
            $datat[$i]['Storage']=34-$i;//仓利息
            $datat[$i]['Profit']=54+$i;//获利
        }

        exit(json_encode($datat));

        if (IS_AJAX) {
            $url = 'getaccounttrades';
            $data['account'] = session('user')['mt4account'];
            $data['from'] = strtotime(I('post.fromtime'));
            $data['to'] = strtotime(I('post.totime') . '23:59:59');
            $data = json_encode($data);
            $post_data['data'] = $data;
            $result = postmt4($url, $post_data, 0);

            getlogger()->debug($result);//debug日志

            echo $result;
        }
        else {
            $this->error('非法打开链接');
        }
    }

    /**
     * 获取注资记录
     */
    public function getpayinrecorde()
    {
        myurl();
        $Payin = D('Payin');
        $mychecktime = mychecktime();
        if ($mychecktime['code'] == 1) {
            $redata = ['id' => session('user')['id'], 'fromtime' => I('get.fromtime'), 'totime' => I('get.totime'), 'status' => I('get.status')];
            echo json_encode($Payin->payinrecorde($redata));
        }
    }
    
    public function payinrecorde()//注资记录
    {
        myurl();
        $Payin = D('Payin');
        $mychecktime = mychecktime();
        if ($mychecktime['code'] == 1) {
            $redata = ['id' => session('user')['id'], 'fromtime' => I('get.fromtime'), 'totime' => I('get.totime'), 'status' => I('get.status')];
            $this->assign('payinrecorde', $Payin->payinrecorde($redata));
        }
        $this->display();
    }

    /**
     * 获取取款记录
     */
    public function getpayoutrecorde()
    {
        getlogger()->debug($_REQUEST);//debug 日志
        myurl();
        $Payout = D('Payout');
        $mychecktime = mychecktime();
        if ($mychecktime['code'] == 1) {
            echo json_encode( $Payout->payoutrecorde());
        }
    }
    public function payoutrecorde()//取款记录
    {
        myurl();
        $Payout = D('Payout');
        $mychecktime = mychecktime();
        if ($mychecktime['code'] == 1) {
            $this->assign('payoutrecorde', $Payout->payoutrecorde());
        }
        $this->display();
    }

    public function checktime()//取款检测时间的合法性
    {
        if (IS_AJAX) {
            $this->ajaxReturn(mychecktime());
        }
        else {
            $this->error('非法打开链接');
        }
    }

    public function userinfo()//资料管理
    {
        $User = D('User');
        $this->assign('userinfo', $User->userinfo());
        $this->display();
    }

    public function completeinfo()//完善资料页面
    {
        $User = D('User');
        $this->assign('userinfo', $User->completeinfo());
        $this->display();
    }

    public function completeinfodo()//完善资料
    {
        if (IS_AJAX) {
            $User = D('User');
            $this->ajaxReturn($User->completeinfodo());
        }
        
        else {
            $this->error('非法打开链接');
        }
    }

    public function cardupload()//证件上传页面
    {
        $User = D('User');
        $this->assign('userinfo', $User->cardupload());
        $this->display();
    }

    public function upcard()//响应ajax上传证件
    {
//        $list=M('User')->field('filecard,filebank')->where(['id'=>session('user')['id']])->find();
//        if( $list['filecard'] )
//        {
//            $info['code']=-2;
//            $info['errormsg']='身份证已经上传';
//            $this->ajaxReturn($info);
//        }
//        if( $list['filebank'] )
//        {
//            $info['code']=-3;
//            $info['errormsg']='银行卡已经上传';
//            $this->ajaxReturn($info);
//        }

        $upload = new \Think\Upload();// 实例化上传类
        $upload->rootPath = './upload/card/';//设置跟目录
        $upload->maxSize = 512 * 1024;// 设置附件上传大小
        $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->subName = session('user')['id'];  //设置只文件名
        $upload->saveName = date('YmdHis') . mt_rand(10000, 99999);
        $info = $upload->uploadOne($_FILES['file']);
        if (!$info) // 上传错误提示错误信息
        {
            $info['code'] = -20;
            $info['errormsg'] = $upload->getError();
            $this->ajaxReturn($info);
        }
        else // 上传成功
        {
            $info['code'] = 1;
            $info['url'] = '/upload/card/' . $info['savepath'] . $info['savename'];
            $this->ajaxReturn($info);
        }
    }

    public function carduploaddo()//保存证件上传的路径

    {
        if (IS_AJAX) {
            $User = D('User');
            $this->ajaxReturn($User->carduploaddo());
        }
        else {
            $this->error('非法访问');
        }
    }

    public function editpassword()//网站修改密码页面
    {
        $this->display();
    }

    /**发送手机验证码
     * @return mixed
     */
    public function telcode()
    {
        $this->ajaxReturn(telcode(session('user')['tel']));
    }
    
    public function editpassworddo()//修改密码
    {
        if (IS_AJAX) {
            $User = D('User');
            $this->ajaxReturn($User->editpassworddo());
        }
        else {
            $this->error('非法访问');
        }
    }

    public function editmt4pass()//MT4密码页面
    {
        $this->display();
    }

    public function editmt4passdo()//MT4密码页面

    {
        if (IS_AJAX) {
            $User = D('User');
            $this->ajaxReturn($User->editmt4passdo());
        }
        else {
            $this->error('非法访问');
        }
    }

    public function transfer()
    {
        if (session('user')['agentid'] != 0) {
            $this->display();
        }

    }

    public function transferdo()
    {
        if (IS_AJAX && (session('user')['agentid'] != 0)) {
            $this->ajaxReturn($this->settransfer());
        }
    }

    private function settransfer()
    {
        if (I('post.money') < 0) {
            $errormsg['code'] = -1;
            $errormsg['msg'] = '取款金额不能小于0';
            return $errormsg;
        }

        $accounts['accounts'] = array(I('post.mt4account'));
        $accounts = json_encode($accounts);

        $result = postmt4('getaccount', ['data' => $accounts]);

        if ($result['success'] != true || $result['data'][0]['Login'] != I('post.mt4account')) {
            $errormsg['code'] = -1;
            $errormsg['msg'] = '转账账户不存在！';
            return $errormsg;
        }

        $post_data = array(
            'account' => session('user')['mt4account'],
            'primary_password' => I('post.mt4pass')
        );

        $result['success'] = false;
        $result = postmt4('authenticate', $post_data);

        if ($result['success'] !== true) {
            $errormsg['code'] = -4;
            if (stripos($result['error'], 'Network') !== false) {
                $errormsg['msg'] = '网络错误，请稍后再！';
                return $errormsg;
            }
            elseif (stripos($result['error'], 'account') !== false) {
                $errormsg['msg'] = '密码错误！';
                return $errormsg;
            }
            elseif (stripos($result['error'], 'paramenters') !== false) {
                $errormsg['msg'] = '非法参数，请稍后再试！';
                return $errormsg;
            }
            else {
                $errormsg['message'] = '非法参数，请稍后再！';
                return $errormsg;
            }
        }

        $Payout = D('Payout');

        $data['userid'] = session('user')['id'];
        $data['mt4account'] = session('user')['mt4account'];
        $data['bank_account'] = I('post.mt4account');
        $data['money'] = I('post.money') * 100;
        $data['exchangerate'] = exchangerate();
        $data['pay_time'] = time();
        $data['pay_ip'] = get_client_ip(1);
        $data['status'] = 3;
        $data['order'] = $Payout->order();

        $Payout->add($data);

        $result['success'] = false;

        $post_data = array('account' => $data['mt4account'], 'command' => 'BALANCE', 'price' => $data['money'] / 100 * (-1), 'expiration' => time() + 3000, 'balanceno' => $data['order'], 'comment' => 'W ' . $data['order']);

        try {
            $result = postmt4('transaction', $post_data, 0);
        } catch (Exception $e) {
        }

        M('Payinlog')->add(['mt4account' => $data['mt4account'], 'balance' => $data['money'] / 100 * (-1), 'prdordno' => $data['order'], 'log' => $result, 'type' => 1, 'create_time' => time()]);

        $result = json_decode($result, true);
        if ($result['success'] != true) {
            if ($result['errno'] == -90) {
                $errormsg['code'] = -90;
                $errormsg['msg'] = '有未平仓订单，不能转账！';
                return $errormsg;
            }
            elseif ($result['errno'] == -80) {
                $errormsg['code'] = -80;
                $errormsg['msg'] = '没有足够的余额！';
                return $errormsg;
            }
            elseif ($result['errno'] == -70) {
                $errormsg['code'] = -70;
                $errormsg['msg'] = '未能检测到用户的余额，请稍后重试！';
                return $errormsg;
            }
        }
        else {
            $Payin = D('Payin');
            $payOrdNo = $Payin->orderCreate();

            $Payin->add([
                'userid' => session('user')['id'],
                'mt4account' => I('post.mt4account'),
                'pay_time' => time(),
                'pay_ip' => get_client_ip(1),
                'money' => $data['money'],
                'prdordno' => $payOrdNo,
                'payOrdNo' => $data['order'],
                'status' => 3
            ]);

            $post_data = array('account' => I('post.mt4account'), 'command' => 'BALANCE', 'price' => $data['money'] / 100, 'expiration' => time() + 3000, 'balanceno' => $payOrdNo, 'comment' => 'D ' . $payOrdNo);

            try {
                $result = postmt4('transaction', $post_data, 0);
            } catch (Exception $e) {
            }

            M('Payinlog')->add(['mt4account' => I('post.mt4account'), 'balance' => $data['money'] / 100, 'prdordno' => $payOrdNo, 'log' => $result, 'type' => 2, 'create_time' => time()]);

            $de_result = json_decode($result, true);
            if ($de_result['success'] != true) {
                $errormsg['code'] = -10;
                $errormsg['msg'] = '转账失败，请重试！';
                return $errormsg;
            }
            else {
                $errormsg['code'] = 1;
                $errormsg['msg'] = '转账成功';
                return $errormsg;
            }
        }

    }

    public function getuser()
    {
        $accounts['accounts'] = array(I('post.mt4account'));
        $accounts = json_encode($accounts);
        $result = postmt4('getaccount', ['data' => $accounts], 0);
        echo $result;
    }

    public function getuseryzm()
    {
        $tel = '13349508783,13766506055,15876572365';//13791949567,其中15876572365为测试号码，后期可以删除

        $smscode = mt_rand(100001, 999999);
        session('useryzm', $smscode);
        sendsms($tel, array($smscode), "50975");
        $errormsg['code'] = 1;
        $errormsg['message'] = '手机验证码发送成功！';

        $this->ajaxReturn($errormsg);
    }
}
