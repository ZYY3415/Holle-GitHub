<?php
namespace Home\Controller;
use Think\Controller;
use Think\Exception;

class TestController extends Controller{
    
    /**
     * 
     */
    public function adduser()
    {
        //$mt4pass=greatmt4pass();
        $mt4pass='gjb123';
        $post_data=array(
            'group'=>'99',//必须参数
            'name'=>'test561',//必须参数
            'account'=>'123789',
            'primary_passwd'=>$mt4pass,//必须参数
            'investor_passwd'=>$mt4pass
        );
        $result=postmt4('addaccount', $post_data);
        dump($result);
    }
    
//     public function edituser()
//     {
//         $url='resetpassword';    
//         $post_data=array(
//             'account'=>561590,
//             'primary_password'=>'gjb777',
//             //'name'=>'TEST161584',
//             //'telephone'=>'18888222000',
//         );        
//         $result=$this->mypostmt4($url, $post_data);
//         dump($result);
         
//     }

//     public function listtrades()
//     {
//         $url='listorders';
    
//         $post_data=array(
//             'observe'=>true,
//             'timestamp'=>0,
//         );
        
//         $result=$this->mypostmt4($url, $post_data);
//         var_dump($result);
         
//     }
    
//     public function listusers()
//     {
//         $url='listusers';
    
//         $post_data=array(
//             'observe'=>true,
//             'timestamp'=>0,
//         );
    
//         $result=$this->mypostmt4($url, $post_data);
//         var_dump($result);
//     }
    

    public function getaccount()
    {        
        $url='getaccount';
        $accounts['accounts']=array(999999);
        $accounts=json_encode($accounts);
        $post_data['data']=$accounts;
        $result=postmt4($url,$post_data,1);
        var_dump($result['data'][0]['Group']) ;      
    }    
    
//     public function getaccounttrades()
//     {
//         $url='getaccounttrades';              
//         $data['account']='123456';
//         $data['from']=time()-3600*24*100;
//         $data['to']=time();        
//         $data=json_encode($data);
//         $post_data['data']=$data;
//         $result=postmt4($url, $post_data,0);
//         echo $result ;
//     }
    
    
    public function tt()
    {
        $url='transaction';
        $post_data = array('account'=>999999, 'command'=>'BALANCE', 'price'=>9999, 'expiration'=>time()+3000,'comment'=>'This is an test transaction');
//         $data = array('account'=>123456, 'command'=>'CREDIT', 'price'=>11111.22, 'expiration'=>time()+3000,'comment'=>'This is an test
//  transaction');
        //$post_data['data']=json_encode($data);
        $result=postmt4($url,$post_data,0);
        
        print_r($result) ;
    }
    
//     function mypostmt4($url,$post_data,$flag=1)
//     {
//         $url='http://10.116.22.58:9980/'.$url;
//         foreach($post_data as $key=>$value)
//         {
//             $post_data[$key] = iconv("utf-8","gb2312//IGNORE",$value);
//         }
//         $ch=curl_init();
//         curl_setopt($ch,CURLOPT_URL, $url);
//         curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
//         curl_setopt($ch,CURLOPT_POST, 1);
//         curl_setopt($ch, CURLOPT_TIMEOUT,60);
//         curl_setopt($ch,CURLOPT_POSTFIELDS, $post_data);
//         $output=curl_exec($ch);
//         curl_close($ch);
//         if($output&&($flag==1)) $output=json_decode($output,true);
//         return $output;
//     }
    
    
//     function bendi($url)
//     {
//         $url='http://jyjrwx.com/test/'.$url;
//         $ch=curl_init();
//         curl_setopt($ch,CURLOPT_URL, $url);
//         curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
//         curl_setopt($ch,CURLOPT_POST, 1);
//         curl_setopt($ch, CURLOPT_TIMEOUT,60);
//         //curl_setopt($ch,CURLOPT_POSTFIELDS, $post_data);
//         $output=curl_exec($ch);
//         curl_close($ch);
//         return $output;
//     }
    
//     public function test()
//     {
//         $result=$this->bendi('getaccount');
//         echo $result;
//     }
    
//     public function test11()
//     {
//         echo '';
//     }
    
//     public function testttt()
//     {
// //         //echo date('Y-m-d H:i:s',1456380758);
// //         $aaaa='{"success":true, "data":[], "total": 0, "stamp": 1456380758}';
// //         $aaaa=json_decode($aaaa,true);
// //         print_r($aaaa);

//        //var_dump(ini_get("magic_quotes_gpc"));
       
//         //echo greatmt4pass();
        
// //         $User=M('User');
// //         $data['id']=array('egt',1);
// //         $data['agentid']=0;
// //         $User->save($data);
//             $var=3.14;
//             echo get_client_ip(1);
//     }
//     public function test1()
//     {
//         $data=I('post.');
//         $this->ajaxReturn($data);
//     }
    
//     public function test3()
//     {
//         $aaa=M('Exchangerate');
//         echo $aaa->order('id desc')->getField('exchangerate');
//         echo $aaa->getLastSql();
//     }
    
//     public function test4()
//     {
//         $User=M('User');
//         $where=array(
//             'u.agentid'=>'a.id',
//             'u.mt4account'=>'20005',
//         );
//         //$list=$User->table($table)->where($where)->select();
//         $list=$User
//         ->field('u.rname,u.mt4account,a.ibcode')
//         ->table('gjb_user u,gjb_agent a')
//         ->where('u.agentid=a.id and u.mt4account=20005')
//         ->select();
        
        
//         print_r($list);
//     }
    
//     public function test5()
//     {
//         $User=M('User');
//         $geshu=$User->count('id');
//         echo $geshu;
//     }
    
//     public function testme()
//     {
//         $mem=new \Memcache();
//         $mem->connect('192.168.1.58',11211);        
//         $mem->set('bbb','2222');
//         print_r($mem->get('bbb'));
        
        
//         $mem->close();
//     }
    
//     public function testgetmemcache()
//     {
//         $redis=new \Redis();
//         $redis->connect('192.168.1.58',6379);
//         $redis->set('aaa','1111111');
//         print_r($redis->get('aaa'));
//     }
 
//     public function testpf()
//     {
//         printf('您好%s！您%d月账单是￥%d。','那敏',3,1000);
//         //echo $a;
//     }
    
//     public function aaa()
//     {
//         $mt4pass=greatmt4pass();
//         $post_data=array(
//             //'group'=>'99999',//必须参数
//             'group'=>'demoforex',//必须参数
//             'name'=>'测试开户4',//必须参数
//             'account'=>2123479274,
//             'primary_passwd'=>$mt4pass,//必须参数
//             'investor_passwd'=>$mt4pass
//         );        
        
//         $result=postmt4('addaccount', $post_data);
//         echo '<p>第一次执行结果：——————————————</p>';
//         print_r($result);
//         echo '<p>第一次执行结果：——————————————</p>';
        
//         $i=0;
//         while( ($result['success']!=true)&&($i<3) )
//         {            
//             sleep(3);
//             $result=postmt4('addaccount', $post_data);
//             $i=$i+1;
//             echo "<p>重试第{$i}次结果：——————————————</p>";
//             print_r($result);
//             echo "<p>重试第{$i}次结果：——————————————</p>";
//         }
        
//         echo '<p>执行结束</p>';
//     }
    
//     public function bb()
//     {
//         $temp='';
//         for($i=0;$i<30;$i++)
//         {
//             sleep(5);
//             $temp.="<p>第{$i}次执行————————————————————————</p>";
//         }
//         echo $temp;
//     }
    
//     public function cc()
//     {
//         echo date('Y-m-d H:i:s',1462514229);
//     }
    
     public function login()
     {
         $mt4account=999999;
         $User=M('User');
         $userinfo=$User->field('id,rname,tel,mt4account,agentid')->where(array('mt4account'=>$mt4account))->find();
        
         session('user',$userinfo);
     }
    
//     public function ajaxtest1()
//     {
//         $url1='http://news.garhfx.com/news/tactics/';
//         //$url2='http://news.garhfx.com/news/media/';
//         //$url3='http://news.garhfx.com/about/company-news/';
        
//         $pattern='/<div class="news">[^<>]*<div class="newsLeft">[^<>]*<ul class="newsList">[^<>]*<li>[^<>]*<a class="newsLink" href="(.+)" target="_blank">[^<>]*<div class="newsPic">[^<>]*<img src=".+" width="\d+" height="\d+" alt=".+">[^<>]*<\/div>[^<>]*<div class="newsText">[^<>]*<h4>(.+)<\/h4>[^<>]*<p>(.*)<\/p>[^<>]*<div class="tagTime">[^<>]*<span class="tag">.+<\/span>[^<>]*<span class="time">(\d+)-(\d+)-(\d+)<\/span>[^<>]*<\/div>[^<>]*<\/div>[^<>]*<\/a>[^<>]*<\/li>/';        
        
//         $output1=curl_get($url1);     
//         //$output2=curl_get($url2);       
//         //$output3=curl_get($url3);
//         preg_match($pattern,$output1,$result1);
//         //preg_match($pattern,$output2,$result2);
//         //preg_match($pattern,$output3,$result3);
// //         $result1[]=$url1;
// //         $result2[]=$url2;
// //         $result3[]=$url3;
//         print_r( $result1 );

//     }
    
//     public function testdel()
//     {
//         $buffer=file_get_contents('R:\workerman_1462200696.txt');
         
//         $recv_timestamp=time();
//         $sucess=json_decode($buffer,true);
//         if(json_last_error()==JSON_ERROR_NONE)
//         {
//             $pdo = new \PDO("mysql:host=localhost;dbname=g9999;charset=utf8","root","");
//             $param ="`Name`,`Login`,`Group`,`Status`,`Leverage`,`Balance`,`Credit`,`Interestrate`,`Prevbalance`,`Prevequity`,`Prevmonthbalance`,`Prevmonthequity`,`recv_timestamp`";
            
//             foreach ( $sucess['data'] as $key=>$val )
//             {
//                 if( !$val['Status'] ) $val['Status']=null;
//                 $sql="insert into gjb_listuser ({$param}) values ('{$val['Name']}','{$val['Login']}','{$val['Group']}','{$val['Status']}','{$val['Leverage']}','{$val['Balance']}','{$val['Credit']}','{$val['Interestrate']}','{$val['Prevbalance']}','{$val['Prevequity']}','{$val['Prevmonthbalance']}','{$val['Prevmonthequity']}',{$recv_timestamp})";
                
//                 if($pdo->exec($sql)===false)
//                 {
//                     print_r($pdo->errorInfo());
//                     echo "\n";
//                     echo $sql;
//                     echo "\n";
//                 }
//             }
//         }
        
//     }
    
//     public function geta2($sb=7)
//     {
//         $pdo = new \PDO("mysql:host=localhost;dbname=g9999;charset=utf8","root","");
//         $param ="`Name`,`Login`,`Group`,`Status`,`Leverage`,`Balance`,`Credit`,`Interestrate`,`Prevbalance`,`Prevequity`,`Prevmonthbalance`,`Prevmonthequity`,`recv_timestamp`";
        
//         $sql="insert into gjb_listuser (Name,Login,`Group`,Status,Leverage,Balance,Credit,Interestrate,Prevbalance,Prevequity,Prevmonthbalance,Prevmonthequity,recv_timestamp) values ('吕雯雯','2123479230','demoforex','RE','100','98472.000000','0.000000','0.000000','98472','0','98472','0',1464860498)";
//         //$sql="insert into gjb_listuser (Name,Login,Status,Leverage,Balance,Credit,Interestrate,Prevbalance,Prevequity,Prevmonthbalance,Prevmonthequity,recv_timestamp) values ('吕雯雯','2123479230','','100','98472.000000','0.000000','0.000000','98472','0','98472','0',1464860498)";
        
//         if($pdo->exec($sql)===false)
//         {
//             print_r($pdo->errorInfo());
//             echo "\n";
//             echo $sql;
//             echo "\n";
//         }
//     }
    
//     public function phpsocket()
//     {
//         $param ="Name,Login,Group,Status,Leverage,Balance,Credit,Interestrate,Prevbalance,Prevequity,Prevmonthbalance,Prevmonthequity,recv_timestamp";
//         foreach( explode(',', $param) as $val )
//         {
//             $a[]='{$val['."'".$val."'".']}';
//         }
        
//         echo implode(',', $a);
//     }
    
//     public function testmobie()
//     {
// //        //var_export($_SERVER);
// //        $filename='./upload/testmobie.txt';
// //        $rn="\r\n";
// //        $fp=fopen($filename,'a');
// //        fwrite($fp, var_export($_SERVER,true).$rn);
// //        $string=fread($fp, filesize($filename));
// //        echo $string;
// //        fclose($fp);

//         if(isMobile())
//         {
//             echo '<span style="color:red;font-size:100px;">mobile</span>';
//         }
//         else
//         {
//             echo 'pc';
//         }
//     }

    public function shengji()
    {
        $accounts=json_encode(array('accounts'=>array('999999')));

        $result=postmt4('getaccount',['data'=>$accounts]);

        print_r($result['data'][0]['Login']);

//        if( $result['success']!=true || !isset($result['data']['login']))
//        {
//            $errormsg['code']=-1;
//            $errormsg['msg']='转账账户不存在！';
//            return $errormsg;
//        }

    }
    
    public function aa()
    {
        $post_data = array('account'=>'999999', 'command'=>'BALANCE', 'price'=>10, 'expiration'=>time()+3000,'balanceno'=>'test','comment'=>'Deposit from test');

        try {
            $result=postmt4('transaction',$post_data,0);
        }
        catch(Exception $e) {
        }
    }
    
    public function editpassword()
    {
        $post_data=array(
            'account'=>'999999',
            'primary_password'=>'gjb123',
            'reset'=>'true',
        );
        
        $result=postmt4('resetpassword', $post_data);
        
        print_r($result);
    }

    public function ttt()
    {
        $post_data=array(
            'account'=>'999999',
            'primary_password'=>'123456',
        );
        $result=postmt4('authenticate', $post_data);
        print_r($result);
    }


}