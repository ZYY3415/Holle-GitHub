<?php

namespace Home\Controller;

use BestPay\BestPay;
use Think\Controller;
use Think\Exception;
use Think\Log;

class PayresultController extends Controller
{
    public function notifyurl()
    {
        ini_set("max_execution_time", "240");
        //校验数据
        vendor('Bestpay.Bestpay');
        $bestpay = new BestPay();
        if ($bestpay->verify(C('DYZF_KEY'))) {
            //读取传过来的订单数据
            //验证成功，说明是我们的订单数据,更新数据库订单数据
            $orderno = $_POST['out_trade_no'];//订单号
            $fee = $_POST['total_fee'];//付款金额
            $status = $_POST['trade_status'];//订单状态
            $realmenoy = $_POST['user_money'];//扣了手续费之后的金额

            //从数据库拿订单数据
            $payin = M('Payin');
            $payinrecorde = $payin->where(array('prdordno' => $orderno))->find();

            // 交易成功,数据库中存在该订单，金额一样
            if ($status == 'TRADE_SUCCESS' && null != $payinrecorde && $fee == $payinrecorde['ordamt']) {
                $payinrecorde['status'] = 1;
                $payinrecorde['retime'] = time();
                $payinrecorde['money']=$realmenoy/exchangerate();
                //异步POST通知，输出success字符串，告知服务器已经完成处理

                if (!$payin->save($payinrecorde)) {//无法更新数据库
                    //记录错误日志
                    Log::write($payin->getDbError());
                }
                //短信通知
                sendsms(C('DX_TEL.PAYIN'), array(
                    date('Y-m-d H:i:s'),
                    $payinrecorde['rname'],
                    $payinrecorde['mt4account'],
                    $fee,
                    $orderno
                ), "83924");
                $result['success'] = false;
                $price = $realmenoy;

                if ($price <= 10000) {
                    $post_data = array('account' => $payinrecorde['mt4account'],
                        'command' => 'BALANCE',
                        'price' => $price,
                        'expiration' => time() + 3000,
                        'balanceno' => $orderno,
                        'comment' => 'D ' . $orderno);
                    //向mt4中入金
                    try {
                        $result = postmt4('transaction', $post_data, 0);
                    } catch (Exception $e) {
                        Log::write($e->getMessage());
                    }

                    M('Payinlog')->add(['mt4account' => $payinrecorde['mt4account'],
                        'balance' => $price,
                        'prdordno' => $orderno,
                        'log' => $result,
                        'type' => 2,
                        'create_time' => time()]);
                }

                $de_result = json_decode($result, true);
                if ($de_result['success'] != true) {
                    $mt4log = '自动入金失败!'.$result;
                } else {
                    $mt4log = '自动入金成功';
                }

                //邮件通知
                email('3', array(
                    'rname' => $payinrecorde['rname'],
                    'account' => $payinrecorde['mt4account'],
                    'tel' => $payinrecorde['tel'],
                    'money' => $fee,
                    'prdordno' => $orderno,
                    'mt4log' => $mt4log
                ));

                echo "success";
            } else {
                echo 'fail';
            }
        }
    }


    public function payinnotify()
    {
        ob_clean();
        //echo(json_encode($_POST));

        /*
         {"orderno":"1493227156","fee":"1","signature":"55e66a0d1aad1e9d3038553571d6f6ec0ee73cdf"}
         */

        $key = C('PAYMENT.key');

        // reply to server
        if (payverify($_POST, $_POST['signature'], $key)) {
            // 获取订单编号
            $Prdordno = $_POST['orderno'];
            // 获取付款金额
            $Ordamt = $_POST['fee'];


            //file_put_contents('/tmp/hrpayok.txt', $str);
            $Payin = M('Payin');
            $payinrecorde = $Payin->where(array('prdordno' => $Prdordno))->find();
            if ($payinrecorde['status'] == 0) {
                $update['status'] = 1;
                $update['payOrdNo'] = 'ignore';
                $update['retime'] = time();
                $Payin->where(array('prdordno' => $Prdordno))->save($update);


                // increment credit
                /*
                $post_data['account'] = $payinrecorde['mt4account'];
                $post_data['command'] = 'CREDIT';
                $post_data['price'] = $Ordamt / (exchangerate()) * 0.2;

                $post_data['expiration'] = time() + 60 * 60 * 24 * 360;
                $post_data['comment'] = 'from DEPOSIT';

                $i = 0;
                $result['success'] = false;
                while ($i < 4 && $result['success'] !== true) {
                    $result = postmt4('transaction', $post_data);
                    $i = $i + 1;
                }
                */

                $price = $Ordamt / (exchangerate() * 100);

                //短信通知
                sendsms(C('DX_TEL.PAYIN'), array(
                    date('Y-m-d H:i:s'),
                    $payinrecorde['rname'],
                    $payinrecorde['mt4account'],
                    $price,
                    $Prdordno
                ), "83924");

                $result['success'] = false;


                if ($price <= 10000) {
                    $post_data = array('account' => $payinrecorde['mt4account'],
                        'command' => 'BALANCE', 'price' => $price,
                        'expiration' => time() + 3000,
                        'balanceno' => $Prdordno, 'comment' => 'D ' . $Prdordno);

                    try {
                        $result = postmt4('transaction', $post_data, 0);
                    } catch (Exception $e) {
                    }

                    M('Payinlog')->add(['mt4account' => $payinrecorde['mt4account'],
                        'balance' => $price,
                        'prdordno' => $Prdordno,
                        'log' => $result,
                        'type' => 2,
                        'create_time' => time()]);
                }

                $de_result = json_decode($result, true);
                if ($de_result['success'] != true) {
                    $mt4log = '自动入金失败';
                } else {
                    $mt4log = '自动入金成功';
                }

                //邮件通知
                $edata = array(
                    'rname' => $payinrecorde['rname'],
                    'account' => $payinrecorde['mt4account'],
                    'tel' => $payinrecorde['tel'],
                    'money' => $price,
                    'prdordno' => $Prdordno,
                    'mt4log' => $mt4log
                );
                email('3', $edata);

                $edata['account'] = $payinrecorde['mt4account'];
                $edata['ori_money'] = $price;

                $str = json_encode($edata);

                file_put_contents('/tmp/garhfxpayok.txt', $str . '\n\n');
            }

            echo 'SUCCESS';
        } else {
            echo 'FAILURE';
        }
    }

}