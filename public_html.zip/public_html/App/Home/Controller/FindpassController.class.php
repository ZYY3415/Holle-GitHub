<?php
namespace Home\Controller;

class FindpassController extends HomeController
{

	public function totel()
	{
		$this->display();
	}

	public function telone()
	{
		if (IS_AJAX) {
			$User = D('User');
			$this->ajaxReturn($User->telone());
		} else {
			$this->error('非法打开链接');
		}
	}

	public function telcheck()  //手机验证第二步
	{
		if (session('tuser')['step2'] != 1) {
			$this->redirect('findpass/totel');
		}
		$tel = session('tuser')['tel'];
		$ttel = substr($tel, 0, 3) . '****' . substr($tel, -4);
		$this->assign('ttel', $ttel);
		$this->display();
	}

	public function telcode()//手机验证码
	{
		if (IS_AJAX) {
			if (session('tuser')['step2'] != 1) {
				$errormsg['code'] = -1;
				$errormsg['message'] = '非法打开链接！';
				$this->ajaxReturn($errormsg);
			}
			$this->ajaxReturn(telcode(session('tuser')['tel']));
		} else {
			$this->error('非法打开链接');
		}

	}

	public function teltwo() //手机验证第二步
	{
		if (IS_AJAX) {
			$User = D('User');
			$this->ajaxReturn($User->teltwo());
		} else {
			$this->error('非法打开链接');
		}
	}

	public function editpass()  //第3步
	{
		if (session('tuser')['step3'] != 1) {
			$this->redirect('findpass/totel');
		}
		$this->display();
	}

	public function passthree() //修改密码第3步
	{
		if (IS_AJAX) {
			$User = D('User');
			$this->ajaxReturn($User->passthree());
		} else {
			$this->error('非法打开链接');
		}
	}

	public function complete()
	{
		$this->display();
	}

	public function toemail()
	{
		$this->display();
	}

	public function emailone()  //邮件修改密码第1步
	{
		if (IS_AJAX) {
			$User = D('User');
			$this->ajaxReturn($User->emailone());
		} else {
			$this->error('非法打开链接');
		}
	}

	public function emailcheck()
	{
		if (session('tuser')['step2'] != 1) {
			$this->redirect('findpass/toemail');
		}
		$this->display();
	}

	public function emailtwo()  //邮件修改密码第2步
	{
		if (IS_AJAX) {
			$User = D('User');
			$this->ajaxReturn($User->emailtwo());
		} else {
			$this->error('非法打开链接');
		}
	}

	public function emailcode()//手机验证码
	{
		if (IS_AJAX) {
			if (session('tuser')['step2'] != 1) {
				$errormsg['code'] = -1;
				$errormsg['message'] = '非法打来连接！';
				$this->ajaxReturn($errormsg);
			}
			$emailcode = mt_rand(100001, 999999);
			session('emailcode', $emailcode);
			$arr = array(
				'emailcode' => $emailcode,
				'myemail' => session('tuser')['email']
			);
			email('6', $arr);
			$errormsg['code'] = 1;
			$errormsg['message'] = '邮件验证码发送成功！';
			$this->ajaxReturn($errormsg);
		} else {
			$this->error('非法打开链接');
		}

	}

}