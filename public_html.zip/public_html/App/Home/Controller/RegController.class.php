<?php
namespace Home\Controller;

use Think\Log;

class RegController extends HomeController
{
    public function index()//注册
    {
        $pattern='/^\d+$/';
        if(preg_match($pattern, I('get.ibcode')))
        {
            cookie('ibcode',I('get.ibcode'),3600*24*31);
        }
        $this->display();
    }

    public function success()//注册成功的页面
    {
        $this->assign('userinfo',session('user'));
        $this->display();
    }
    
    public function saveadd()//新增用户
    {
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn( $User->saveadd() );
        }
        else
        {
            $this->error('非法打开链接');
        }
    }
    public function telcode()//手机验证码
    {
        getlogger()->debug($_REQUEST);//debug
        if(IS_AJAX)
        {
            $User=D('User');
            $this->ajaxReturn( $User->telcode() );
        }
        else
        {
            $this->error('非法打开链接');
        }
    }
    public function khxys()
    {
        $filename = './Public/Home/myfile/khxys.pdf';
        //文件的类型
        header('Content-type: application/pdf');
        //下载显示的名字
        $size=filesize($filename);
        header("Accept-Ranges: bytes");
        header("Accept-Length: ".$size);
        header('Content-Disposition: attachment; filename="客户协议书.pdf"');
        readfile("$filename");
        exit();
    }


}