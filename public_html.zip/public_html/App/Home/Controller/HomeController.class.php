<?php
namespace Home\Controller;
use Think\Controller;

class HomeController extends Controller
{
    //构造方法
    protected function _initialize()
    {
        header("Content-Type:text/html; charset=utf-8");
    }
    public function _empty()
    {
        $this->redirect('/error/pagenotfound');
    
    }   
    function ff(){

    }
}