<?php

namespace Home\Model;

use Think\Log;
use Think\Model;

class UserModel extends Model
{
    public function saveadd()
    {

        Log::record('user 11', Log::DEBUG);

        $errormsg['code'] = 1;
        $errormsg['message'] = '';
        ini_set("max_execution_time", "120");
        $errormsg = $this->checkdata();
        if ($errormsg['code'] != 1) return $errormsg;
        $re = $this->receviedata();

        if ($re['code']!=1){//注册mt4账号出错
            return $re;
        }

        if ($this->add($re['data']) === false) {
            $re['success'] = $re['success'] . '网站注册失败';
            $errormsg['code'] = -20;
            $errormsg['message'] = '数据库新增失败！';
        } else {
            session('telcode', null);
            $re['success'] = $re['success'] . '网站注册成功';
            $errormsg['code'] = 1;
            $errormsg['message'] = '数据库新增成功！';
        }

        //发送短信给客服
        //sendsms(C('DX_TEL.REG'),array($re['data']['mt4account'],$re['mt4pass']),"49200");
        sendsms(C('DX_TEL.REG'), array($re['data']['rname'], $re['data']['mt4account'], $re['mt4pass']), "198049");

        //发送短信客户
        sendsms($re['data']['tel'], array($re['data']['rname'], $re['data']['mt4account'], $re['mt4pass']), "198049");

        //邮件通知客服
        email('4', array(
            'rname' => $re['data']['rname'],
            'tel' => $re['data']['tel'],
            'mt4account' => $re['data']['mt4account'],
            'email' => $re['data']['email'],
            'mt4pass' => $re['mt4pass'],
            'ibcode' => $re['data']['ibcode'],
            'suceess' => $re['success']
        ));
        //邮件通知客人
        email('7', array(
            'rname' => $re['data']['rname'],
            'myemail' => $re['data']['email'],
            'mt4account' => $re['data']['mt4account'],
            'mt4pass' => $re['mt4pass']
        ));
        return $errormsg;
    }


    private function checkdata()
    {
        $errormsg['code'] = 1;
        $errormsg['message'] = '表单校验通过';
        //手机验证码校验
		if (!check_mobile_code()) {
			$errormsg['code'] = -1;
			$errormsg['message'] = '手机验证码错误！';
			return $errormsg;
		}
        mb_internal_encoding("UTF-8");
        if ((!I('post.rname')) || mb_strlen(I('post.rname')) > 30) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '用户名为空或用户名不得超过30个字符';
            return $errormsg;
        }
        $pattern = '/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel'))) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '手机号码错误！';
            return $errormsg;
        }
        $pattern = '/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/';
        if (!preg_match($pattern, I('post.email'))) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '电子邮箱错误！';
            return $errormsg;
        }

        if (I('post.ibcode')) {
            $pattern = '/^\d+$/';
            if (!preg_match($pattern, I('post.ibcode'))) {
                $errormsg['code'] = -5;
                $errormsg['message'] = 'IB编码是数字！';
                return $errormsg;
            }
        }

        if ($this->where(array('tel' => I('post.tel')))->find()) {
            $errormsg['code'] = -6;
            $errormsg['message'] = '手机号码已经注册过！';
            return $errormsg;
        }
        if ($this->where(array('email' => I('post.email')))->find()) {
            $errormsg['code'] = -7;
            $errormsg['message'] = '电子邮箱已经注册过！';
            return $errormsg;
        }

        return $errormsg;
    }

    private function receviedata()
    {
        ini_set("max_execution_time", "120");
        $re['mt4pass'] = greatmt4pass();

        $data['rname'] = trim(I('post.rname'));
        $data['tel'] = trim(I('post.tel'));
        $data['email'] = trim(I('post.email'));
        $data['ibcode'] = trim(I('post.ibcode'));
        if (!I('post.ibcode')) $data['ibcode'] = C('MT4SRV.defaultgroup');
        $data['password'] = sha1($re['mt4pass'] );
        $data['reg_time'] = time();
        $data['reg_ip'] = get_client_ip(1);
        $data['status'] = 0;
        $data['agentid'] = 0;
        $data['mt4account'] = greataccount();


        //注册
        $post_data = array(
            'group' => $data['ibcode'],//必须参数
            'name' => $data['rname'],//必须参数
            'account' => $data['mt4account'],
            'telephone' => $data['tel'],
            'email' => $data['email'],
            'primary_passwd' => $re['mt4pass'],//必须参数
            'investor_passwd' => $re['mt4pass']
        );
        $result = postmt4('addaccount', $post_data);
        $i = 1;
        while (($result['success'] != true) && ($i < 3)) {
            sleep(2);
            $result = postmt4('addaccount', $post_data);
            $i = $i + 1;
        }
        getlogger()->debug($post_data);
        getlogger()->debug($result);

        if ($result['success']==true) {
            $data['mt4_success'] = 1;
            $data['mt4_errno'] = $result['error'];
            $re['message'] = '注册成功；';

            //保存session
            session('user',$data);

            $re['code']=1;
        } else {
            $re['code']=-1;
            $data['mt4_success'] = 0;
            $data['mt4_errno'] = $result['error'];
            $re['message'] = "注册mt4账号错误！错误信息：{$result['error']}；";
        }

        $re['data'] = $data;
        return $re;
    }

    public function telcode()//手机验证码
    {

//		if (!checkcode(I('post.txyzm'))) {
//			$errormsg['code'] = -2;
//			$errormsg['message'] = '图形验证码错误！';
//			return $errormsg;
//		}
        getlogger()->debug(I('post.tel'));
        $pattern = '/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel'))) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '手机号码错误！';
            return $errormsg;
        }
        return telcode(I('post.tel'),'200739');
    }

    public function dologin()//用户登陆
    {
        ini_set("max_execution_time", "120");

        if (!checkcode(I('post.yzm'))) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '验证码错误！';
            return $errormsg;
        }
        if (!I('post.mt4account')) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '用户名不能为空！';
            return $errormsg;

        }

        if (!I('post.password')) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '密码不能为空！';
            return $errormsg;
        }
        $mt4account = trim(I('post.mt4account'));

        $pass = sha1(I('post.password'));
        $password = $this->where(array('mt4account' => $mt4account))->getField('password');
        if ($pass != $password) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '用户名或密码错误！';
            return $errormsg;
        }
        /* !!!!!!! Authenticate toward MT4 server !!!!!!!!!!!!!!!!!!!
         *
         */
        $password = trim(I('post.password'));
        $post_data = array(
            'account' => $mt4account,
            'primary_password' => $password
        );

        $i = 0;
        $result['success'] = true;

        //读取信息写入session
        $userinfo = $this->where(array('mt4account' => $mt4account))->find();

        //更新登陆时间
        $data['id'] = $userinfo['id'];
        $data['login_time'] = time();
        $data['login_ip'] = get_client_ip(1);
        $this->save($data);
        session('user', $userinfo);
        cookie('group', getgroup($mt4account));

        $errormsg['code'] = 1;
        $errormsg['message'] = U('Usercenter/index');
        return $errormsg;
    }

    public function completeinfodo()//修改用户资料
    {
        $errormsg = $this->checkinfodata();

        if ($errormsg['code'] != 1) return $errormsg;
        $data = $this->recevieinfodata();

        if ($this->save($data) === false) {
            $errormsg['code'] = -20;
            $errormsg['message'] = '用户资料修改失败！';
        } else {
            $errormsg['code'] = 1;
            $errormsg['message'] = '用户资料修改成功！';

            //重新装填session数据
            $userinfo=$this->where(array('id'=>session('user')['id']))->find();

            session('user', $userinfo);
        }
        session('useryzm', null);
        return $errormsg;
    }

    private function checkinfodata()
    {
        $errormsg['code'] = 1;
        $errormsg['message'] = '表单校验通过';

        $status = $this->where(['id' => session('user')['id']])->getField('status');

        mb_internal_encoding("UTF-8");

        if (mb_strlen(I('post.vname')) > 30) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '昵称不得超过30个字符';
            return $errormsg;
        }
        if (I('post.birthday')) {
            if (strtotime(I('post.birthday')) - time() > 0) {
                $errormsg['code'] = -2;
                $errormsg['message'] = '未来时间出生？';
                return $errormsg;
            }
        }
//        if (!$this->where(array('id' => session('user')['id']))->getField('card')) {

//			if (!I('post.cardtype')) {
//				$errormsg['code'] = -4;
//				$errormsg['message'] = '请选择证件类型';
//				return $errormsg;
//			}
        if (!I('post.card')) {
            $errormsg['code'] = -5;
            $errormsg['message'] = '请输入证件号码';
            return $errormsg;
        }
        $pattern = '/^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/';
        if (!preg_match($pattern, I('post.card'))) {
            $errormsg['code'] = -6;
            $errormsg['message'] = '身份证号码格式不正确';
            return $errormsg;
        }
        if (mb_strlen(I('post.card')) > 60) {
            $errormsg['code'] = -7;
            $errormsg['message'] = '证件号码太长请联系客服';
            return $errormsg;
        }
        //证件号码重复校验
        if ($this->where(array('cardtype' => I('post.cardtype'), 'card' => I('post.card'), 'id' => array('neq', session('user')['id'])))->find()) {
            $errormsg['code'] = -8;
            $errormsg['message'] = '证件号码已存在';
            return $errormsg;
        }

        if (!I('post.bank')) {
            $errormsg['code'] = -12;
            $errormsg['message'] = '请选择开户银行';
            return $errormsg;
        }
        if (!I('post.subbank')) {
            $errormsg['code'] = -13;
            $errormsg['message'] = '请填写开户支行';
            return $errormsg;
        }
        if (mb_strlen(I('post.subbank')) > 100) {
            $errormsg['code'] = -14;
            $errormsg['message'] = '开户支行大于100个字符';
            return $errormsg;
        }
        if (!I('post.bankaccount')) {
            $errormsg['code'] = -15;
            $errormsg['message'] = '请填写银行账号';
            return $errormsg;
        }
        if (mb_strlen(I('post.bankaccount')) > 100) {
            $errormsg['code'] = -16;
            $errormsg['message'] = '银行账号字符大于100个字符';
            return $errormsg;
        }

//        }

        $pattern = '/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel'))) {
            $errormsg['code'] = -9;
            $errormsg['message'] = '手机号码错误！';
            return $errormsg;
        }
        $pattern = '/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/';
        if (!preg_match($pattern, I('post.email'))) {
            $errormsg['code'] = -10;
            $errormsg['message'] = '电子邮箱格式错误！';
            return $errormsg;
        }

        if (mb_strlen(I('post.address')) > 300) {
            $errormsg['code'] = -11;
            $errormsg['message'] = '详细地址超过300个字符';
            return $errormsg;
        }


        //手机号码重复校验
        if ($this->where(array('tel' => I('post.tel'), 'id' => array('neq', session('user')['id'])))->find()) {
            $errormsg['code'] = -17;
            $errormsg['message'] = '手机号码已存在';
            return $errormsg;
        }
        //电子邮箱重复校验
        if ($this->where(array('card' => I('post.email'), 'id' => array('neq', session('user')['id'])))->find()) {
            $errormsg['code'] = -18;
            $errormsg['message'] = '电子邮箱已存在';
            return $errormsg;
        }


        return $errormsg;
    }

    private function recevieinfodata()
    {
        $data['id'] = session('user')['id'];
        $data['vname'] = I('post.vname');
        $data['sex'] = I('post.sex');
        if (I('post.birthday')) $data['birthday'] = I('post.birthday');

        if (I('post.cardtype')) $data['cardtype'] = 1;//默认给身份证
        if (I('post.card')) $data['card'] = I('post.card');
        $data['bank'] = I('post.bank');
        $data['subbank'] = I('post.subbank');
        $data['bankaccount'] = I('post.bankaccount');

        if (I('post.province') != '省份') $data['province'] = I('post.province');
        if (I('post.city') != '地级市') $data['city'] = I('post.city');
        if (I('post.county') != '市、县级市') $data['county'] = I('post.county');
        $data['address'] = I('post.address');
        $data['status'] = 1;

        return $data;
    }

    public function userinfo()//资料管理
    {
        $userinfo = $this->field('id,mt4account,vname,rname,sex,birthday,cardtype,card,province,city,county,address,tel,email,ibcode,bank,subbank,bankaccount,agentid')->where(array('id' => session('user')['id']))->find();
        $userinfo['birthday'] ? $userinfo['birthday'] = date('Y-m-d', strtotime($userinfo['birthday'])) : '';
        $userinfo['cardtype'] = showcardtype($userinfo['cardtype']);
        $userinfo['sex'] = showsex($userinfo['sex']);
        return $userinfo;
    }

    public function completeinfo()//完善资料
    {
        $userinfo = $this->field('id,mt4account,rname,vname,sex,birthday,cardtype,card,tel,email,province,city,county,address,bank,subbank,bankaccount,status')->where(array('id' => session('user')['id']))->find();
        $userinfo['birthday'] ? $userinfo['birthday'] = date('Y-m-d', strtotime($userinfo['birthday'])) : '';
        return $userinfo;
    }

    public function cardupload()//证件上传
    {
        $userinfo = $this->field('filecard,filebank')->where(array('id' => session('user')['id']))->find();
        if ($userinfo['filecard']) {
            $userinfo['filecard1'] = '<img src="' . __ROOT__ . $userinfo['filecard'] . '" width="89" height="89" >';
        }
        if ($userinfo['filebank']) {
            $userinfo['filebank1'] = '<img src="' . __ROOT__ . $userinfo['filebank'] . '" width="89" height="89" >';
        }
        return $userinfo;
    }

    public function carduploaddo()
    {

        $list = $this->field('filecard,filebank')->where(['id' => session('user')['id']])->find();
//        if( $list['filecard'] || $list['filebank'])
//        {
//            if(!session('?useryzm'))
//            {
//                $errormsg['code']=-21;
//                $errormsg['message']='请获取短信验证!';
//                return $errormsg;
//            }
//
//            if(session('useryzm')!=I('post.useryzm') && session('?useryzm'))
//            {
//                $errormsg['code']=-22;
//                $errormsg['message']='短信验证码错误!';
//                return $errormsg;
//            }
//        }


        if (!I('post.filecard')) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '请上传证件';
            return $errormsg;
        }
        if (!I('post.filebank')) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '请上传银行卡';
            return $errormsg;
        }
        $data['id'] = session('user')['id'];
        $data['filecard'] = I('post.filecard');
        $data['filebank'] = I('post.filebank');
        if ($this->save($data) !== false) {
            $errormsg['code'] = 1;
            $errormsg['message'] = '上传成功';
        } else {
            $errormsg['code'] = -20;
            $errormsg['message'] = '上传失败';

        }
        session('useryzm', null);
        return $errormsg;

    }

    public function editpassworddo()//修改密码
    {
        if (!I('post.oldpassowrd')) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '请填写原密码！';
            return $errormsg;
        }
        if (!I('post.newpassowrd1')) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '请填写新密码！';
            return $errormsg;
        }
        if (!I('post.newpassowrd2')) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '请填写确认密码！';
            return $errormsg;
        }
        //验证手机验证码
//		if ((I('post.telcode') != session('telcode')['smscode'])) {
//			$errormsg['code'] = -1;
//			$errormsg['message'] = '手机验证码错误！';
//			return $errormsg;
//		}

        mb_internal_encoding('UTF-8');
        if (mb_strlen(I('post.newpassowrd1')) < 6) {
            $errormsg['code'] = -5;
            $errormsg['message'] = '新密码最少是6位';
            return $errormsg;
        }
        if (mb_strlen(I('post.newpassowrd1')) > 20) {
            $errormsg['code'] = -8;
            $errormsg['message'] = '新密码不得大于20位';
            return $errormsg;
        }
        if (I('post.newpassowrd1') != I('post.newpassowrd2')) {
            $errormsg['code'] = -6;
            $errormsg['message'] = '新密码和确认密码不一致';
            return $errormsg;
        }
        $enoldpassword = sha1(I('post.oldpassowrd') );
        $oldpassword = $this->where(array('id' => session('user')['id']))->getField('password');
        if ($enoldpassword != $oldpassword) {
            $errormsg['code'] = -7;
            $errormsg['message'] = '原密码不正确';
            return $errormsg;
        }
        $ennewpassword = sha1(I('post.newpassowrd1') );
        if ($this->where(array('id' => session('user')['id']))->save(array('password' => $ennewpassword)) !== false) {

            //修改数据库成功，则提交修改后的密码到mt4服务器
            $post_data = array(
                'account' => session('user')['mt4account'],
                'primary_password' => $ennewpassword,
                'origin_password' => $oldpassword,
            );

            $result = postmt4('resetpassword', $post_data);

            if ($result['success'] != true) {
                Log::record($result);//记录日志

                //修改mt4服务器的密码失败，将本地数据库的密码修改回原来的
                $this->where(array('id' => session('user')['id']))->save(array('password' => $oldpassword));
                if ($result['errno'] == '65') {
                    $errormsg['code'] = -6;
                    $errormsg['message'] = '原密码错误，请重试！';
                    return $errormsg;
                } else {
                    $errormsg['code'] = -5;
                    $errormsg['message'] = 'MT4密码修改失败，请重试！';
                    return $errormsg;
                }
            } else {
                $errormsg['code'] = 1;
                $errormsg['message'] = 'MT4密码修改成功！';
                return $errormsg;
            }
            $errormsg['code'] = 1;
            $errormsg['message'] = '新密码修改成功';
            return $errormsg;
        } else {
            $errormsg['code'] = -20;
            $errormsg['message'] = '新密码修改失败';
            return $errormsg;
        }
    }


    public function telone()
    {
        if (!checkcode(I('post.yzm'))) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '验证码错误！';
            return $errormsg;
        }
        if (I('post.mt4account') == '') {
            $errormsg['code'] = -2;
            $errormsg['message'] = '用户名不能为空！';
            return $errormsg;
        }
        $pattern = '/^1(\d){10}$/';
        if (!preg_match($pattern, I('post.tel'))) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '手机格式不正确！';
            return $errormsg;
        }
        $where = array(
            'mt4account' => I('post.mt4account'),
            'tel' => I('post.tel')
        );
        if (!$this->field('id')->where($where)->find()) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '用户名或手机号码不存在！';
            return $errormsg;
        }
        $where['step2'] = 1;
        session('user', $where);

        $errormsg['code'] = 1;
        $errormsg['message'] = U('findpass/telcheck');
        return $errormsg;

    }

    public function teltwo()//手机修改第二步
    {
        if (session('user')['step2'] != 1) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '非法打开链接！';
            return $errormsg;
        }
        //手机验证码校验
        if ((I('post.telcode') != session('telcode')['smscode']) || (I('post.telcode') == '')) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '手机验证码错误！';
            return $errormsg;
        }

        $user = session('user');
        $user['step3'] = 1;
        session('user', $user);

        $errormsg['code'] = 1;
        $errormsg['message'] = U('findpass/editpass');
        return $errormsg;
    }

    public function passthree() //修改密码第3步
    {
        if (session('user')['step3'] != 1) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '非法打开链接！';
            return $errormsg;
        }
        if (!I('post.newpassowrd1')) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '请填写新密码！';
            return $errormsg;
        }
        if (!I('post.newpassowrd2')) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '请填写确认密码！';
            return $errormsg;
        }
        mb_internal_encoding('UTF-8');
        if (mb_strlen(I('post.newpassowrd1')) < 6) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '新密码最少是6位';
            return $errormsg;
        }
        if (mb_strlen(I('post.newpassowrd1')) > 20) {
            $errormsg['code'] = -5;
            $errormsg['message'] = '新密码不得大于20位';
            return $errormsg;
        }
        if (I('post.newpassowrd1') != I('post.newpassowrd2')) {
            $errormsg['code'] = -6;
            $errormsg['message'] = '新密码和确认密码不一致';
            return $errormsg;
        }

        $post_data = array(
            'account' => session('user')['mt4account'],
            'primary_password' => I('post.newpassowrd1'),
            'reset' => 'true',
            //'name'=>'TEST161584',
            //'telephone'=>'18888222000', origin_password
        );

        $result = postmt4('resetpassword', $post_data);
        if ($result['success']) {
            $errormsg['code'] = 1;
            $errormsg['message'] = '新密码修改成功';
            session('user', null);
            return $errormsg;
        } else {
            $errormsg['code'] = -20;
            $errormsg['postmsg'] = $post_data;
            $errormsg['dump'] = $result;
            $errormsg['message'] = '新密码修改失败，请重试！';
            session('user', null);
            return $errormsg;
        }
         $ennewpassword=sha1(I('post.newpassowrd1').'firma');
         if( $this->where(array('mt4account'=>session('user')['mt4account']))->save(array('password'=>$ennewpassword))!==false )
         {
             $errormsg['code']=1;
             $errormsg['message']='新密码修改成功';
             session('user',null);
             return $errormsg;
         }
         else
         {
             $errormsg['code']=-20;
             $errormsg['message']='新密码修改失败，请重试！';
             session('user',null);
             return $errormsg;
         }
    }

    public function emailone()  //邮件修改密码第1步
    {
        if (!checkcode(I('post.yzm'))) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '验证码错误！';
            return $errormsg;
        }
        if (I('post.mt4account') == '') {
            $errormsg['code'] = -2;
            $errormsg['message'] = '用户名不能为空！';
            return $errormsg;
        }
        $pattern = '/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/';
        if (!preg_match($pattern, I('post.email'))) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '请填写正确的邮件！';
            return $errormsg;
        }
        $where = array(
            'mt4account' => I('post.mt4account'),
            'email' => I('post.email')
        );
        if (!$this->field('id')->where($where)->find()) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '用户名或邮箱不存在！';
            return $errormsg;
        }
        $where['step2'] = 1;
        session('user', $where);

        $errormsg['code'] = 1;
        $errormsg['message'] = U('findpass/emailcheck');
        return $errormsg;
    }

    public function emailtwo()  //邮件修改密码第2步
    {
        if (session('user')['step2'] != 1) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '非法打来连接！';
            return $errormsg;
        }
        //手机验证码校验
        if ((I('post.yzm') != session('emailcode')) || (I('post.yzm') == '')) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '邮件验证码错误！';
            return $errormsg;
        }

        $user = session('user');
        $user['step3'] = 1;
        session('user', $user);

        $errormsg['code'] = 1;
        $errormsg['message'] = U('findpass/editpass');
        return $errormsg;
    }

    public function editmt4passdo()//MT4密码页面
    {
        if (!checkcode(I('post.yzm'))) {
            $errormsg['code'] = -1;
            $errormsg['message'] = '验证码错误！';
            return $errormsg;
        }
        $pattern1 = '/[a-zA-Z]/';
        $pattern2 = '/[0-9]/';
        if (!(preg_match($pattern1, I('post.newpassowrd1')) && preg_match($pattern2, I('post.newpassowrd1')))) {
            $errormsg['code'] = -2;
            $errormsg['message'] = '新密码是6-10位的字母和数字!';
            return $errormsg;
        }
        mb_internal_encoding('UTF-8');
        if (mb_strlen(I('post.newpassowrd1')) < 6 || mb_strlen(I('post.newpassowrd1')) > 10) {
            $errormsg['code'] = -3;
            $errormsg['message'] = '新密码是6-10位的字母和数字!';
            return $errormsg;
        }
        if (I('post.newpassowrd1') != I('post.newpassowrd2')) {
            $errormsg['code'] = -4;
            $errormsg['message'] = '新密码和确认密码不一致!';
            return $errormsg;
        }

        $post_data = array(
            'account' => session('user')['mt4account'],
            'primary_password' => I('post.newpassowrd1'),
            'origin_password' => I('post.oldpassword'),
        );

        $result = postmt4('resetpassword', $post_data);

        if ($result['success'] != true) {
            if ($result['errno'] == '65') {
                $errormsg['code'] = -6;
                $errormsg['message'] = '原密码错误，请重试！';
                return $errormsg;
            } else {
                $errormsg['code'] = -5;
                $errormsg['message'] = 'MT4密码修改失败，请重试！';
                return $errormsg;
            }
        } else {
            $errormsg['code'] = 1;
            $errormsg['message'] = 'MT4密码修改成功！';
            return $errormsg;
        }
    }

}

?>