<?php
namespace Home\Model;
use Think\Model;

class AgentModel extends Model
{
    public function findson($id)//找儿子算法
    {
        while($id)
        {
            $ids='';
            $where['pid']=array('in',$id);
            $list=$this->field('id')->where($where)->select();
            foreach($list as $val)
            {
                $allid[]=$val['id'];
                $ids.=$val['id'].',';
            }
            $id=substr($ids,0,-1);
        }
        return $allid;
    }
    public function findfather()//找父亲算法
    {
        $ibcod=114;
        $pid=$this->where(array('ibcode'=>$ibcod))->getField('pid');
        while($pid!=0)
        {
            $allpid[]=$pid;
            $pid=$this->where(array('id'=>$pid))->getField('pid');
        }
        print_r($allpid);
    
    }
}
?>