<?php
namespace Home\Model;
use Think\Model;

class PayinModel extends Model
{
    static private $exRate = 100;

    public function payinshowdo()//注资
    {
        if( getgroup(session('user')['mt4account'])!='99')
        {
            if( doubleval(I('post.Ordamt')) < 100 )
            {
                $payinfo['code']=-2;
                $payinfo['message']='注资金额需大于100美金';
                return $payinfo;
            }
        }
 
        if(!I('post.paytype'))
        {
            $payinfo['code']=-3;
            $payinfo['message']='请选择银行';
            return $payinfo;
        }
        //ordamt 充值金额
        session('payin',['Ordamt'=>I('post.Ordamt'),'paytype'=>I('post.paytype')]);
        
        $payinfo['code']=1;
        $payinfo['message']='校验通过';
        
        return $payinfo;
    }
    
    public function payto()
    {
        if(session('?payin'))
        {
            //生成支付参数
            $payinfo['MD5key'] = C('HR.MD5key');  			//MD5key值为您在新付支付注册后所得、需要您向业务人员获取
            $payinfo['Merno'] = C('HR.Merno'); 			//商户ID为您在新付支付注册后所得
            $payinfo['Signtype'] = C('HR.Signtype');           			//加密方式 目前只为M代表MD5
            $payinfo['Prdordno'] = $this->orderCreate();  //订单编号
            $payinfo['bizType'] =  C('HR.bizType');  				    //商户业务类型为您在新付支付注册时候设定
            $payinfo['Prdordnam'] = session('user')['mt4account']; 	//商品名称
            $payinfo['Ordamt'] = session('payin')['Ordamt']*$this::$exRate*exchangerate();//美元转换成rmb支付金额 [必填]【以分为单位】
            $payinfo['Orddate'] = date('Ymd'); 		   //下单日期 [必填]交易时间：
            $payinfo['TranType'] = C('HR.TranType');    			//交易类型
            $payinfo['Paytype'] = C('HR.Paytype');  				    //支付方式
            $payinfo['bankCode']  = session('payin')['bankCode'];   	     //银行编码
            $payinfo['ThirdParty'] = C('HR.ThirdParty');
            $payinfo['custnam'] = '';  					//买家姓名
            $payinfo['custmob'] = '';   		            //买家手机号
            $payinfo['custmail']  = '';                    //买家邮箱
            $payinfo['custcardno'] = '';  			        //买家身份证号
            $payinfo['Return_url'] = 'http://www.garhfx.com/Usercenter/payinsuccess.html';   //同步通知url
            $payinfo['Notify_url'] = 'http://www.garhfx.com/Payresult/notifyurl.html'; //U('Payresult/notifyurl','','html',$_SERVER['HTTP_HOST']);   //[必填]支付完成后，后台接收支付结果，可用来更新数据库值
            
            if($payinfo['Signtype']=='M') //MD5加密
            {
                //设置参与MD5加签的字段
                $md5src= $payinfo['Merno']."&".$payinfo['Signtype']."&".$payinfo['Prdordno']."&".$payinfo['Prdordnam']."&".$payinfo['Ordamt']."&".$payinfo['Orddate']."&".$payinfo['TranType']."&".$payinfo['Paytype']."&".$payinfo['Notify_url']."&".$payinfo['MD5key'];
                $inMsg = strtoupper(md5($md5src));
            }
            else
            {
                exit("签名类型有误");
            }
            $payinfo['inMsg']=$inMsg;
            
            //记录数据库
            $data['userid']     =session('user')['id'];
            $data['rname']      =session('user')['rname'];
            $data['mt4account'] =session('user')['mt4account'];
            $data['tel']        =session('user')['tel'];
            $data['pay_time']   =time();
            $data['pay_ip']     =get_client_ip(1);
            $data['money']      =session('payin')['Ordamt']*$this::$exRate;
            $data['exchangerate']=exchangerate();
            $data['status']     =0;
            $data['prdordno']   =$payinfo['Prdordno'];
            $data['prdordnam']  =$payinfo['Prdordnam'];
            $data['ordamt']     =$payinfo['Ordamt'];
            $data['orddate']    =$payinfo['Orddate'];
            $data['bankcode']   =$payinfo['bankCode'];
            
            $this->add($data);
            
            return $payinfo;
            
        }
        
    }
    
    //生成订单号
    public function orderCreate()
    {
        $myrand   = str_pad(mt_rand(1,9999), 4, '0', STR_PAD_LEFT);//生成随机的4位数，生成时不足4位左补零
        $Prdordno = 'F'.session('user')['mt4account'].date('YmdHis').$myrand;//日期的前8位
        if( $this->field('prdordno')->where(array('prdordno'=>$Prdordno))->find() )
        {
            $this->orderCreate();
        }
        return $Prdordno;
    }
    
    public function payinrecorde($redata)//注资记录
    {
        $redata['fromtime'] = $redata['fromtime']?strtotime($redata['fromtime']):strtotime('2000-01-01');
        $redata['totime']   = $redata['totime']?strtotime($redata['totime'].'23:59:59'):time();
        
        $where['userid']=$redata['id'];
        $where['pay_time']=array('between',array($redata['fromtime'],$redata['totime']));
        if(isset($redata['status']))
        { 
            if( $redata['status']=='1' || $redata['status']=='0' )
            {
                $where['status']=$redata['status'];
            }
        }
        $list=$this->where($where)->select();
        foreach($list as $key=>$val)
        {
            $list[$key]['pay_time']=date('Y-m-d',$val['pay_time']);
            $val['retime']?$list[$key]['retime']=date('Y-m-d',$val['retime']):$list[$key]['retime']='';         
            $list[$key]['money']=$val['money']/$this::$exRate;
            $list[$key]['status']=showpayinstatus($val['status']);
        }
        return $list;
    }
}
?>
