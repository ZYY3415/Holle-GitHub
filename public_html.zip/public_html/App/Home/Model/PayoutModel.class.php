<?php

namespace Home\Model;

use BestPay\BestPay;
use Think\Log;
use Think\Model;

class PayoutModel extends Model
{
    public function payoutdo()//取款
    {
        ini_set("max_execution_time", "120");
        $User = M('User');
        $userinfo = $User->where(array('id'=>session('user')['id']))->find();
        if ((!$userinfo['rname']) || (!$userinfo['card']) || (!$userinfo['tel']) || (!$userinfo['email']) || (!$userinfo['bank']) || (!$userinfo['subbank']) || (!$userinfo['bankaccount'])) {
            $errormsg['code'] = -30;
            $errormsg['message'] = '请您先资料未完善';
            return $errormsg;
        }
        mb_internal_encoding("UTF-8");
//        if (!I('post.bank')) {
//            $errormsg['code'] = -1;
//            $errormsg['message'] = '请选择收款银行名称';
//            return $errormsg;
//        }
//        if (!I('post.bank_address')) {
//            $errormsg['code'] = -2;
//            $errormsg['message'] = '收款银行地址未填写';
//            return $errormsg;
//        }
//        if (mb_strlen(I('post.bank_address')) > 100) {
//            $errormsg['code'] = -3;
//            $errormsg['message'] = '收款银行地址大于100个字符';
//            return $errormsg;
//        }
//        if (!I('post.bank_account')) {
//            $errormsg['code'] = -4;
//            $errormsg['message'] = '请填写收款银行卡号';
//            return $errormsg;
//        }
//        if (mb_strlen(I('post.bank_account')) > 100) {
//            $errormsg['code'] = -5;
//            $errormsg['message'] = '收款银行卡号大于100个字符';
//            return $errormsg;
//        }
        if (I('post.money') <= 0) {
            $errormsg['code'] = -6;
            $errormsg['message'] = '取款金额要大于0';
            return $errormsg;
        }
        //向mt4服务器获取账户信息，余额
        $result1 = $this->getmoney();
        if ($result1['success'] != true) {
            $errormsg['code'] = -10;
            $errormsg['message'] = '无法获取mt4账号数据，提款申请失败请重试！';

            Log::record($result1);

            return $errormsg;
        } else {
            $money = $result1['data'][0]['Balance'];
            if (I('post.money') > $money) {
                $errormsg['code'] = -7;
                $errormsg['message'] = '账户余额不足';
                return $errormsg;
            }
        }

        if (I('post.money') < 100 && I('post.money') > 0) {
            $data['sxf'] = 300;
        } elseif (I('post.money') >= 100) {
            $data['sxf'] = 0;
        }
        $exchange=exchangerate();//汇率

        //保存记录到本地数据库 ------------------------------------
        $data['userid'] = session('user')['id'];
        $data['mt4account'] = session('user')['mt4account'];
        $data['tel'] = session('user')['tel'];
        $data['rname'] = session('user')['rname'];
        $data['bank'] = session('user')['bank'];
        $data['bank_address'] = session('user')['subbank'];
        $data['bank_account'] = session('user')['bankaccount'];
        $data['money'] = I('post.money') * $exchange;
        $data['exchangerate'] =$exchange;
        $data['pay_time'] = time();
        $data['pay_ip'] = get_client_ip(1);
        $data['status'] = 0;
        $data['order'] = $this->order();
        $data['province']=session('user')['province'];
        $data['city']=session('user')['city'];
        if ($this->add($data) !== false) {
            $errormsg['code'] = 1;
            $errormsg['message'] = '数据库添加成功';
        } else {
            $errormsg['code'] = -20;
            $errormsg['message'] = '数据库添加失败';
            getlogger()->error($this->getDbError());//记录日志
            return $errormsg;
        }
        //向第一支付提交申请  -----------------------------------
        $bestdata = array('rname' => $data['rname'],
            'order' => $data['order'], //订单
            'mt4account' => $data['mt4account'],
            'userid' => C('DYZF_APP_ID'),  //商户的APPID
            'appkey'=>C('DYZF_KEY'),//商户key
            'tel' => $data['tel'],
            'bank' => $data['bank'],
            'bank_account' => $data['bank_account'],
            'bank_address' => $data['bank_address'],
            'province'=>$data['province'],
            'city'=>$data['city'],
            'pay_time' => $data['pay_time'],
            'money' => $data['money'],//单位是元
            'exchangerate' => $data['exchangerate'],//汇率
            'notify_url' => U('usercenter/payoutreturn', '', true, true));
        vendor('BestPay.BestPay');
        $bestpay=new BestPay();
        $re_bestpay=$bestpay->withdraw($bestdata);
        if (true!==$re_bestpay){
            //提取返回消息
            $re_bestpay=json_decode($re_bestpay,true);
            //失败
            $errormsg['code'] = -20;
            $errormsg['message'] = '无法向第一支付提交取款申请，取款失败!原因：'.$re_bestpay['message'];

            getlogger()->error($re_bestpay);//记录日志

            return $errormsg;
        }
        //出金成功，短信通知  ----------------------------------
        sendsms(C('DX_TEL.PAYOUT'), array(
            date('Y-m-d H:i:s'),
            session('user')['rname'],
            session('user')['mt4account'],
            $data['money'] / 100
        ), "83930");


        //发送邮件通知 ---------------------------------------
        $mt4log = 'MT4余额自动扣除成功';
        email('2', array(
            'rname' => session('user')['rname'],
            'tel' => session('user')['tel'],
            'money' => $data['money'] / 100,
            'sxf' => $data['sxf'] / 100,
            'dzje' => ($data['money'] - $data['sxf']) / 100,
            'mt4account' => session('user')['mt4account'],
            'bank_account' => $data['bank_account'],
            'mt4log' => $mt4log,
            'bank_address' => $data['bank'] . $data['bank_address']
        ));
        return $errormsg;
        //向mt4服务器提交取款------------------------------------------
        $result['success'] = false;
        $post_data = array('account' => $data['mt4account'],
            'command' => 'BALANCE',
            'price' => $data['money'] / 100 * (-1),
            'expiration' => time() + 3000,
            'balanceno' => $data['order'],
            'comment' => 'W ' . $data['order']);
        try {
            $result = postmt4('transaction', $post_data, 0);
        } catch (Exception $e) {
            getlogger()->error($e->getMessage());
        }
        //将mt4操作记录记录至数据库
        M('Payinlog')->add(['mt4account' => $data['mt4account'],
            'balance' => $data['money'] / 100 * (-1),
            'prdordno' => $data['order'], 'log' => $result,
            'type' => 1, 'create_time' => time()]);

        $result = json_decode($result, true);
        if ($result['success'] != true) {
            if ($result['errno'] == -90) {
                $errormsg['code'] = -90;
                $errormsg['message'] = '有未平仓订单，不能出金！';
            } elseif ($result['errno'] == -80) {
                $errormsg['code'] = -80;
                $errormsg['message'] = '没有足够的余额！';
            } elseif ($result['errno'] == -70) {
                $errormsg['code'] = -70;
                $errormsg['message'] = '未能检测到用户的余额，请稍后重试！';
            }else{
                $errormsg['code']=-1;
                $errormsg['message']='MT4余额自动扣除失败。失败原因：'.$result['message'];
            }
        } else {
            //出金成功，短信通知  ----------------------------------
            sendsms(C('DX_TEL.PAYOUT'), array(
                date('Y-m-d H:i:s'),
                session('user')['rname'],
                session('user')['mt4account'],
                $data['money'] / 100
            ), "83930");


            //发送邮件通知 ---------------------------------------
            $mt4log = 'MT4余额自动扣除成功';
            email('2', array(
                'rname' => session('user')['rname'],
                'tel' => session('user')['tel'],
                'money' => $data['money'] / 100,
                'sxf' => $data['sxf'] / 100,
                'dzje' => ($data['money'] - $data['sxf']) / 100,
                'mt4account' => session('user')['mt4account'],
                'bank_account' => $data['bank_account'],
                'mt4log' => $mt4log,
                'bank_address' => $data['bank'] . $data['bank_address']
            ));
        }

    }


    public function payoutrecorde()//取款记录
    {
        $fromtime = I('fromtime') ? strtotime(I('fromtime')) : strtotime('2000-01-01');
        $totime = I('totime') ? strtotime(I('totime') . '23:59:59') : time();

        $where['userid'] = session('user')['id'];
        $where['pay_time'] = array('between', array($fromtime, $totime));
        $list = $this->where($where)->select();
        foreach ($list as $key => $val) {
            $list[$key]['pay_time'] = date('Y-m-d', $val['pay_time']);
            $list[$key]['money'] = $val['money'] / 100;
        }
        return $list;
    }

    public function getmoney()
    {
        $url = 'getaccount';
        $accounts['accounts'] = array(session('user')['mt4account']);
        $accounts = json_encode($accounts);
        $post_data['data'] = $accounts;
        $result = postmt4($url, $post_data, 1);
        return $result;
    }

    //生成订单号
    public function order()
    {
        do {
            $order = date('YmdHis') . mt_rand(10, 99);
        } while ($this->field('id')->where(array('order' => $order))->find());

        return $order;
    }
}

?>