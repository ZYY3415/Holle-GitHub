<?php

namespace Home\Model;


use Think\Model;

class ZixunModel extends Model
{

    /**
     * @return array
     * @todo 获取MarketInfo列表
     */
    public function getMarketInfoList(){

        $where = ' status=1 and identity in (1,2,4) ';
        $cat = I('get.cat');
        if($cat && in_array((int)$cat, array(1,2,4))){
            switch($cat){
                case 1:
                    $where = ' status=1 and identity=1 ';
                    break;
                case 2:
                    $where = ' status=1 and identity=2 ';
                    break;
                case 4:
                    $where = ' status=1 and identity=4 ';
                    break;

            }
        }

        $page = I('get.page');

        if(!$page){
            $page = 1;
        }

        if($page> 90){
            $page = 90;
        }


        $list = $this->field('id,picture,title,description,come_from,date_added,identity')
            ->where($where)
            ->order('id DESC')
            ->page($page, 6)
            ->select();

//        转换时间格式
        for($i=0,$n=count($list); $i < $n; $i++){

            $list[$i]['date_added'] = date('Y-m-d', strtotime($list[$i]['date_added']));
        }

        return $list;

    }

    /**
     * @return array
     * @todo 获取资讯列表
     */
    public function getList(){

        $where = ' status=1 and identity in (6,7,8) ';
        $cat = I('get.cat');
        if($cat && in_array((int)$cat, array(6,7,8))){
            switch($cat){
                case 6:
                    $where = ' status=1 and identity=6 ';
                    break;
                case 7:
                    $where = ' status=1 and identity=7 ';
                    break;
                case 8:
                    $where = ' status=1 and identity=8 ';
                    break;

            }
        }

        $page = I('get.page');

        if(!$page){
            $page = 1;
        }

        if($page> 90){
            $page = 90;
        }


        $list = $this->field('id,picture,title,description,come_from,date_added,identity')
            ->where($where)
            ->order('id DESC')
            ->page($page, 6)
            ->select();

//        转换时间格式
        for($i=0,$n=count($list); $i < $n; $i++){

            $list[$i]['date_added'] = date('Y-m-d', strtotime($list[$i]['date_added']));
        }

        return $list;

    }


    /**
     * @param $id
     * @return array
     * @todo 获取文章内容
     */
    function getDetails($id){

        $details = $this->field('picture,title,description,content,come_from,viewed,date_added')->where('status=1 and id=' . $id)->find();
        $details['date_added'] = date('Y-m-d', strtotime($details['date_added']));

        return $details;
    }

    /**
     * @param $id
     * @todo 添加文章浏览次数
     */
    function  updateViewCount($id){

        $this->find($id);
        $this->viewed +=1;
        $this->save();
    }
    /**
     * @return array $data
     * @todo 最新资讯
     */
    function getLatestInformation(){

        return $this->field('id,title')
            ->where(' status=1 and identity=2 ')
            ->order('id DESC')
            ->limit(5)
            ->select();
    }
    /**
     * @return array $data
     * @todo 最新报道
     */
    function getLatestReports(){

        return $this->field('id,title')
            ->where(' status=1 and identity=4 ')
            ->order('id DESC')
            ->limit(5)
            ->select();

    }

    /**
     * @param $id
     * @param $identity
     * @param int $prevOrNext
     * @return array
     * @todo 获取上一篇或者下一篇文章
     */
    function getPrevOrNextOne($id, $prevOrNext=0){
        $data = $this->field('identity')->find($id);
        $where = ' status=1 and identity='.(int)$data['identity'] . ' and id < '.(int)$id;
        $orderBy = 'id DESC';
        if($prevOrNext == 1){
            $where = ' status=1 and identity='.(int)$data['identity'] . ' and id > '.(int)$id;
            $orderBy = 'id';
        }
        return $this->field('id,title')
            ->where($where)
            ->order($orderBy)
            ->limit(1)
            ->select();
    }
}