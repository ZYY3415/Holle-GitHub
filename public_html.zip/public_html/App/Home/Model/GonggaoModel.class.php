<?php

namespace Home\Model;


use Think\Model;

class GonggaoModel extends Model
{




}