<?php
namespace Home\Model;
use Think\Model;

class ExchangerateModel extends Model
{
    public function setexchangerateod()//客服设置汇率
    {
        $redata['exchangerate']=I('post.exchangerate');
        if(session('user')['agentid']!=1)
        {
            $errormsg['code']=-1;
            $errormsg['message']='非法打开链接';
            return  $errormsg;
        }
        if(!is_numeric($redata['exchangerate']))
        {
            $errormsg['code']=-2;
            $errormsg['message']='汇率是数字';
            return  $errormsg;
        }
        $data['exchangerate']=$redata['exchangerate'];
        $data['doname']=session('user')['id'];
        $data['dotime']=time();
        $data['doip']=get_client_ip(1);
        if( $this->order('id desc')->getField('exchangerate')==$data['exchangerate'] )
        {
            $errormsg['code']=-3;
            $errormsg['message']='汇率未修改';
            return  $errormsg;
        }
        if($this->add($data)!==false)
        {
            $errormsg['code']=1;
            $errormsg['message']='汇率设置成功';
            return  $errormsg;
        }
        else
        {
            $errormsg['code']=-1;
            $errormsg['message']='汇率设置失败';
            return  $errormsg;
        }
    }
}
?>