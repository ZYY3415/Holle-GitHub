<?php
namespace Home\Model;
use Think\Model;

class SxfModel extends Model
{
    public function sxfdo()//客服设置汇率
    {
        $redata['sxf']=I('post.sxf');
        if(session('user')['agentid']!=1)
        {
            $errormsg['code']=-1;
            $errormsg['message']='非法打开链接';
            return  $errormsg;
        }
        if(!is_numeric($redata['sxf']))
        {
            $errormsg['code']=-2;
            $errormsg['message']='手续费是数字';
            return  $errormsg;
        }

        $data['fl']=$redata['sxf'];
        $data['id']=1;

        if($this->save($data)!==false)
        {
            $errormsg['code']=1;
            $errormsg['message']='手续费设置成功';
            return  $errormsg;
        }
        else
        {
            $errormsg['code']=-1;
            $errormsg['message']='手续费设置失败';
            return  $errormsg;
        }
    }
}
?>